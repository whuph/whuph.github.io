The matrix data used by the test function is placed in the "Algorithm/input_data" folder.

If you find this code useful in your work, please cite the 
following paper by the author of the code "Chen J, Deng C, Peng H, et al. Enhanced Brain Storm Optimization with Role-playing Strategy[C]//2019 IEEE Congress on Evolutionary Computation (CEC). IEEE, 2019: 1132-1139".