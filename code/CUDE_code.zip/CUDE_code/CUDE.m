function [GlobalMin, outcome, CPUtime] = CUDE(fhd, fun, xmin, xmax)
%--------------------------------------------------------------------------------------------------------
% 2014-10-27 programming by Hu Peng at WHU
%--------------------------------------------------------------------------------------------------------
% Peng H, Wu Z*, Deng C. Enhancing differential evolution with commensal learning and uniform local search[J].
% Chinese Journal of Electronics, 2017, 26(4): 725-733. 
%--------------------------------------------------------------------------------------------------------
% More information can visit H Peng's homepage: https://whuph.github.io/index.html
%--------------------------------------------------------------------------------------------------------
    tic;

    global initial_flag
    initial_flag = 0;

    D  = 30;
    NP = 50;
          
    nfevalmax = 10000*D;

    outcome = [];
    
    lowbound  = ones(1,D).*xmin;
    highbound = ones(1,D).*xmax;
    pop = zeros(NP,D);

    for i=1:NP
        pop(i,:) = lowbound + rand(1,D).*(highbound - lowbound);
    end

    val = zeros(1,NP);
    nfeval = 0;

    for i=1:NP
        val(i)  = feval(fhd,pop(i,:)',fun);
    end
    nfeval  = nfeval + NP;

    r = zeros(1,3);
    
    lowF = 0.5;
    uppF = 0.8;
    lowCR = 0.1;
    uppCR = 0.9;
    std = 0.1;
    
    sn = 6;
    dictsucc = ones(NP,sn);
    dicttota = ones(NP,sn);
    
    %uniform_layout = [ 1 2 3 4 5 6; 2 4 6 1 3 5; 3 6 2 5 1 4; 4 1 5 2 6 3; 5 3 1 6 4 2; 6 5 4 3 2 1 ];
    Q = 6; % level
    J = 6; % factor
    temp_layout = Uniform_array_generate(Q+1,J);
    uniform_layout = temp_layout(1:Q,:);
    
    while nfeval <nfevalmax

        for i=1:NP
            rd=randperm(NP);
            for j=1:3
                if rd(j)~=i; r(j)=rd(j);
                else r(j)=rd(4); end
            end 
            
            tempx = pop(i, :);
                
            jrand = fix(1+D*rand);
            
            sr = dictsucc(i,:)./dicttota(i,:);
            P = sr / sum( sr );
            scheme = Roulette(P);

            switch scheme
                case 1
                    F = lowF + randn * std;
                    CR = lowCR + randn * std;
                    for j=1:D
                        if (rand<CR || j==jrand ) 
                            tempx(j) = pop(r(1),j)+F.*(pop(r(2),j)-pop(r(3),j));
                            if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                tempx(j) = lowbound(j) + rand*(highbound(j) - lowbound(j));
                            end
                        end
                    end

                case 2
                    F = uppF + randn * std;
                    CR = uppCR + randn * std;
                    for j=1:D
                        if (rand<CR || j==jrand ) 
                            tempx(j) = pop(r(1),j)+F.*(pop(r(2),j)-pop(r(3),j));
                            if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                tempx(j) = lowbound(j) + rand*(highbound(j) - lowbound(j));
                            end
                        end
                    end

                case 3
                    F = lowF + randn * std;
                    CR = lowCR + randn * std;
                    [~,bestid] = min(val);
                    for j=1:D
                        if (rand<CR || j==jrand ) 
                            tempx(j) = pop(bestid,j)+F.*(pop(r(2),j)-pop(r(3),j));                            
                            if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                tempx(j) = lowbound(j) + rand*(highbound(j) - lowbound(j));
                            end
                        end
                    end

                case 4
                    F = uppF + randn * std;
                    CR = uppCR + randn * std;
                    [~,bestid] = min(val);
                    for j=1:D
                        if (rand<CR || j==jrand ) 
                            tempx(j) = pop(bestid,j)+F.*(pop(r(2),j)-pop(r(3),j));                            
                            if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                tempx(j) = lowbound(j) + rand*(highbound(j) - lowbound(j));
                            end
                        end
                    end

                case 5
                    F = lowF + randn * std;
                    CR = lowCR + randn * std;
                    randF = rand;
                    for j=1:D
                        if (rand<CR || j==jrand ) 
                            tempx(j) = pop(i,j)+randF.*(pop(r(1),j)-pop(i,j))+F.*(pop(r(2),j)-pop(r(3),j));
                            if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                tempx(j) = lowbound(j) + rand*(highbound(j) - lowbound(j));
                            end
                        end
                    end

                case 6
                    F = uppF + randn * std;
                    CR = uppCR + randn * std;
                    randF = rand;
                    for j=1:D
                        if (rand<CR || j==jrand ) 
                            tempx(j) = pop(i,j)+randF.*(pop(r(1),j)-pop(i,j))+F.*(pop(r(2),j)-pop(r(3),j));
                            if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                tempx(j) = lowbound(j) + rand*(highbound(j) - lowbound(j));
                            end
                        end
                    end

            end                
            
            tempval = feval(fhd, tempx', fun);
            nfeval  = nfeval + 1;

            if tempval < val(i)
                val(i)   = tempval;
                pop(i,:) = tempx;
                dictsucc(i,scheme) = dictsucc(i,scheme)+1;
            end
            dicttota(i,scheme) = dicttota(i,scheme)+1;
            
        end %--for i=1:NP
        
        % Uniform local search        
        bid=randperm(NP);

        [u,subvectors] = Uniform_local_search(pop(bid(1), :), pop(bid(2), :), D, uniform_layout, Q, J);
                
        for j = 1 : Q
            fit_u(j) = feval(fhd, u(j,:)', fun);                    
        end
        nfeval = nfeval + Q;
        
        [minfit,mid] = min(fit_u);
                                
        if val(bid(1))> minfit
            pop(bid(1),:) = u(mid,:);
            val(bid(1)) = minfit;
        elseif val(bid(2))> minfit
            pop(bid(2),:) = u(mid,:);
            val(bid(2)) = minfit;            
        end
        
        GlobalMin = min(val);
        outcome   = [outcome GlobalMin];  

    end %--while nfeval <nfevalmax

    CPUtime   = toc;

end

function Select=Roulette(P)
    m = length(P);  
    r = rand; 
    
    sumP = 0;      
    j = ceil(m*rand);      
    while sumP < r          
        sumP = sumP + P(mod(j-1,m)+1);         
        j = j+1;     
    end     
    Select = mod(j-2,m)+1; 
    
end

function [U,mouse] = Uniform_local_search(V, X, D, uni_array, Q, J)

    % U contains the individuals produced 
    
    beta = zeros(D, Q);
    U = zeros(Q, D);

    % Do quantization for this search range and defines Q levels for each variable 
    for i = 1:D

        if V(1, i) == X(1, i)
            beta(i, :) = V(1, i)*ones(1, Q);
        else
            inter = (X(1, i) - V(1, i)) / (Q-1);
            beta(i,1) = V(1,i);
            beta(i,Q) = X(1,i);
            for k=2:Q-1
                beta(i,k)=beta(i,k-1)+inter;
            end
            
            %beta(i, :) = V(1, i) : ((X(1, i) - V(1, i)) / (Q-1)) : X(1, i);
        end

    end
    

    % If the dimension of the individual is less than J, we can use the
    % Uniform layout to implement ULS directly. Otherwise, we should first
    % divides the variables into several subvectors
    if D < J

        for i = 1 : D

            temp = beta(i, :);
            U(:, i) = temp(uni_array(:, i))';
            
            mouse{i} = [i];
        end        

    else

        % Divide the variables into J subvectors
        nouse = 1 + randperm(D - 2);
        nouse = sort(nouse(1 : J-1));
        mouse{1} = 1 : nouse(1);
        for i = 2 : J-1
            mouse{i} = (nouse(i - 1) + 1) : nouse(i);
        end
        mouse{J} = (nouse(J-1) + 1) : D;

        % Implement ULS
        k = 1;

        for i = 1 : J

            temp = beta(mouse{i}, :);
            for j = 1 : length(mouse{i})
                temp_1 = temp(j, :);            
                U(:, k) =  temp_1(uni_array(:, i))';            
                k = k + 1;
            end

        end

    end
end

function uni_array = Uniform_array_generate(Q,J)
    
    uni_array(:,1)=1:Q;
    
    i = 2;
    for j=2:J
        if gcd(Q,i) ~= 1
           i =i + 1;   
        end
        uni_array(1,j) = i;
        i =i + 1;   
    end
    
    for i=2:Q
        for j=2:J
            
            if mod(i*uni_array(1,j),Q) == 0
                uni_array(i,j)= Q;
            else
                uni_array(i,j)= mod(i*uni_array(1,j),Q);
            end
        end
    end

end











