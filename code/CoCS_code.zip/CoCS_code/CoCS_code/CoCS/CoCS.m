function CoCS
% This is a simple demo of CoCS
%--------------------------------------------------------------------------------------------------------
% If you find this code useful in your work, please cite the 
% following paper "Peng H, Lu H, Deng C, et al. Enhancing cuckoo search algorithm with complement strategy. 
% International Journal of Innovative Computing and Applications".
%--------------------------------------------------------------------------------------------------------
% This function is implmented by Hua Lu
%--------------------------------------------------------------------------------------------------------
% More information can visit H Peng's homepage: https://whuph.github.io/index.html
%--------------------------------------------------------------------------------------------------------

tic; 
fprintf('Now is running CoCS\n');

fhd=str2func('cec13_func');
fun=1;
% for cec13_func
funopt = [-1400,-1300,-1200,-1100,-1000,-900,-800,-700,-600,-500,-400,-300,-200,-100,100,200,300,400,500,600,700,800,900,1000,1100,1200,1300,1400];
Xmin = [-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100];

%------------------- Parameter settings------------------------%

% This is a simple demo of CoCS
%--------------------------------------------------------------------------------------------------------
%--------------------------------------------------------------------------------------------------------
% This function is implmented by Hua Lu
tic;
n=30;
nd=30; 

%% Simple bounds of the search domain
lb=Xmin(fun);
ub=-lb;
% Lower bounds
Lb=lb*ones(1,nd); 
% Upper bounds
Ub=ub*ones(1,nd);

% Random initial solutions
for i=1:n
nest(i,:)=Lb+(Ub-Lb).*rand(size(Lb));
end

% Get the current best
fitness=10^10*ones(n,1);

[fmin,bestnest,nest,fitness]=get_best_nest(nest,nest,fitness,fhd, fun);
t=0;
G=25000;
outcome=[];
%% Starting iterations
while t<G
      t=t+1;
    % Generate new solutions (but keep the current best)
     new_nest=get_cuckoos(nest,bestnest,Lb,Ub,t,G,fitness);   
     [fnew,best,nest,fitness]=get_best_nest(nest,new_nest,fitness,fhd, fun);
     
     
     pa=0.25+normrnd(0,exp(-5*t/G));
    % Update the counter
    % Discovery and randomization
      new_nest=empty_nests(nest,Lb,Ub,pa) ;
    % Evaluate this set of solutions
      [fnew,best,nest,fitness]=get_best_nest(nest,new_nest,fitness,fhd, fun);
    % Find the best objective so far  
    if fnew<fmin
        fmin=fnew;
        bestnest=best;
    end
    
    outcome = [outcome fmin];
end %% End of iterations
GlobalMin=fmin-funopt(fun);
fprintf('best value=%d\n',GlobalMin);
CPUtime   = toc;
end

%% --------------- All subfunctions are list below ------------------
%% complement strategy
function nest=get_cuckoos(nest,best,Lb,Ub,t,G,fitness)
% complement strategy
n=size(nest,1);
beta=3/2;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
fmin=min(fitness);
fmax=max(fitness);
fs=rand;
for j=1:n
    s=nest(j,:);
    if fs>0.4
        u=randn(size(s))*sigma;
        v=randn(size(s));
        step=u./abs(v).^(1/beta);
        stepsize1=0.01*exp(-5*t/G).*step.*randn(size(s))+unifrnd(0,0.8,size(s)).*randn(size(s));
        s=s+stepsize1.*(s-best);
    else
        l1=randi(n);
        l2=randi(n);
        step2=((fitness(j)-fmin)/(fmax-fmin))*normrnd(0,0.15,size(s))*(exp(-2*t/G));
        s=s+step2.*(s+nest(l1,:)-nest(l2,:)-best);
    end
   % Apply simple bounds/limits
   nest(j,:)=simplebounds(s,Lb,Ub);
end
end

%% Find the current best nest
function [fmin,best,nest,fitness]=get_best_nest(nest,newnest,fitness,fhd, fun)
% Evaluating all new solutions
for j=1:size(nest,1)
    fnew=feval(fhd,newnest(j,:)',fun);
    if fnew<=fitness(j)
       fitness(j)=fnew;
       nest(j,:)=newnest(j,:);
    end
end
% Find the current best
[fmin,K]=min(fitness) ;
best=nest(K,:);
end

%% Replace some nests by constructing new solutions/nests
function new_nest=empty_nests(nest,Lb,Ub,pa)
% A fraction of worse nests are discovered with a probability pa
n=size(nest,1);
% Discovered or not -- a status vector
K=rand(size(nest))>pa;

%% New solution by biased/selective random walks
stepsize=(2*rand-1)*(nest(randperm(n),:)-nest(randperm(n),:));
new_nest=nest+stepsize.*K;
for j=1:n
    new_nest(j,:)=simplebounds(new_nest(j,:),Lb,Ub);
end
end

% Application of simple constraints
function s=simplebounds(s,Lb,Ub)
  % Apply the lower bound
  ns_tmp=s;
  I=ns_tmp<Lb;
  ns_tmp(I)=Lb(I);
  
  % Apply the upper bounds 
  J=ns_tmp>Ub;
  ns_tmp(J)=Ub(J);
  % Update this new move 
  s=ns_tmp;
end