Welcome to access Hu Peng's Homepage, https://whuph.github.io/index.html,
Our papers and codes are avaliable on the website. 

If you find this code useful in your work, please cite the 
following paper "Peng H, Lu H, Deng C, et al. 
Enhancing cuckoo search algorithm with complement strategy. 
International Journal of Innovative Computing and Applications".