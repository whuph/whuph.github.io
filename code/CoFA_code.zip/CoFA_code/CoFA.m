
function  CoFA
% This is a simple demo of CoFA
%--------------------------------------------------------------------------------------------------------
% If you find this code useful in your work, please cite the
% following paper "Peng H, Zhu W, Deng C, et al.
% Composite Firefly Algorithm For Breast Cancer Recognition
% Mechanism[J].Concurrency And Computation-Practice & Experience,2020,DOI:10.1002/cpe.6032"
%--------------------------------------------------------------------------------------------------------
% This function is implmented by Wenhua Zhu
%--------------------------------------------------------------------------------------------------------
clear;clc;
fprintf('Now is running CoFA\n');
format long;
format compact;

load breastcancerwisconsin.mat
A=breastcancerwisconsin;

A = A(all(~isnan(A),2),:);
[data_r, data_c] = size(A);
B=A(:,data_c);
A=A(:,1:data_c-1);
mapData=mapminmax(A',0,1);
data=[mapData',B];
nd=size(data,2)-1;
c=nd;
lb=zeros(1,nd);
ub=ones(1,nd);

warning('off')

global initial_flag
initial_flag = 0;

start=tic;
n = 20;
nfevalmax = 2E3;
outcome = [];
alpha=0.2;
gamma=1;
betamin=0.2;
beta0=1;
nfeval=0;
ratio=0;
pop=lhsdesign(n,nd).*(ones(n,1)*(ub-lb))+ones(n,1)*lb;

% Evaluate new solutions
Light=10^10*zeros(1,n);
GlobalMax=0;
for i=1:n
    if sum(round(pop(i,:)))>0
        allResult=KNN(round(pop(i,:)),data);
        Light(i)=allResult(1);
        if Light(i)>GlobalMax
            GlobalMax=Light(i);
            allEvaluate=allResult;
        end
    end
end

nfeval=nfeval+n;
G=50;
[~,bestid]=max(Light);
best=pop(bestid,:);
t=1;
while nfeval<nfevalmax &&t<G
    t=t+1;
    alpha=((1/9000)^(1/1000))*alpha;
    for i=1:n
        [set]=f(n,i);
        x1=set(1);
        x2=set(2);
        
        p=abs(GlobalMax)+abs(Light(x1))+abs(Light(x2));
        p1=abs(GlobalMax);
        F=(p1)/p;
        TX2=best+F.*(pop(x1,:)-pop(x2,:));
        TX=TX2;   
        r1 = norm(TX-pop(i,:));
        r2 = norm(best-pop(i,:));   
        beta=(betamin+(beta0-betamin)*exp(-gamma*r1^2));
        pop(i,:)=pop(i,:)+(TX-pop(i,:)).*beta+alpha.*(rand(1,nd)-0.5).*abs(ub-lb);
        pop(i,:) = ( (pop(i,:) >= lb) & (pop(i,:) <= ub) ) .* pop(i,:)...
            + (pop(i,:) < lb) .* ( lb + (ub-lb) .* rand(1,nd) )...
            + (pop(i,:) > ub) .* ( lb + (ub-lb) .* rand(1,nd) );
        
        if sum(round(pop(i,:)))>0
            allResult=KNN(round(pop(i,:)),data);
            Light(i)=allResult(1);
            nfeval=nfeval+1;
            if Light(i)>GlobalMax
                GlobalMax=Light(i);
                best=pop(i,:);
                allEvaluate=allResult;
                ratio=sum(round(pop(i,:)))/nd;
            end
        end       
    end   
    outcome = [outcome GlobalMax];
    
end   % end of iterations
CPUtime  = toc(start);
fprintf('best accuracy=%d\n',GlobalMax);
fprintf('runtime =%d\n',CPUtime);
end

function [set]=f(m,mo)
k=randperm(m);
set=[];
for i=1:5
    if (k(i))~=mo
        set=[set k(i)];
    end
end

end

function [allEvaluate]=KNN(pop,data)
warning('off')
tic;
[data_r, data_c] = size(data);

FeatIndex = find(pop==1);

indices = crossvalind('Kfold', data_r, 10);
ac=zeros(1,10);
pre=zeros(1,10);
reca=zeros(1,10);
spec=zeros(1,10);
fmea=zeros(1,10);
TP=0;
FN=0;
TN=0;
FP=0;
allEvaluate=zeros(1,5);
for k=1:1
    for i = 1 : 10
        test = (indices == i);
        
        train = ~test;
        
        test_data = data(test, 1 : data_c - 1);
        test_data=test_data(:,[FeatIndex]);
        test_label = data(test, data_c);
        
        train_data = data(train, 1 : data_c - 1);
        train_data = train_data(:,[FeatIndex]);
        train_label = data(train, data_c);
        
        
        mdl = ClassificationKNN.fit(train_data,train_label,'NumNeighbors',5);
        predict_label=predict(mdl, test_data);
        accuracy=length(find(predict_label == test_label))/length(test_label);
        
        for j=1:size(predict_label)
            if (predict_label(j,1)==2)
                if (test_label(j,1)==2)
                    TP=TP+1;
                else
                    FP=FP+1;
                end
            else
                if(test_label(j,1)==2)
                    FN=FN+1;
                else
                    TN=TN+1;
                end
            end
        end
        precision=TP/(TP+FP);
        recall=TP/(TP+FN);
        specificity=TN/(TN+FP);
        Fmeasure=2*(precision*recall)/(precision+recall);
        ac(i)=accuracy;
        pre(i)=precision;
        reca(i)=recall;
        spec(i)=specificity;
        fmea(i)=Fmeasure;
    end
    
    allEvaluate(1)=sum(ac)/10;
    allEvaluate(2)=sum(pre)/10;
    allEvaluate(3)=sum(reca)/10;
    allEvaluate(4)=sum(spec)/10;
    allEvaluate(5)=sum(fmea)/10;
    cputime=toc;
end

end




