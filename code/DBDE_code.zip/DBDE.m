function [GlobalMin, outcome, CPUtime, FEs] = DBDE(n,m,v,w,c,nfevalmax,bestval)
% 2015-3-27 programming by Hu Peng at WHU
    tic;

    D  = n;
    NP = 100;
    
    CR = 0.3;
    
    scheme=2;

    outcome = [];
    
    pop = round(rand(NP,D)); 
    val = zeros(1,NP);   
    nfeval=0;
    
    for i=1:NP;
        for j=1:m
            cons = sum( pop(i,:) .* w(j,:) );
            if cons>c(j)
                %scheme = fix(1+3*rand);
                pop(i,:)=repair(pop(i,:),v,w(j,:),c(j),scheme);
            end
        end
        
        val(i) = sum( pop(i,:) .* v );
        nfeval=nfeval+1;
        
        if val(i)==bestval
            FEs=nfeval;
            GlobalMin = bestval;
            outcome   = [outcome GlobalMin];
            CPUtime   = toc;
            return
        end
    end
    

    r = zeros(1,3);
    
    while nfeval <nfevalmax

        for i=1:NP
            rd=randperm(NP);
            for j=1:3
                if rd(j)~=i 
                    r(j)=rd(j);
                else
                    r(j)=rd(4);
                end
            end 
            tempx = pop(i, :);            
                       
            for j=1:D
                if  xor( pop(r(1),j), pop(r(2),j) ) == 1
                    if rand<0.5
                        tempx(j) =round(rand);
                    end
                else
                    if rand<0.2 
                        tempx(j) =pop(r(1),j);
                    end
                end
            end
            
            for j=1:m
                cons = sum( tempx .* w(j,:) );            
                if cons>c(j)
                    %scheme = fix(1+3*rand);
                    tempx=repair(tempx,v,w(j,:),c(j),scheme);
                end
            end

            tempval = sum( tempx .* v );
            nfeval  = nfeval + 1;

            if tempval > val(i)
                val(i)   = tempval;
                pop(i,:) = tempx;
                
                if tempval==bestval
                    FEs=nfeval;
                    GlobalMin = bestval;
                    outcome   = [outcome GlobalMin];
                    CPUtime   = toc;
                    return
                end
            end
            
        end %--for i=1:NP
        
        GlobalMin = max(val);
        outcome   = [outcome GlobalMin];       

    end %--while nfeval <nfevalmax

    CPUtime   = toc;
    FEs=nfevalmax;

end

function p= repair(p,v,w,c,scheme)
    
    if scheme == 1 
        % Profit-greedy repair
        [~,ind]=sort(v);        
    elseif scheme == 2
        % Ratio-greedy repair
        [~,ind]=sort(v./w);        
    elseif scheme ==3
        % Random repair
        ind = randperm(length(p));
    end
    
    cons = sum(p.*w);
    i = 1;
    while cons>c
        p(ind(i))=0;
        i=i+1;
        cons = sum(p.*w);
    end

end

