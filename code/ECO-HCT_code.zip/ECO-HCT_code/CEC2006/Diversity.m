% Calculate the diversity and optimal fitness value of the population
% output��
% DI: diversity of population 
% Fbest: optimal fitness value of the population
function [DI,Fbest]=Diversity(x,fit,lu)
% Calculate diversity of the population
[popsize,n]=size(x);
DI=1/n*sum((std(x)./(lu(2,:)-lu(1,:))),2);
% Calculate optimal fitness value of the population
percent=length(find(fit(:,2)==0))/popsize;
if percent>0
    index=find(fit(:,2)==0);
    Fbest=min(fit(index,1));
else
    [~,index]=min(fit(:,2));
    Fbest=fit(index,1);
end
end