function [x,fit]=feasible(x,fit,mu)
[~,fitIndex]=sort(fit(:,1));
x=x(fitIndex(1:mu),:);
fit=fit(fitIndex(1:mu),:);
end