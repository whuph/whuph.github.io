function [x,fit,A_1,fitA_1]=infeasible(x,fit,parentN,A_1,fitA_1,gen,total_gen)
if ~isempty(A_1)
    % Calculate the size of the Archive A_1 and the size of population X
    total_num=size(A_1,1);
    pop_x=size(x,1);
    rand_num=randi([1,total_num],1,1);
    ind_index=zeros(1,rand_num);
    temp_index=(1:total_num);
    for i=1:rand_num
        position=floor(total_num*rand)+1;
        ind_index(i)=temp_index(position);
        temp_index(position)=[];
        total_num=total_num-1;
    end
    x(((pop_x+1):(pop_x+rand_num)),:)=A_1(ind_index,:);
    fit(((pop_x+1):(pop_x+rand_num)),:)=fitA_1(ind_index,:);
end

[popsize,n]=size(x);

index_num=1:popsize;
% Record the number of individuals that each individual can Pareto dominated
S = zeros(popsize,1);
for i=1:popsize
    S(i)=size(find((fit(i, 1)<=fit(:, 1)) & (fit(i, 2)<=fit(:, 2)) & ((fit(i, 1)<fit(:, 1)) | (fit(i, 2) < fit(:, 2)))),1);
end

R=zeros(popsize,1);
for i=1:popsize
    r_index=find((fit(i, 1)>=fit(:, 1)) & (fit(i, 2)>=fit(:, 2)) & ((fit(i, 1)>fit(:, 1)) | (fit(i, 2) > fit(:, 2))));
    R(i)=sum(S(r_index),1);
end

Rmax=max(R);
Rmin=min(R);
Rstd=(R-Rmin)./(Rmax-Rmin+1E-30);

[~,Ranking_1]=sort(fit(:,1));
[~,Ranking_2]=sort(fit(:,2));
Rank_1=ones(popsize,1);
Rank_2=ones(popsize,1);
for i=1:popsize
    Rank_1(i)=find(Ranking_1==i);
    Rank_2(i)=find(Ranking_2==i); 
end

Gmax=max(fit(:,2));
Gmin=min(fit(:,2));
gnor=(fit(:,2)-Gmin)/(Gmax-Gmin+1E-30);
Ffinally=Rank_2./popsize+Rstd+gnor;

F_=zeros(parentN,1);
Index_finally=[];
for i=1:parentN
    Index=[i;parentN+3*(i-1)+1;parentN+3*(i-1)+2;parentN+3*(i-1)+3];
    [~,index]=min(Ffinally(Index));
    Index_finally=[Index_finally;Index(index)];
end
% Dynamically adjust the rate
omega_min=0.2;
omega_max=0.8;
bili=omega_min+(gen/total_gen)*(omega_max-omega_min);

P=floor(parentN*bili)+1;
[~,temp_index]=sort(Ffinally(Index_finally));
Index_finally=Index_finally(temp_index);
Index_finally=Index_finally(1:(parentN-P));
index_num(Index_finally)=[];
% Add the selected individual information to next_x
temp_x=x;
temp_fit=fit;
next_x=zeros(parentN,n);
next_fit=zeros(parentN,2);

next_x((1:(parentN-P)),:)=x(Index_finally,:);
next_fit((1:(parentN-P)),:)=fit(Index_finally,:);
F_((1:(parentN-P)))=Ffinally(Index_finally);
% Delete the selected individual information
temp_x(Index_finally,:)=[];
temp_fit(Index_finally,:)=[];
Ffinally(Index_finally)=[];
% The selected individuals enter the next generation population.
[~,temp_index_2]=sort(Ffinally);
temp_index_2=temp_index_2(1:P);
F_((parentN-P+1:parentN))=Ffinally(temp_index_2);
next_x((parentN-P+1:parentN),:)=temp_x(temp_index_2,:);
next_fit((parentN-P+1:parentN),:)=temp_fit(temp_index_2,:);
x=next_x;
fit=next_fit;
% sort the individuals in population x according to the degree of constraint violation
[~,temp_index_3]=sort(F_);
x=x(temp_index_3,:);
fit=fit(temp_index_3,:);
% Add the remaining unselected individuals to Archive A_1.
temp_x(temp_index_2,:)=[];
temp_fit(temp_index_2,:)=[];
A_1=temp_x;
fitA_1=temp_fit;
end