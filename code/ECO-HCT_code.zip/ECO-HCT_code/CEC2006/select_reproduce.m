function [temp_x]=select_reproduce(x,fit,lu,n,parentN,gen,total_gen)
F=0.8;
CR=0.9;
Fbest=1;
temp_x=zeros(parentN*3,n);

if gen<(total_gen*2/5)
    %%  rand/1  rand/2  current-to-rand/1
    for i=1:parentN
        for j=1:3
            rand_=rand;
            if rand_<1/3
                %% rand/1
                nouse_=1:parentN;
                nouse_(i)=[];

                temp=floor(rand*(parentN-1))+1;
                nouse(1)=nouse_(temp);
                nouse_(temp)=[];

                temp=floor(rand*(parentN-2))+1;
                nouse(2)=nouse_(temp);
                nouse_(temp)=[];

                temp=floor(rand*(parentN-3))+1;
                nouse(3)=nouse_(temp);
                
                v1=x(nouse(1),:)+F.*(x(nouse(2),:)-x(nouse(3),:));
            elseif rand_<2/3
                %% rand/2
                nouse_=1:parentN;
                nouse_(i)=[];

                temp=floor(rand*(parentN-1))+1;
                nouse(1)=nouse_(temp);
                nouse_(temp)=[];

                temp=floor(rand*(parentN-2))+1;
                nouse(2)=nouse_(temp);
                nouse_(temp)=[];

                temp=floor(rand*(parentN-3))+1;
                nouse(3)=nouse_(temp);
                nouse_(temp)=[];
                
                temp=floor(rand*(parentN-4))+1;
                nouse(4)=nouse_(temp);
                nouse_(temp)=[];
                
                temp=floor(rand*(parentN-5))+1;
                nouse(5)=nouse_(temp);
                
                v1=x(nouse(1),:)+F.*(x(nouse(2),:)-x(nouse(3),:))+F.*(x(nouse(4),:)-x(nouse(5),:));
            else
                %% current-to-rand/1
                nouse_=1:parentN;
                nouse_(i)=[];

                temp=floor(rand*(parentN-1))+1;
                nouse(1)=nouse_(temp);
                nouse_(temp)=[];

                temp=floor(rand*(parentN-2))+1;
                nouse(2)=nouse_(temp);
                nouse_(temp)=[];

                temp=floor(rand*(parentN-3))+1;
                nouse(3)=nouse_(temp);
                
                v1=x(i,:)+F.*(x(nouse(3),:)-x(i,:))+F.*(x(nouse(1),:)-x(nouse(2),:));
            end
            w=find(v1<lu(1,:));
                if ~isempty(w)
                    v1(1,w)=2.*lu(1,w)-v1(1,w);
                    w1=find(v1(1,w)>lu(2,w));
                    if ~isempty(w1)
                        v1(1,w(w1))=lu(2,w(w1));
                    end
                end

                y=find(v1>lu(2,:));
                if ~isempty(y)
                    v1(1,y)=2.*lu(2,y)-v1(1,y);
                    y1=find(v1(1,y)<lu(1,y));
                    if ~isempty(y1)
                        v1(1,y(y1))=lu(1,y(y1));
                    end
                end

                
                j_rand=floor(rand*n)+1;
                t=rand(1,n)<CR;
                
                t(1,j_rand)=1;
                t_=1-t;
                u1=t.*v1+t_.*x(i,:);
                temp_x(3*i-3+j,:)=u1;
        end
    end

elseif gen<(total_gen*4/5)
    %% current-to-rand/1 rand-to-best/1 rand/1
    for i=1:parentN
        for j=1:3
            rand_=rand;
            if rand_<1/3
                %% current-to-rand/1
                nouse_=1:parentN;
                nouse_(i)=[];

                temp=floor(rand*(parentN-1))+1;
                nouse(1)=nouse_(temp);
                nouse_(temp)=[];

                temp=floor(rand*(parentN-2))+1;
                nouse(2)=nouse_(temp);
                nouse_(temp)=[];

                temp=floor(rand*(parentN-3))+1;
                nouse(3)=nouse_(temp);
                
                v1=x(i,:)+F.*(x(nouse(3),:)-x(i,:))+F.*(x(nouse(1),:)-x(nouse(2),:)); 
                % u1=v1;
            elseif rand_<2/3
                %% rand-to-best/1
                nouse_=1:parentN;
                nouse_(i)=[];

                temp=floor(rand*(parentN-1))+1;
                nouse(1)=nouse_(temp);
                nouse_(temp)=[];

                temp=floor(rand*(parentN-2))+1;
                nouse(2)=nouse_(temp);
                nouse_(temp)=[];

                temp=floor(rand*(parentN-3))+1;
                nouse(3)=nouse_(temp);
               
                v1=x(nouse(1),:)+F.*(x(Fbest,:)-x(nouse(1),:))+F.*(x(nouse(2),:)-x(nouse(3),:));
            else
                %% rand/1
                nouse_=1:parentN;
                nouse_(i)=[];

                temp=floor(rand*(parentN-1))+1;
                nouse(1)=nouse_(temp);
                nouse_(temp)=[];

                temp=floor(rand*(parentN-2))+1;
                nouse(2)=nouse_(temp);
                nouse_(temp)=[];

                temp=floor(rand*(parentN-3))+1;
                nouse(3)=nouse_(temp);
               
                v1=x(nouse(1),:)+F.*(x(nouse(2),:)-x(nouse(3),:));
            end
                 w=find(v1<lu(1,:));
                if ~isempty(w)
                    v1(1,w)=2.*lu(1,w)-v1(1,w);
                    w1=find(v1(1,w)>lu(2,w));
                    if ~isempty(w1)
                        v1(1,w(w1))=lu(2,w(w1));
                    end
                end

                y=find(v1>lu(2,:));
                if ~isempty(y)
                    v1(1,y)=2.*lu(2,y)-v1(1,y);
                    y1=find(v1(1,y)<lu(1,y));
                    if ~isempty(y1)
                        v1(1,y(y1))=lu(1,y(y1));
                    end
                end

                
                j_rand=floor(rand*n)+1;
                t=rand(1,n)<CR;
                
                t(1,j_rand)=1;
                t_=1-t;
                u1=t.*v1+t_.*x(i,:);
                temp_x(3*i-3+j,:)=u1;
        end
    end
else
    %% current-to-best/1��best/1 or best/2
    for i=1:parentN
        for j=1:3
            rand_=rand;
            if rand_<2/5
                %% current-to-best
                nouse_=1:parentN;
                nouse_(i)=[];

                temp=floor(rand*(parentN-1))+1;
                nouse(1)=nouse_(temp);
                nouse_(temp)=[];

                temp=floor(rand*(parentN-2))+1;
                nouse(2)=nouse_(temp);
                
                v1=x(i,:)+F.*(x(Fbest,:)-x(i,:))+F.*(x(nouse(1),:)-x(nouse(2),:)); 
            elseif rand_<4/5
                %% current-to-rand/1
                nouse_=1:parentN;
                nouse_(i)=[];

                temp=floor(rand*(parentN-1))+1;
                nouse(1)=nouse_(temp);
                nouse_(temp)=[];

                temp=floor(rand*(parentN-2))+1;
                nouse(2)=nouse_(temp);
                nouse_(temp)=[];

                temp=floor(rand*(parentN-3))+1;
                nouse(3)=nouse_(temp);
  
                v1=x(i,:)+F.*(x(nouse(3),:)-x(i,:))+F.*(x(nouse(1),:)-x(nouse(2),:));
            else
                  %% rand/1
                nouse_=1:parentN;
                nouse_(i)=[];

                temp=floor(rand*(parentN-1))+1;
                nouse(1)=nouse_(temp);
                nouse_(temp)=[];

                temp=floor(rand*(parentN-2))+1;
                nouse(2)=nouse_(temp);
                nouse_(temp)=[];

                temp=floor(rand*(parentN-3))+1;
                nouse(3)=nouse_(temp);

                v1=x(nouse(1),:)+F.*(x(nouse(2),:)-x(nouse(3),:));
            end
                w=find(v1<lu(1,:));
                if ~isempty(w)
                    v1(1,w)=2.*lu(1,w)-v1(1,w);
                    w1=find(v1(1,w)>lu(2,w));
                    if ~isempty(w1)
                        v1(1,w(w1))=lu(2,w(w1));
                    end
                end

                y=find(v1>lu(2,:));
                if ~isempty(y)
                    v1(1,y)=2.*lu(2,y)-v1(1,y);
                    y1=find(v1(1,y)<lu(1,y));
                    if ~isempty(y1)
                        v1(1,y(y1))=lu(1,y(y1));
                    end
                end

                j_rand=floor(rand*n)+1;
                t=rand(1,n)<CR;
                
                t(1,j_rand)=1;
                t_=1-t;
                u1=t.*v1+t_.*x(i,:);
                temp_x(3*i-3+j,:)=u1;
        end
    end                
end