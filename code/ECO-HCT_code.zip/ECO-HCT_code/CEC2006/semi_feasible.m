function [x,fit,A_2,fitA_2,flag]=semi_feasible(x,fit,parentN,A_2,fitA_2,flag)
if~isempty(A_2)
    if size(A_2,1)>=40
        popsize_A=size(A_2,1);
        popsize_x=size(x,1);
        x(popsize_x+1:popsize_x+popsize_A,:)=A_2;
        fit(popsize_x+1:popsize_x+popsize_A,:)=fitA_2;
        A_2=[];
        fitA_2=[];
    end
end


[popsize,n]=size(x);
next_x=zeros(popsize,n);
next_fit=zeros(popsize,2);

percent=length(find(fit(:,2)==0))/popsize;

fea_index=find(fit(:,2)==0);

[~,temp_index]=sort(fit(fea_index,1));
fea_index=fea_index(temp_index);

count=floor(length(find(fit(:,2)==0))*(1-percent))+1;
fea_index=fea_index(1:count);

next_x((1:count),:)=x(fea_index,:);
next_fit((1:count),:)=fit(fea_index,:);

x(fea_index,:)=[];
fit(fea_index,:)=[];

Z_1=find(fit(:,2)==0);
Z_2=find(fit(:,2)>0);
if ~isempty(Z_1)
    %% scheme 2
    if flag==1

    Fmax=max(fit(:,1));
    Fmin=min(fit(:,1));   
    fnor=(fit(:,1)-Fmin)/(Fmax-Fmin+1E-30);  
    Gmax=max(fit(:,2));
    Gmin=min(fit(:,2));
    gnor=(fit(:,2)-Gmin)/(Gmax-Gmin+1E-30);
    
    Ffinally(Z_1)=fnor(Z_1);
    Ffinally(Z_2)=percent*fnor(Z_2)+(1-percent)*gnor(Z_2)+sqrt(fnor(Z_2).^2+gnor(Z_2).^2);
    [~,temp_index]=sort(Ffinally);
    x=x(temp_index,:);
    fit=fit(temp_index,:);
    next_x(((count+1):popsize),:)=x;
    next_fit(((count+1):popsize),:)=fit;
    else
        %% scheme 3
    Fmax=max(fit(:,1));
    Fmin=min(fit(Z_1,1));
    fnor=max((fit(:,1)-Fmin)/(Fmax-Fmin+1E-30),0);
    gnor=fit(:,2);
    
    Ffinaly=fnor+gnor;
    [~,index_2]=sort(Ffinaly);
    x=x(index_2,:);
    fit=fit(index_2,:);
    next_x(((count+1):popsize),:)=x;
    next_fit(((count+1):popsize),:)=fit;
    end
else
    %% scheme 1
    Gmax=max(fit(:,2));
    Gmin=min(fit(:,2));
    gnor=(fit(:,2)-Gmin)/(Gmax-Gmin+1E-30);
    Fmax=max(fit(:,1));
    Fmin=min(fit(:,1));
    fnor=(fit(:,1)-Fmin)/(Fmax-Fmin+1E-30);

    Ffinaly=percent*fnor+(1-percent)*gnor;
    [~,index_3]=sort(Ffinaly);
    x=x(index_3,:);
    fit=fit(index_3,:);
    next_x(((count+1):popsize),:)=x;
    next_fit(((count+1):popsize),:)=fit;
end
x=next_x((1:parentN),:);
fit=next_fit((1:parentN),:);

next_x(1:parentN,:)=[];
next_fit(1:parentN,:)=[];
[~,index_f]=min(next_fit(:,1));
[~,index_g]=min(next_fit(:,2));
A_2=[A_2;next_x(index_f,:)];
fitA_2=[fitA_2;next_fit(index_f,:)];
A_2=[A_2;next_x(index_g,:)];
fitA_2=[fitA_2;next_fit(index_g,:)];

end