function [x,fit]=feasible(x,fit,parentN)
[~,fitIndex]=sort(fit(:,1));
x=x(fitIndex(1:parentN),:);
fit=fit(fitIndex(1:parentN),:);
end