function [x,fit,DI,Fbest]=restart(x,fit,parentN,lu,DI,Fbest,problem)
% Calculate the diversity and optimal fitness value of the population
[popsize,n]=size(x);
DI_new=1/n*sum((std(x)./(lu(2,:)-lu(1,:))),2);

percent=length(find(fit(:,2)==0))/popsize;
if percent>0
    index=find(fit(:,2)==0);
    Fbest_=min(fit(index,1));
else
    [~,index]=min(fit(:,2));
    Fbest_=fit(index,1);
end
delta_D=DI-DI_new;
delta_F=Fbest-Fbest_;

if ((delta_D<0.0001) && (delta_F<0.00005))
    bili=0.1;

    count_num=floor(bili*parentN)+1;
    S = zeros(popsize,1);
    for i=1:popsize
        S(i)=length(find((fit(i, 1)<=fit(:, 1)) & (fit(i, 2)<=fit(:, 2)) & ((fit(i, 1)<fit(:, 1)) | (fit(i, 2) < fit(:, 2)))));
    end
    R=zeros(popsize,1);
    for i=1:popsize
        r_index=find((fit(i, 1)>=fit(:, 1)) & (fit(i, 2)>=fit(:, 2)) & ((fit(i, 1)>fit(:, 1)) | (fit(i, 2) > fit(:, 2))));
        R(i)=sum(S(r_index));
    end
    
    Rmax=max(R);
    Rmin=min(R);
    Rstd=(R-Rmin)./(Rmax-Rmin+1E-30);
    
    [~,Ranking_1]=sort(fit(:,1));
    [~,Ranking_2]=sort(fit(:,2));
    Rank_1=ones(popsize,1);
    Rank_2=ones(popsize,1);
    for i=1:popsize
        Rank_1(i)=find(Ranking_1==i);
        Rank_2(i)=find(Ranking_2==i); 
    end
    
    Ffinally=Rank_2./popsize+Rstd+fit(:,2);
    
    [~,index]=sort(Ffinally);
    x=x(index,:);
    fit=fit(index,:);
    
    temp_X=ones(count_num,1)*lu(1,:)+rand(count_num,n).*(ones(count_num,1)*(lu(2,:)-lu(1,:)));
    [temp_Fit(:,1), temp_Fit(:,2)] = fitness_wbc(temp_X,problem);

    x((parentN-count_num+1:parentN),:)=temp_X;
    fit((parentN-count_num+1:parentN),:)=temp_Fit;
end

DI=DI_new;
Fbest=Fbest_;

end