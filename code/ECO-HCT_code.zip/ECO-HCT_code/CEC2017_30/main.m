clc;
clear all;
tic;
'ECO-HCT'
format long;
format compact;
rand('seed',sum(100*clock));

problem_index = 1:28;
all_data_1=zeros(25,25+5);          
all_data_2=zeros(25,25+5);          

global initial_flag;

for problem_sel = 1:25
    problem = problem_index(problem_sel);           
    fprintf("problem=%d\n",problem);
    n=30;
     % get parameters
    [lu(1,:),lu(2,:)] = problemSelection2017(problem,n);
    parentN=40;                              
    offsprintN=3*parentN; 
    % the maximum number of the fitness evaluations(FES)
    MAX_FES=20000*n;                   
    % the array used to store the objective function values of the best individuals in the final parent population in each run
    outcome_1=[];
    % the array used to store the feasibility proportion of the final parent population in each run
    outcome_2=[];
    % the total number of generations in each run
    total_gen=ceil(MAX_FES/offsprintN)+1;  
    % the total number of the independent runs
    total_time=25;      
    % initialize the value of the variable 'time'
    time=1;                             
    % do total_gen independent runs
    while time<=total_time 
        fprintf('time=%d\n',time);
        % generate the initial population
        x=ones(parentN,1)*lu(1,:)+rand(parentN,n).*(ones(parentN,1)*(lu(2,:)-lu(1,:)));   
        initial_flag = 0;
        % initialize the value of the variable 'gen'
        gen=1;                      
        % evaluate the initial population and compute the degree of the constraint violation
        [fit(:,1), fit(:,2)] = fitness_wbc(x,problem);
        % Calculate the diversity and optimal fitness value of the population
        [DI,Fbest]=Diversity(x,fit,lu);  
        % Calculate the Feasible rate of the Initial Population
        percent=length(find(fit(:,2)==0))/parentN;   
        FES=parentN;
        % Archive A_1 for infeasible situation 
        A_1=[];
        fitA_1=[];
        % Archive A_2 for semi-feasible situation 
        A_2=[];
        fitA_2=[];
        % semi-feasible situation conversion fla
        flag=1;
        percent_old=percent;
        
        if percent==0
            [~,index]=min(fit(:,2));
            best_old=fit(index,1);
        else
            index=find(fit(:,2)==0);
            best_old=min(fit(index,1));
        end
        
        while FES<=MAX_FES
            % generate an offspring population from the parent population by DE
            temp_x=select_reproduce(x,fit,lu,n,parentN,gen,total_gen);
            % evaluate the offspring population
            [temp_fit(:,1), temp_fit(:,2)] = fitness_wbc(temp_x,problem);
            % modify the value of FES
            FES=FES+offsprintN;
            % combine the parent population and the offspring population
            x((parentN+1):(parentN+offsprintN),:)=temp_x;
            fit((parentN+1):(parentN+offsprintN),:)=temp_fit;
            % Calculate the Feasible rate of the Combined Population
            combination_num=size(fit,1);
            percent=length(find(fit(:,2)==0))/combination_num;
            %% HCT
            % infeasible situation
            if percent==0
                [x,fit,A_1,fitA_1]=infeasible(x,fit,parentN,A_1,fitA_1,gen,total_gen);
                [x,fit,DI,Fbest]=restart(x,fit,parentN,lu,DI,Fbest,problem);
            % semi-feasible situation
            elseif percent>0 && percent<1             
                [x,fit,A_2,fitA_2,flag]=semi_feasible(x,fit,parentN,A_2,fitA_2,flag);               
                percent=size(find(fit(:,2)==0),1)/parentN;                
                if (percent<percent_old && (best_old-min(fit(find(fit(:,2)==0),1)))<=0.0001) || mod(gen,5)
                    flag=-flag;
                end                
                percent_old = percent;  
                best_old = min(fit(find(fit(:,2)==0),1));
            % feasible situation
            else
                [x,fit]=feasible(x,fit,parentN);
            end                   
            gen=gen+1;                  
        end
                
        num_3=find(fit(:,2)==0);       
        
       
        if ~isempty(num_3)              
            outcome_1=[outcome_1 min(fit(num_3,1))];
            percent = length(num_3) / size(fit,1);      
            outcome_2=[outcome_2 percent]; 
        else
            [m_,n_]=min(fit(:,2));
            outcome_1=[outcome_1 fit(n_,1)];
            outcome_2=[outcome_2 0];
        end
        time=time+1;
    end
    
    all_outcome_2 = outcome_2
    
    all_data_2(problem,1:total_time)=all_outcome_2;

    max_outcome_2 = max(outcome_2);

    min_outcome_2 = min(outcome_2);

    median_outcome_2 = median(outcome_2);

    mean_outcome_2 = mean(outcome_2);

    std_outcome_2 = std(outcome_2);
    
    all_data_2(problem,total_time+1:total_time+5)=[max_outcome_2 min_outcome_2 median_outcome_2 mean_outcome_2 std_outcome_2];
    
    %all the value of the objective function of the best individuals in the final population

    all_outcome_1 = outcome_1
    
    all_data_1(problem,1:total_time)=all_outcome_1;
    %the maximum value

    max_outcome_1 = max(outcome_1)
    %the minimum value

    min_outcome_1 = min(outcome_1)
    %the median value

    median_outcome_1 = median(outcome_1)
    %the mean value

    mean_outcome_1 = mean(outcome_1)
    %the standard value

    std_outcome_1 = std(outcome_1)
    
    all_data_1(problem,total_time+1:total_time+5)=[max_outcome_1 min_outcome_1 median_outcome_1 mean_outcome_1 std_outcome_1];
end

run_time = toc
