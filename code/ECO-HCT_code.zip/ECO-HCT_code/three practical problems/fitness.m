% evaluate all the individuals in the population p, and return its values of
% the fitness function, and the degree of the inequality and equality
% constraint violation

function [fit,g,h] = fitness(p,problem,delta,A)

%% input parameters
% p -- the population evaluated
% problem -- the problem tested
% delta -- the tolerance value
% A -- the array of parameters p,q,r
%% output parameters
% fit -- values of fitness functions and degree of constraint violation
% g -- degree of the inequality constraint violations
% h -- degree of the equality constraint violations

%compute the size of the population p
popsize=size(p,1);

%initialize the set fit
fit=zeros(popsize,2);

%initialize the set of degree of equality constraint violations
h=[];

%initialize the set of degree of inequality constraint violations
g=[];

%choose the problem
switch problem
    
    case 1
        g(:,1)=1-((p(:,2).^3 .* p(:,3))./ (71785.*(p(:,1).^4)));
        g(:,2)=(4.*(p(:,2).^2) - p(:,1).*p(:,2))./(12566.*(p(:,2).* (p(:,1).^3) - p(:,1).^4)) + 1./(5108.*(p(:,1).^2)) -1;
        g(:,3)=1 - (140.45.*p(:,1))./((p(:,2).^2) .* p(:,3));
        g(:,4)=(p(:,1)+p(:,2))./1.5 -1;
        
        f1=(p(:,3) + 2).*p(:,2).* p(:,1).^2;
        
        
        f2=sum(max(0,g)./(ones(popsize,1)*(max(max(0,g))+1E-30)),2)./size(g,2);
        
        
    case 2
        g(:,1) = 27./(p(:,1).* (p(:,2).^2).* p(:,3)) -1;
        g(:,2) = 397.5./(p(:,1) .* (p(:,2).^2).* (p(:,3).^2)) -1;
        g(:,3) = 1.93.* (p(:,4).^3) ./(p(:,2).* p(:,3).* (p(:,6).^4)) -1;
        g(:,4) = 1.93.* (p(:,5).^3) ./(p(:,2).* p(:,3).* (p(:,7).^4)) -1;
        g(:,5) = sqrt(((745.* p(:,4)./(p(:,2).* p(:,3))).^2) + 16.9E6)./ (110.* (p(:,6).^3)) -1;
        g(:,6) = sqrt(((745.* p(:,5)./(p(:,2).* p(:,3))).^2) + 157.5E6)./ (85.* (p(:,7).^3)) -1;
        g(:,7) = (p(:,2).* p(:,3))./ 40 -1;
        g(:,8) = (5.*p(:,2))./p(:,1) -1;
        g(:,9) = p(:,1)./(12.*p(:,2)) -1;
        g(:,10) = (1.5.* p(:,6)+1.9)./p(:,4) -1;
        g(:,11) = (1.1.*p(:,7) +1.9)./p(:,5) -1;
        
        f1 = 0.7854.*p(:,1).*(p(:,2).^2).*(3.3333.*(p(:,3).^2) +14.9334.*p(:,3) -43.0934 )...
            -1.508.*p(:,1).*((p(:,6).^2)+(p(:,7).^2))+7.4777.*((p(:,6).^3)+(p(:,7).^3))...
            +0.7854.*(p(:,4).*(p(:,6).^2) + p(:,5).*(p(:,7).^2));
        
        f2=sum(max(0,g)./(ones(popsize,1)*(max(max(0,g))+1E-30)),2)./size(g,2);
        
    case 3
        g(:,1)=2.*(sqrt(2).*p(:,1)+p(:,2))./(sqrt(2).*p(:,1).^2+2.*p(:,1).*p(:,2))-2;
        g(:,2)=2.*p(:,2)./(sqrt(2).*p(:,1).^2+2.*p(:,1).*p(:,2))-2;
        g(:,3)=2./(sqrt(2).*p(:,2)+p(:,1))-2;
        
        f1=100.*(2.*sqrt(2).*p(:,1)+p(:,2));        
        f2=sum(max(0,g),2);
end

%save the values obtained
fit(1:popsize,1)=f1;
fit(1:popsize,2)=f2;