function [lu,n,A]=practical(problem)
    switch problem
     
        case 1 % The tension/compression spring design problem\\0.012665232
            lu=[0.05 0.25 2;2 1.3 15];
            n=3;A=[];     
        case 2 % The speed reducer design problem\\2994.4710661
            lu=[2.6 0.7 17 7.3 7.3 2.9 5.0;3.6 0.8 28 8.3 8.3 3.9 5.5];
            n=7;A=[];       
        case 3 % The three-bar truss design problem\\263.8958434
            lu=[0 0;1 1];
            n=2;A=[];%\\263.895843
            
    end

end