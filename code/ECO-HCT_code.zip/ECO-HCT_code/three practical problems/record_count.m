function [flag_1]=record_count(x,fit,problem)
flag_1=0;
[popsize,~]=size(x);
percent=length(find(fit(:,2)==0))/popsize;      
switch problem
    
        
    case 1
        know_best=0.012665232;
        
    case 2
        know_best=2994.4710661;
        
    case 3
        know_best=263.8958434;
end
if percent == 0
    [~,temp_best_index] = min(fit(:,2));
    temp_best_ = fit(temp_best_index,1);
else
    temp_best_ = min(fit(find(fit(:,2)==0),1));
end
if abs(temp_best_-(know_best))<0.000001
    flag_1=1;
end


end