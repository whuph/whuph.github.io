function FACL
% This is a simple demo of FA-CL
%--------------------------------------------------------------------------------------------------------
% If you find this code useful in your work, please cite the 
% following paper by the author of the code "Peng H, Zhu W, Deng C, Wu Z. 
% Enhancing Firefly Algorithm with Courtship Learning[J]. Information Sciences, 2020, 543:18-42"
%--------------------------------------------------------------------------------------------------------
% This function is implmented by Wenhua Zhu
%--------------------------------------------------------------------------------------------------------
    clear;clc;
    fprintf('Now is running FA-CL\n');
    %% Parameter setting for test function
    addpath('../TestFunction');
    fhd=str2func('cec13_func'); % two parameters can be set, cec13_func or yao_13
    fun=1;
    % for cec13_func
    funopt = [-1400,-1300,-1200,-1100,-1000,-900,-800,-700,-600,-500,-400,-300,-200,-100,100,200,300,400,500,600,700,800,900,1000,1100,1200,1300,1400];
    Xmin = [-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100];
    Xmax  = -Xmin;
    
    %% Parameter setting for algorithm
    D=30;%dimension of firefly
    n = 20;%pop size
    nfevalmax = 5E5;%  maximum number of evaluate
    ub=Xmax(fun);
    lb=Xmin(fun);
    
alpha=0.5;
gamma=1/(ub-lb)^2;
beta0=1;
betamin=0.2;
nfeval=0;
N=20;%the size of female archive
pop = lb + rand(n,D).*(ub - lb);% generate the population randomly

% Evaluate new solutions
Light=zeros(1,n);
for i=1:n 
    Light(i)  = feval(fhd,pop(i,:)',fun);    
end
nfeval=nfeval+n;

femaleArchive=pop;%initialize the female archive
femaleLight=Light;%initialize the female fitness in archive;

%evaluate the initial selection probability of female in archive;eq.6 and eq.7
c=zeros(N,D);
d=zeros(1,N);
value=zeros(1,N);
[a,b]=sort(femaleLight);
for i=1:N
    c(i,:)=femaleArchive(b(i),:);
    d(i)=a(i);
    value(i)=1/d(i);
end
p=value/sum(value,2);  %selection probability

[GlobalMin,~]=min(Light);

t=0;
G=fix(nfevalmax/n);
while nfeval<nfevalmax && t<G
    t=t+1;
    for i=1:n
        for j=1:n            
            if Light(i)>Light(j)
                r = norm(pop(i,:)-pop(j,:));
                beta=beta0*exp(-gamma*r^2);                         
                pop(i,:)=pop(i,:)+(pop(j,:)-pop(i,:)).*beta+alpha.*(rand(1,D)-0.5);%ө����˶���ʽ
                

                pop(i,:) = ( (pop(i,:) >= lb) & (pop(i,:) <= ub) ) .* pop(i,:)...
                       + (pop(i,:) < lb) .* ( lb + (ub-lb) .* rand(1,D) )...
                       + (pop(i,:) > ub) .* ( lb + (ub-lb) .* rand(1,D) );

                Light(i)  = feval(fhd,pop(i,:)',fun);
                nfeval=nfeval+1;
            else
               %use roulettle aglorthim to select female
                f=Roulettle(p);
                if Light(j)>d(f)
                r = norm(c(f,:)-pop(j,:));
               beta=(betamin+(beta0-betamin)*exp(-gamma*r^2));
               %eq.8 and eq.9
                m=1/800;
                v=r*m*(logsig(-beta)^(t/600));
                pop(j,:)=pop(j,:)+(v).*(c(f,:)-pop(j,:))+alpha.*(rand(1,D)-0.5).*abs(ub-lb);
                pop(j,:) = ( (pop(j,:) >= lb) & (pop(j,:) <= ub) ) .* pop(j,:)...
                       + (pop(j,:) < lb) .* ( lb + (ub-lb) .* rand(1,D) )...
                       + (pop(j,:) > ub) .* ( lb + (ub-lb) .* rand(1,D) );
                
                Light(j)  = feval(fhd,pop(j,:)',fun);

              
                nfeval=nfeval+1;
                if Light(j)<GlobalMin
                    GlobalMin=Light(j);
                    
                end
                
                end
            end 
        end %end for j
    end %end for i
    %update the female archive
    for i=1:n
        if Light(i)<femaleLight(i)
            femaleLight(i)=Light(i);
            femaleArchive(i,:)=pop(i,:);
        end
    end
%update the selection probability
[a,b]=sort(femaleLight);
for i=1:N
    c(i,:)=femaleArchive(b(i),:);
    d(i)=a(i);
    value(i)=1/d(i);
end
p=value/sum(value,2);
    
           
    % Memorize Best
    [CycleMin,~]=min(Light);
    if CycleMin<GlobalMin 
       GlobalMin=CycleMin;
    end
end   % end of iterations
 GlobalMin=GlobalMin-funopt(fun);
 fprintf('best value=%d\n',GlobalMin);
 
end

function [Female] = Roulettle(P)
%utilize the  roulette strategy to select the female individual in archive
r=rand(1);
pc=cumsum(P,2);
tar=find(pc>=r);
Female=tar(1);
end

