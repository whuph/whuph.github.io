﻿If you find this code useful in your work, please cite the 
following paper "Peng H, Zhu W, Deng C, Wu Z. Enhancing Firefly Algorithm with Courtship Learning[J]. Information Sciences, 2021, 543:18-42”

More information can visit H Peng's homepage: https://whuph.github.io/index.html