
function [GlobalMin, outcome, CPUtime] = GBFA(fhd, fun, lb, ub)
%--------------------------------------------------------------------------------------------------------
% 2016-8-12 programming by Hu Peng at JJU
%--------------------------------------------------------------------------------------------------------
% Peng H, Peng S. Gaussian bare-bones firefly algorithm[J]. International Journal of Innovative Computing and Applications, 2019, 10(1):35-42.
%--------------------------------------------------------------------------------------------------------
% More information can visit H Peng's homepage: https://whuph.github.io/index.html
%--------------------------------------------------------------------------------------------------------
tic;

global initial_flag
initial_flag = 0;

D  = 30;
n = 30;    

nfevalmax = 5E5;

outcome = [];

alpha=0.5;

nfeval=0;

pop = lb + rand(n,D).*(ub - lb);

% Evaluate new solutions
Light=zeros(1,n);
for i=1:n 
    Light(i)  = feval(fhd,pop(i,:),fun);    
end
nfeval=nfeval+n;

[GlobalMin,Bestid]=min(Light);
% gbestmem=pop(Bestid,:);

gamma=1;
betamin=0.2;
beta0=1;


while nfeval <nfevalmax
   
    alpha=(1/9000)^(1/2000)*alpha;
    
    for i=1:n
        
        j=fix(rand*n)+1;
        [~,Bestid]=min(Light);
   
        tempu = ((pop(Bestid,:)+pop(j,:))./2);
        tempd = abs(pop(Bestid,:)-pop(j,:));      
        tempx = tempu+tempd.*randn(1,D);
        
        r = norm(pop(i,:)-tempx);
        beta=(betamin+(beta0-betamin)*exp(-gamma*r^2));
            
        pop(i,:)=pop(i,:)+(tempx-pop(i,:)).*beta+alpha.*(rand(1,D)-0.5).*abs(ub-lb);

        pop(i,:) = ( (pop(i,:) >= lb) & (pop(i,:) <= ub) ) .* pop(i,:)...
               + (pop(i,:) < lb) .* ( lb + (ub-lb) .* rand(1,D) )...
               + (pop(i,:) > ub) .* ( lb + (ub-lb) .* rand(1,D) );

        Light(i)  = feval(fhd,pop(i,:),fun);

        nfeval=nfeval+1;
 
    end % end for i

    % Memorize Best
    [CycleMin,Bestid]=min(Light);
    if CycleMin<GlobalMin 
       GlobalMin=CycleMin;
%        gbestmem=pop(Bestid,:);
    end    
    
    outcome = [outcome GlobalMin];
 
end % end of iterations

CPUtime   = toc;

end


