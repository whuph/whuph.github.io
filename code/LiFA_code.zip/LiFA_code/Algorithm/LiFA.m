function LiFA
% This is a simple demo of LiFA
%--------------------------------------------------------------------------------------------------------
% If you find this code useful in your work, please cite the 
% following paper by the author of the code "Peng H, He Y, Deng C, et al. 
% Firefly Algorithm With Luciferase Inhibition 
% Mechanism[J]. IEEE Access, 2019, 7: 120189-120201".
%--------------------------------------------------------------------------------------------------------
% This function is implmented by Yichen He
%--------------------------------------------------------------------------------------------------------
% More information can visit H Peng's homepage: https://whuph.github.io/index.html
%--------------------------------------------------------------------------------------------------------
    clear;clc;
    fprintf('Now is running LiFA\n');
    %% Parameter setting for test function
    addpath('../TestFunction');
    fhd=str2func('cec13_func'); % two parameters can be set, cec13_func or yao_13
    fun=1;
    % for cec13_func
    funopt = [-1400,-1300,-1200,-1100,-1000,-900,-800,-700,-600,-500,-400,-300,-200,-100,100,200,300,400,500,600,700,800,900,1000,1100,1200,1300,1400];
    Xmin = [-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100];
    Xmax  = -Xmin;
    
    % for yao_13
%     funopt=zeros(1,13);
%     Xmin    = [-100,-10,-100,-100,-30,-100,-1.28,-500,-5.12,-32,-600,-50,-50];
%     Xmax    = -Xmin;

    
    %% Parameter setting for algorithm
    D=30;%dimension of firefly
    n = 20;%pop size
    nfevalmax = 4E5;%  maximum number of evaluate

    alpha=0.5;
    gamma=1;
    betamin=0.2;
    beta0=1;
    Remain=1:n;
    nfeval=0;
    a=7;b=2000;% the parameter of eq.10
    
    lb=Xmin(fun);
    ub=-lb;
    pop = lb + rand(n,D).*(ub - lb);% generate the population randomly
    
    %% Evaluate new solutions
    Light=zeros(1,n);
    for i=1:n 
        Light(i)  = feval(fhd,pop(i,:)',fun);    
    end
    nfeval=nfeval+n;

    [GlobalMin,~]=min(Light);

    t=0;
    G=fix(nfevalmax/n);
    %% Move
    while nfeval <nfevalmax && t<G
        t=t+1;
        alpha=(1/9000)^(1/2000)*alpha;
        c=fix((n-a)*exp(-t/(G-b)))+1;%eq.10
        for i=1:n
            [moveObj,Remain]=luciferaseInhibition(c,Remain,n);           
            ll=length(moveObj);
            for z=1:ll
                j=moveObj(z);
                if Light(i)>Light(j)
                    
                    r = norm(pop(i,:)-pop(j,:));
                    beta=(betamin+(beta0-betamin)*exp(-gamma*r^2));
                    
                    pop(i,:)=pop(i,:)+(pop(j,:)-pop(i,:)).*beta+alpha.*(rand(1,D)-0.5).*abs(ub-lb);
                    
                    pop(i,:) = ( (pop(i,:) >= lb) & (pop(i,:) <= ub) ) .* pop(i,:)...
                        + (pop(i,:) < lb) .* ( lb + (ub-lb) .* rand(1,D) )...
                        + (pop(i,:) > ub) .* ( lb + (ub-lb) .* rand(1,D) );
                    
                    Light(i)  = feval(fhd,pop(i,:)',fun);
                    nfeval=nfeval+1;
                    
                end
            end % end for j
            
        end % end for i
        % Memorize Best
        [CycleMin,~]=min(Light);
        if CycleMin<GlobalMin
            GlobalMin=CycleMin;
        end       
    end   % end of iterations
    GlobalMin=GlobalMin-funopt(fun);
    fprintf('best value=%d\n',GlobalMin);
end

function [moveObj,nextRemain] = luciferaseInhibition(c,Remain,n)
%% select c fireflies from remain population
    flag=false;
    e=numel(Remain);
    if e <= c
        moveObj=Remain;        
        Remain=1:n;
        flag=true;
    else
        temp=randperm(e);
        temp=Remain(temp(1:c));
        moveObj=sort(temp);
    end    
    % luciferase inhibition
    lastPos=1;
    if ~flag
        for i=1:length(moveObj)
            for j=lastPos:length(Remain)
                if moveObj(i) == Remain(j)
                    lastPos=j;
                    Remain(j)=[];
                    break;
                end
            end
        end
    end
    nextRemain=Remain;
end