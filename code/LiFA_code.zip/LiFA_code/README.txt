Two test sets you can choose: cec13_func and yao_13.
If you want to choose yao_13, you must modify 
"Light(i)  = feval(fhd,pop(i,:)',fun)"
to "Light(i)  = feval(fhd,pop(i,:),fun)", vice versa.

If you find this code useful in your work, please cite the 
following paper by the author of the code "Peng H, He Y, Deng C, et al. 
Firefly Algorithm With Luciferase Inhibition 
Mechanism[J]. IEEE Access, 2019, 7: 120189-120201".

More information can visit H Peng's homepage: https://whuph.github.io/index.html