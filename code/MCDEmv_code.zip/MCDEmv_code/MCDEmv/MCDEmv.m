function MCDEmv
% This is a simple demo of MCDEmv
%--------------------------------------------------------------------------------------------------------
% If you find this code useful in your work, please cite the 
% following paper "Peng H, Han Y, Deng C et al., Multi-strategy co-evolutionary differential evolution 
%                  for mixed-variable optimization[J], Knowledge-Based Systems, 2021, 107366, 
%                  DOI:107366.10.1016/j.knosys.2021.107366".
%--------------------------------------------------------------------------------------------------------
% This function is implmented by Yupeng Han
%--------------------------------------------------------------------------------------------------------
%--------------------------------------------------------------------------------------------------------
% More information can visit Hu Peng's homepage: https://whuph.github.io/index.html
%--------------------------------------------------------------------------------------------------------
    
    fprintf('Now is running MCDEmv\n');

    fhd=str2func('cec13_func'); % cec13_func
    fun=4;
    % for cec13_func
    funopt = [-1400,-1300,-1200,-1100,-1000,-900,-800,-700,-600,-500,-400,-300,-200,-100,100,200,300,400,500,600,700,800,900,1000,1100,1200,1300,1400];
    xmin = [-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100];

    D  = 50;
    D1 = 25;
    NP = 30;
    nfevalmax = 2000*D;

    outcome = [];
    
    lowbound  = ones(1,D).*xmin(fun);
    highbound = ones(1,D).*( -xmin(fun) );
    pop = zeros(NP,D);

    for i=1:NP
        pop(i,:) = lowbound + rand(1,D).*(highbound - lowbound);
    end
%------------------------------------------------------------------------------------
    % mapping method
    % In here, the number of feasible values for discrete variables is 201, integer randomly 
    % distributed between [-100,100],the number and value of feasible values is special, 
    % so the rounding method is used directly
    feasibleValue_number = 201;
    for i=1:NP
        for j=D1+1:D
            pop(i,j) = round(pop(i,j));
        end
    end
%------------------------------------------------------------------------------------
    val = zeros(1,NP);
    nfeval = 0;

    for i=1:NP
        val(i)  = feval(fhd,pop(i,:)',fun);
    end
    nfeval  = nfeval + NP;

    r = zeros(1,3);
    
    flag = 1;
    CR1=0.1;
    CR2=0.9; 
    CR=CR2+randn*0.1;
    
    sn1 = 2;
    dictsucc1 = ones(NP,sn1);
    dicttota1 = ones(NP,sn1);

    sn2 = 3;
    dictsucc2 = ones(NP,sn2);
    dicttota2 = ones(NP,sn2);

    t = 0;
    % The nth available value to be assigned to the jth variable
    valueNum = zeros(D1,feasibleValue_number);% Count the number of occurrences of each feasible value of the discrete dimension
    Prob = zeros(D1,feasibleValue_number); % Calculate the probability of each feasible value of the discrete dimension being selected
%----------------------------------------------------------------------------------------    
    while nfeval <nfevalmax
        for i=1:NP   
            rd=randperm(NP);
            for j=1:3
                if rd(j)~=i
                    r(j)=rd(j);
                else
                    r(j)=rd(4);
                end
            end 
                    
            T=10;
            Em=T*CR;
            Es=T*(1-CR);
            Crm= Em/(Em+ 1);
            Crs= Es/(Es+ 1);
            
            sr1 = dictsucc1(i,:)./dicttota1(i,:);
            P1 = sr1 / sum( sr1 );
            scheme1 = Roulette(P1);

            sr2 = dictsucc2(i,:)./dicttota2(i,:);
            P2 = sr2 / sum( sr2 );
            scheme2 = Roulette(P2);
            
            F = 0.9 + randn*0.1;
            tempx = pop(i, :);                
            jrand = fix(1+D*rand);

            switch scheme1
                    case 1  
                        switch scheme2 
                            case 1        
                                for j=1:D
                                    if (rand<CR || j==jrand ) 
                                        tempx(j) = pop(r(1),j)+F.*(pop(r(2),j)-pop(r(3),j));
                                        if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                            tempx(j) = lowbound(j) + rand*(highbound(j) - lowbound(j));
                                        end
                                    end
                                end

                            case 2
                                [~,bestid] = min(val);
                                for j=1:D
                                    if (rand<CR || j==jrand ) 
                                        tempx(j) = pop(bestid,j)+F.*(pop(r(2),j)-pop(r(3),j));
                                        if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                            tempx(j) = lowbound(j) + rand*(highbound(j) - lowbound(j));
                                        end
                                    end
                                end

                            case 3
                                randF = rand;
                                for j=1:D
                                    if (rand<CR || j==jrand ) 
                                        tempx(j) = pop(i,j)+randF.*(pop(r(1),j)-pop(i,j))+F.*(pop(r(2),j)-pop(r(3),j));                            
                                        if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                            tempx(j) = lowbound(j) + rand*(highbound(j) - lowbound(j));
                                        end
                                    end
                                end
                        end   
                
             case 2  
                    switch scheme2  
                        case 1        
                            n = fix(1+D*rand);
                            k = 1;
                            Mutation_Enable = 1;
                            while  k<=D
                                if Mutation_Enable == 1
                                    while  k <= D && rand <= Crm
                                        if n<=D
                                            j = n;
                                        else
                                            j = n - D;
                                        end
                                        tempx(j) = pop(r(1),j)+F.*(pop(r(2),j)-pop(r(3),j));
                                        if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                            tempx(j) = lowbound(j) + rand*(highbound(j) - lowbound(j));
                                        end
                                        n = n+1;
                                        k = k+1;
                                    end
                                    Mutation_Enable = 0;
                                else
                                    while  k <= D && rand <= Crs
                                        if n<=D
                                            j = n;
                                        else
                                            j = n - D;
                                        end
                                        tempx(j) = pop(i,j);
                                        if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                            tempx(j) = lowbound(j) + rand * (highbound(j) - lowbound(j));
                                        end
                                        n = n+1;
                                        k = k+1;
                                    end
                                    Mutation_Enable = 1;
                                end
                            end

                        case 2
                            [~,bestid] = min(val);
                            n = fix(1+D*rand);
                            k = 1;
                            Mutation_Enable = 1;
                            while  k<=D
                                if Mutation_Enable == 1
                                    while  k <= D && rand <= Crm
                                        if n<=D
                                            j = n;
                                        else
                                            j = n - D;
                                        end
                                        tempx(j) = pop(bestid,j)+F.*(pop(r(2),j)-pop(r(3),j));
                                        if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                            tempx(j) = lowbound(j) + rand*(highbound(j) - lowbound(j));
                                        end
                                        n = n+1;
                                        k = k+1;
                                    end
                                    Mutation_Enable = 0;
                                else
                                    while  k <= D && rand <= Crs
                                        if n<=D
                                            j = n;
                                        else
                                            j = n - D;
                                        end
                                        tempx(j) = pop(i,j);
                                        if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                            tempx(j) = lowbound(j) + rand * (highbound(j) - lowbound(j));
                                        end
                                        n = n+1;
                                        k = k+1;
                                    end
                                    Mutation_Enable = 1;
                                end
                            end

                        case 3
                            randF = rand;
                            n = fix(1+D*rand);
                            k = 1;
                            Mutation_Enable = 1;
                            while  k<=D
                                if Mutation_Enable == 1
                                    while  k <= D && rand <= Crm
                                        if n<=D
                                            j = n;
                                        else
                                            j = n - D;
                                        end
                                        tempx(j) = pop(i,j)+randF.*(pop(r(1),j)-pop(i,j))+F.*(pop(r(2),j)-pop(r(3),j));
                                        if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                            tempx(j) = lowbound(j) + rand*(highbound(j) - lowbound(j));
                                        end
                                        n = n+1;
                                        k = k+1;
                                    end
                                    Mutation_Enable = 0;
                                else
                                    while  k <= D && rand <= Crs
                                        if n<=D
                                            j = n;
                                        else
                                            j = n - D;
                                        end
                                        tempx(j) = pop(i,j);
                                        if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                            tempx(j) = lowbound(j) + rand * (highbound(j) - lowbound(j));
                                        end
                                        n = n+1;
                                        k = k+1;
                                    end
                                    Mutation_Enable = 1;
                                end
                            end
                    end % end scheme2
            end  % end scheme1
%--------------------------------------------------------------------------------------
            % mapping method
            % In here, the number and value of feasible values is special, 
            % so the rounding method is used directly. Otherwise, follow the settings in the paper. 
            for j=26:D
                tempx(j) = round(tempx(j));
            end
% -------------------------------------------------------------------------------------                        
            tempval = feval(fhd, tempx', fun);
            nfeval  = nfeval + 1;

            if tempval < val(i)
                val(i)   = tempval;
                pop(i,:) = tempx;
                dictsucc1(i,scheme1) = dictsucc1(i,scheme1)+1;
                dictsucc2(i,scheme2) = dictsucc2(i,scheme2)+1;
            else% Adaptive shift strategy
                flag=~flag;
                if flag==1
                    CR=CR1+0.1*randn;
                else
                    CR=CR2+0.1*randn;
                end
            end
            dicttota1(i,scheme1) = dicttota1(i,scheme1)+1;
            dicttota2(i,scheme2) = dicttota2(i,scheme2)+1;
        end %--for i=1:NP                               
%------------------------------------------------------------------------------------------
        % Statistics-based local search for discrete variables
        [~,index] = sort(val);
        
        for j = D1+1:D
            for n = 1:feasibleValue_number
                for k = 1:NP/2             
                    if  pop(index(k),j) == (n-101)
                        valueNum(j-25,n) = valueNum(j-25,n) + 1;
                    end
                end 
            end
            for n = 1:201
                Prob(j-25,n) = valueNum(j-25,n)/sum(valueNum(j-25,:));
            end
        end

        p = 0.5*NP;

        m = 3;                          
        selectP = index(randperm(p,m));
        for i =1:m
            localpop(i,:) = pop(selectP(i),:);
        end

        selectcompared = index(randperm(m,m));
        for i = 1:m  
            n = 3;                            
            selectD = 25+randperm(25,n);
            for j = 1:n
                [~,betterProb]= sort(Prob(selectD(j)-25,:),'descend');
                betterValueProb=betterProb(randperm(3,1));       
                localpop(i,selectD(j)) = betterValueProb-101;
            end
            
            localValue(i) = feval(fhd, localpop(i,:)', fun);
            nfeval = nfeval + 1;
                       
            if localValue(i)<val(selectcompared(i))
                pop(selectcompared(i),:) = localpop(i,:);
                val(selectcompared(i)) = localValue(i);
            end
        end
%-----------------------------------------------------------------------------------------
        t = t+1;
        GlobalMin = min(val);
        outcome   = [outcome GlobalMin];  

    end %--While nfeval <nfevalmax
    
    GlobalMin=GlobalMin-funopt(fun);
    fprintf('best value=%d\n',GlobalMin);

end

%% The roulette method
function Select=Roulette(P)
    m = length(P);  
    r = rand; 
    
    sumP = 0;      
    j = ceil(m*rand);   
    while sumP < r          
        sumP = sumP + P(mod(j-1,m)+1);         
        j = j+1;     
    end     
    Select = mod(j-2,m)+1; 
    
end
