Welcome to access Hu Peng's Homepage, https://whuph.github.io/index.html,
Our papers and codes are avaliable on the website. 

If you find this code useful in your work, please cite the 
following paper "Peng H, Han Y, Deng C, et al., Multi-strategy co-evolutionary differential evolution for mixed-variable optimization[J], Knowledge-Based Systems, 2021, 107366, DOI: 107366.10.1016/j.knosys.2021.107366".