function MDMEA_HCR(Global)
% <algorithm> <M>
% Dynamic Multiobjective Optimization algorithm
% nr    ---   2 --- Maximum number of solutions replaced by each offspring

% This is a simple demo of MDMEA-HCR
%--------------------------------------------------------------------------------------------------------
% If you find this code useful in your work, please cite the following paper " Hu Peng, Changrong Mei, 
% Sixiang Zhang, Zhongtian Luo, Qingfu Zhang, Zhijian Wu. Multi-strategy dynamic multi-objective evolutionary
% algorithm with hybrid environmental change responses. Swarm and Evolutionary Computation, 2023".
%--------------------------------------------------------------------------------------------------------
% This function is implmented by Changrong Mei
%--------------------------------------------------------------------------------------------------------
%--------------------------------------------------------------------------------------------------------
% More information can visit Hu Peng's homepage: https://whuph.github.io/index.html
%--------------------------------------------------------------------------------------------------------
%------------------------------- DMO --------------------------------------------------------------------
   %% Parameter Settings
     nr = Global.ParameterSet(2);
     T_min=5;T_max=40; Mid_num=floor(Global.problem.tauT/2); r=1;flexible=4;
     Memory_Set=[];K=0; t_size=20;M_num=5;
     global dif; dif=0;
     
    %% Generate the weight vectors
    if Global.M==2
          [W,~] = UniformPoint(Global.N-8,Global.M);
          W=Update_Weight(W,Global.N);
    else
          [W,~] = UniformPoint(Global.N,Global.M);
           W=Update_Weight(W,Global.N);
    end   
    
    %% Detect the neighbours of each solution
     B = pdist2(W,W);
     [~,B] = sort(B,2);
     
    %% Generate random population
     Global.Initialization();
     Z = min(Global.Population.objs,[],1);
     
    %% Evolutionary optimization
    while Global.NotTermination  
        % Tag1 is the mark variable of function evaluation times before each environmental change.
          Tag1=Global.evaluated; 
        % Detecting changes in the environment using re-evaluation methods
          if Global.hasChanged() 
               dif=0;
               % Memory storage strategy
               [Memory_Set,K]=Memory_store(Global.Population,Memory_Set,t_size,M_num,K);      
              if Global.gen-50==Global.problem.tauT 
                      % The first environmental change occurs, no response is made, and the population is re-evaluated.
                      Last_C=mean(Global.Population.decs,1);
                      Global.Population=INDIVIDUAL(Global.Population.decs);
              elseif Global.gen-50>Global.problem.tauT  
                     % Hybrid environmental change response mechanism
                     Curr_C=mean(Global.Population.decs,1);
                     % Response strategy1: Modified Linear prediction model
                     [New_Pop1,~]=Response_Strategy1(Global.Population,Global.N,Global.D,Last_C,Curr_C,Global.lower,Global.upper);
                     % Response strategy2: Memory solution introduction strategy
                     [New_Pop2,~]=Response_Strategy2(Memory_Set,Global.N,Global.D,Global.lower,Global.upper);
                     % Response strategy3: Gaussian polynomial mixed mutation strategy
                     [New_Pop3,~]=Response_Strategy3(Global.Population,Global.N,Global.D,Global.lower,Global.upper);
                     
                     % Environmental selection mechanism that select out initial response population
                     Global.Population=EnvironmentalSelection([New_Pop1,New_Pop2,New_Pop3],Global.N);
                     Last_C=Curr_C; 
              end
                      r=1;
                     % Response adjustment mechanism(Individual transfer adjustment and  Vector matching adjustment)
                     Global.Population=Response_adjust(Global.Population,W,Global.N,Global.lower,Global.upper);
                     % Update the ideal point
                     Z=min(Global.Population.objs,[],1);
          end
           % Tag2 is the mark variable of function evaluation times after each environmental change.
           Tag2=Global.evaluated;
           if(Tag2-Tag1>100)
               dif=Tag2-Tag1-100;
           end

          % The  neighbor size is adaptively adjusted
          if Global.gen-50>=Global.problem.tauT 
                T=T_min+ceil((T_max-T_min)/(exp(-flexible*(r-Mid_num)/Mid_num)+1)); 
                B1 = B(:,1:T);
          else
                T=20; 
                B1 = B(:,1:T);
          end   
          
        % Static multi-objective optimization
        for i = 1 : Global.N
            if(dif>0)
                dif=dif-1; continue;
            end
            P = B1(i,randperm(end));
            % Multi-Strategy evolutionary operators based on variable domains
            if   T<=T_min+floor((T_max-T_min)/2)
                               Offspring =DE(Global.Population(i),Global.Population(P(1)),Global.Population(P(2)),{1,0.4,1,20});
            else
                  if rand<0.4
                               Offspring=GAhalf([Global.Population(i) Global.Population(P(1))]);
                  else
                               Offspring=DE_current_to_lbest(Global.Population,Global.Population(i),W,Z,P,Global.lower,Global.upper);
                  end
            end
            
            % Update the ideal point
            Z = min(Z,Offspring.obj);
            % Update the solutions in P by Tchebycheff approach
            g_old = max(abs(Global.Population(P).objs-repmat(Z,length(P),1)).*W(P,:),[],2);
            g_new = max(repmat(abs(Offspring.obj-Z),length(P),1).*W(P,:),[],2);
            update_index=P(find(g_old>=g_new,nr));
            Global.Population(update_index) = Offspring;
        end
          r=r+1;  
    end
end