%%  Modified linear prediction model
function [New_Pop1,N1]=Response_Strategy1(Population,N,D,Last_C,Curr_C,Lower,Upper)
    d=Curr_C-Last_C;
    New_Pop1_decs=Population.decs;
    for i=1:N
        if mod(i,3)==0
             New_Pop1_decs(i,:)=New_Pop1_decs(i,:)+0.5*d; 
        elseif mod(i,3)==1
             New_Pop1_decs(i,:)=New_Pop1_decs(i,:)+d; 
        else
             New_Pop1_decs(i,:)=New_Pop1_decs(i,:)+1.5*d; 
        end
             New_Pop1_decs(i,:)= min(max(New_Pop1_decs(i,:),Lower),Upper);
    end
    New_Pop1=INDIVIDUAL(New_Pop1_decs);
    N1=length(New_Pop1);
end