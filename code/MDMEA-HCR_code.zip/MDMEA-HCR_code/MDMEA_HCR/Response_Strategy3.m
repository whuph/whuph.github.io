%% Gaussian polynomial mixed mutation strategy
function [New_Pop3,N3]=Response_Strategy3(Population,N,D,Lower,Upper)
          indexs1=randperm(N,floor(N*0.25));indexs2=setdiff(1:N,indexs1);
          indexs2=indexs2(randperm(length(indexs2),floor(N*0.25)));
          New_Pop31=Gaussian_mutation(Population(indexs1).decs,Lower,Upper);
          New_Pop32=Polynomial_mutation(Population(indexs2).decs,length(indexs2),D,1,20,Lower,Upper);
          New_Pop3=[New_Pop31,New_Pop32];
          N3=length(New_Pop3);
end

%% Gaussian mutation
function new_pop = Gaussian_mutation(pop_decs,lower,upper)
    x=pop_decs;
   [len,dim]= size(x);
   sigma = (upper-lower)./20;
   prob=1/dim;
   newparam = min(max(normrnd(x, repmat(sigma,len,1)), repmat(lower,len,1)), repmat(upper,len,1));
   C = rand(len,dim)<prob;
   x(C) = newparam(C');
   X_dec=Boundary_Repair(x,lower,upper);
   new_pop=INDIVIDUAL(X_dec);  
end

%% Polynomial mutation
function new_one=Polynomial_mutation(pop_one_dec,N,D,proM,disM,Lower,Upper)
            Lower=repmat(Lower,N,1);
            Upper=repmat(Upper,N,1);
            Site  = rand(N,D) < proM/D;
             mu    = rand(N,D);
            temp  = Site & mu<=0.5;
            pop_one_dec       = min(max(pop_one_dec,Lower),Upper);
            pop_one_dec(temp) = pop_one_dec(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
                              (1-(pop_one_dec(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
            temp = Site & mu>0.5; 
            pop_one_dec(temp) = pop_one_dec(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
                              (1-(Upper(temp)-pop_one_dec(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));
            new_one=INDIVIDUAL(pop_one_dec);            
end

