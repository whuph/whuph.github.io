Welcome to access Hu Peng's Homepage, https://whuph.github.io/index.html,
Our papers and codes are avaliable on the website. 

If you find this code useful in your work, please cite the 
following paper "Hu Peng, Changrong Mei, Sixiang Zhang, Zhongtian Luo, Qingfu Zhang, Zhijian Wu. Multi-strategy dynamic multi-objective evolutionary algorithm with hybrid environmental change responses. Swarm and Evolutionary Computation, 2023, 101356."






