function CD = CalCrowdDegree(Population,Space)
    PopDec = Population.decs;
    PopObj = Population.objs;
    K = floor(sqrt(size(PopDec,1)));
    [~, distDec] = knnsearch(PopDec, PopDec, 'K', K+1);
    [~, distObj] = knnsearch(PopObj, PopObj, 'K', K+1);
    DecCD = 1./(distDec(:,K+1)+2);
    ObjCD = 1./(distObj(:,K+1)+2);
    DecCD_norm= (DecCD - min(DecCD)) ./ (max(DecCD) - min(DecCD));
    ObjCD_norm = (ObjCD - min(ObjCD)) ./ (max(ObjCD) - min(ObjCD));
    if strcmp(Space,'Dec')
         CD = DecCD_norm;
         return;
     end
    CD = DecCD_norm + ObjCD_norm;
end