function Fitness = CalFitness(Population)
    PopDec = Population.decs;
    PopObj = Population.objs;
    N = size(PopDec,1);
    Dominate = false(N);
    for i = 1 : N-1
        for j = i+1 : N
            k = any(PopObj(i,:)<PopObj(j,:)) - any(PopObj(i,:)>PopObj(j,:));
            if k == 1
                Dominate(i,j) = true;
            elseif k == -1
                Dominate(j,i) = true;
            end
        end
    end
    S = sum(Dominate,2);
    R = zeros(1,N);
    for i = 1 : N
        R(i) = sum(S(Dominate(:,i)));
    end
    Distance = pdist2(PopDec,PopDec);
    Distance(logical(eye(length(Distance)))) = inf;
    Distance = sort(Distance,2);
    D_Dec = 1./(Distance(:,floor(sqrt(N)))+2);
    D = D_Dec;
    Fitness = R + D';
end