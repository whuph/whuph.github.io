function ILCI = CalLocalCon(Population,Eta)
    PopDec = Population.decs;
    PopObj = Population.objs;
    [N, D] = size(PopDec);
    distDec = pdist2(PopDec,PopDec);
    R =  (prod(max(PopDec) - min(PopDec)) ^ (1 / D)) / (sqrt(2) * pi * (1 - exp(1 - D)));
    R1 = R;
    R2 = Eta*R;
    ILCI = zeros(1,N);
    B = false(N);
    for i = 1 : N-1
        for j = i+1 : N
            if distDec(i, j) > R2
                continue
            end
            if all(PopObj(j, :) <= PopObj(i, :)) && any(PopObj(j, :) < PopObj(i, :))
                B(i, j) = true;
            elseif all(PopObj(i, :) <= PopObj(j, :)) && any(PopObj(i, :) < PopObj(j, :))
                B(j, i) = true;
            end
        end
    end
    for i = 1:N
            Ni = distDec(i, :) <= R2;
            CN = find(distDec(i, :) <= R1);
            DN = find(distDec(i, :) > R1 & distDec(i, :) <= R2);
             if isempty(Ni)
                ILCI(i) = 0;
                continue;
            end
            Ci = sum(B(i, CN)) / numel(CN);
            Sj = zeros(1, numel(CN) + numel(DN));
            for j = 1:numel(CN)
                Sj(j) = sum(B(:,CN(j)));
            end
            for k = 1:numel(DN)
                Sj(numel(CN) + k) = sum(B(:,DN(k)));
            end
            ILCI(i) = sum(Sj) * Ci;
    end
end