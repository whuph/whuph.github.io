classdef MMEABDC< ALGORITHM
% <multi> <real/integer> <multimodal>
     methods
        function main(Algorithm, Problem)
            Eta=1.8;
            %% Initialization
            TraPop = Problem.Initialization(); 
            DifPop = Problem.Initialization();
            [~,CDdec] = RegenerationTraPop(TraPop, Problem.N);
            [~,CDdual,ILCI] = RegenerationDifPop(DifPop, Problem.N, Eta);
            %% Optimization
            while Algorithm.NotTerminated(DifPop)
                MatingPool1 = TournamentSelection(2,Problem.N,CDdec);
                Offspring1  = OperatorGAhalf(Problem,TraPop(MatingPool1));
                MatingPool2 = TournamentSelection(2,Problem.N,ILCI,CDdual);
                Offspring2  = OperatorGAhalf(Problem,DifPop(MatingPool2));
                [TraPop,CDdec] = RegenerationTraPop([TraPop, Offspring1, Offspring2],Problem.N);
                [DifPop,CDdual,ILCI] = RegenerationDifPop([DifPop, Offspring1, Offspring2],Problem.N,Eta);
            end
        end
    end
end