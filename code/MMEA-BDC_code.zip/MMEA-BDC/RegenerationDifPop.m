function [DifPop, CDdual, ILCI] = RegenerationDifPop(Population, N, Eta)
    ILCI = CalLocalCon(Population, Eta);
    Temp = find(ILCI == 0);
    [FrontNo, ~] = NDSort(Population(Temp).objs, length(Temp));
    Gpop = Temp(FrontNo == 1);
    Lpop = setdiff(Temp, Gpop);
    if ~isempty(Lpop)
        Lpop = NicheDrivenFilter(Gpop, Lpop, Population);
        Next = [Gpop Lpop];
    else
        Next = Gpop;
    end
    if length(Next) < N
        CD = CalCrowdDegree(Population, 'Dual');
        [~, idx] = sortrows([ILCI', CD]);
        Next = idx(1:N);
    elseif length(Next) > N
        Next = DualDistSubsetSelection(Next, Population, N);
    end
    DifPop = Population(Next);
    CDdual = CalCrowdDegree(DifPop, 'Dual');
    ILCI = CalLocalCon(DifPop,Eta);
end

function Lpop = NicheDrivenFilter(Gpop, Lpop, Population)
    [N_Gpop, M] = size(Population(Gpop).objs);
    minN_Gpop = 10;
    if length(Gpop) < minN_Gpop
        [FrontNo, ~] = NDSort(Population(Lpop).objs, length(Lpop));
        Lpop = Lpop(FrontNo == 1);
    else
        SUM = zeros(N_Gpop, 1);
        for i = 1:N_Gpop
            sum_i_G = 0;
            objs_G = Population(Gpop(i)).objs;
            for j = 1:M
                sum_i_G = sum_i_G + objs_G(j);
            end
            SUM(i) = sum_i_G;
        end
        SUM_MIN = min(SUM);
        Gpop_Dec = Population(Gpop).decs;
        Gpop_Dec_Dist = pdist2(Gpop_Dec, Gpop_Dec); Gpop_Dec_Dist(logical(eye(N_Gpop))) = Inf;
        Gpop_Dec_Dist_Sort = sort(Gpop_Dec_Dist);
        K = 3;
        radius = (sum(sum(Gpop_Dec_Dist_Sort(1:K, :))) / (N_Gpop * K));
        Lpop_Dec = Population(Lpop).decs;
        Dec_L_G_Dec = pdist2(Lpop_Dec, Gpop_Dec);
        Min_Dist_L_G_Dec = min(Dec_L_G_Dec, [], 2);
        Lpop = Lpop(Min_Dist_L_G_Dec > radius);
        N_Lpop = length(Lpop);
        if N_Lpop ~= 0
            for i = N_Lpop:-1:1
                sum_i_L = 0;
                objs_L = Population(Lpop(i)).objs;
                for j = 1:M
                    sum_i_L = sum_i_L + objs_L(j);
                end
                delte = 5;
                if (sum_i_L / SUM_MIN) > delte
                    Lpop(i) = [];
                end
            end
        end
    end
end

function indices = DualDistSubsetSelection(indices, Population, N)
    K_neighbors = floor(sqrt(length(indices)));
    [~, distObj] = knnsearch(Population(indices).objs, Population(indices).objs, 'K', K_neighbors + 1);
    [~, distDec] = knnsearch(Population(indices).decs, Population(indices).decs, 'K', K_neighbors + 1);
    ThetaDec = sum(sum(distDec(:, 2:end))) / (length(indices) * K_neighbors);
    ThetaObj = sum(sum(distObj(:, 2:end))) / (length(indices)  * K_neighbors);
    CDdec = CalCrowdDegree(Population(indices),'Dec');
    [~,idx] = min(CDdec);
    Temp = indices(idx);
    Rpop = setdiff(indices, Temp);
    while length(Temp) < N
        [~, distDec] = knnsearch(Population(Temp).decs, Population(Rpop).decs, 'K', 1);
        [~, distObj] = knnsearch(Population(Temp).objs, Population(Rpop).objs, 'K', 1);
        distDecNorm = normalizeDistances(distDec(:, 1));
        distObjNorm = normalizeDistances(distObj(:, 1));
        distDual = distDecNorm + distObjNorm;
        [~, idx] = max(distDual);
        X = Rpop(idx); [~, distObj] = knnsearch(Population(Temp).objs, Population(X).objs, 'K', 1);
        distObj = min(distObj);
        if distObj < ThetaObj
            dist = pdist2(Population(X).decs,Population(Rpop).decs);
            nb = find(dist < ThetaDec); nb = setdiff(nb,idx);
            if ~isempty(nb)
                idx = nb(randi(length(nb)));
                X = Rpop(idx);
            end
        end
        Temp = [Temp, Rpop(idx)];
        Rpop(idx) = [];
    end
    indices = Temp;
end

function distNorm = normalizeDistances(dist)
    if max(dist) == min(dist)
        distNorm = zeros(size(dist));
    else
        distNorm = (dist - min(dist)) / (max(dist) - min(dist));
    end
end