function [TraPop, CDdec] = RegenerationTraPop(Population, N)
    Fitness = CalFitness(Population);
    Next = find(Fitness < 1);
    if length(Next) < N
        [~, idx] = sort(Fitness);
        Next = idx(1:N);
    elseif length(Next) > N
        Next = Truncation(Next, Population, length(Next) - N);
    end
    TraPop = Population(Next);
    CDdec = CalCrowdDegree(TraPop, 'Dec');
end

function Next = Truncation(Next,Population,DelN)
    K=3;
    for i = 1:DelN
        PopDec = Population(Next).decs;
        PopObj = Population(Next).objs;
        distDec = sort(pdist2(PopDec,PopDec));
        distDec = sum(distDec(1:K,:));
        distObj = sort(pdist2(PopObj,PopObj));
        distObj = sum(distObj(1:K,:));
        CrowdDis = distDec./max(distDec) + distObj./max(distObj);
        [~, idx] = min(CrowdDis);
        Next(idx) = [];
    end
end
