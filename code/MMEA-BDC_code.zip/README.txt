Welcome to Hu Peng's Homepage at https://whuph.github.io/
Our research papers and corresponding codes are publicly available on this website.

This repository contains the MMEA-BDC folder (Main code of the MMEA-BDC algorithm) and the RLP folder (Restaurant Location Problem with three global optimal solution sets and one local optimal solution set). Please note that for MMOPL (Multimodal Multiobjective Optimization with Local Pareto Sets) problems, the IGD (Inverted Generational Distance) calculation method should be modified to account for the presence of local Pareto fronts.

This implementation is based on the PlatEMO platform: Ye Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, "PlatEMO: A MATLAB Platform for Evolutionary Multi‑Objective Optimization", IEEE Computational Intelligence Magazine, 2017, 12(4): 73‑87.

NOTE: Users are encouraged to adapt the code to their specific problem domains while maintaining proper attribution. If the MMEA-BDC algorithm code or the RLP problem implementation contributes to your research, please cite our paper: Mengfan Li, Hu Peng, Zhanyan Cai and Dunlu Peng, "Bi-Directional Coevolution for Multimodal Multiobjective Optimization With Local Pareto Sets," IEEE Transactions on Evolutionary Computation, DOI: 10.1109/TEVC.2025.3638467.