classdef RLP < PROBLEM
% <2025> <multi> <real> <multimodal>
% Restaurant_Selection_Problem

    properties
        POS;    % Pareto optimal set
        A;      % hospitals coordinates
        B;      % schools coordinates
        C;      % office buildings coordinates
        regions; %global and local optimal regions
    end
    methods
        %% Default settings of the problem
        function Setting(obj)
            obj.M = 3;
            obj.D = 2;
            obj.lower = [0,0];
            obj.upper = [23, 23];
            obj.encoding = ones(1,obj.D);

             % Initialize coordinates
            A1 = [2, 23];
            A2 = [10, 18];
            A3 = [10.5,12];
            A4 = [15, 10];
            A5 = [5,2];
            obj.A=[A1;A2;A3;A4;A5;]; 
            
            B1 = [10, 23];
            B2 = [2,18];
            B3 = [17.5,10+5*sqrt(3)/2];
            B4 = [2, 7];
            
            obj.B=[B1;B2;B3;B4;]; 
            
            C1 = [6,21];
            C2 = [20,10];
            C3 = [1+5*sqrt(2),6.5];
            C4=[5,13];
            C5=[17,4];
            C6=[12,2];
            obj.C = [C1; C2; C3;C4;C5;C6];
            obj.regions = {[A1; B2; C1], [C1; A2; B1], [A4; C2; B3], [B4; C3; A5]};
        end
        %% Calculate objective values
        function PopObj = CalObj(obj,X)
            temp1=pdist2(X(:,1:2),obj.A(:,1:2));
            temp2=pdist2(X(:,1:2),obj.B(:,1:2));
            temp3=pdist2(X(:,1:2),obj.C(:,1:2));
            PopObj(:,1) = min(temp1,[],2);
            PopObj(:,2) = min(temp2,[],2);
            PopObj(:,3) = min(temp3,[],2);
        end

        %% Generate Pareto optimal solutions
        function R = GetOptimum(obj,~)
            load('RLP_PSPF_data.mat');
            obj.POS = PS;
            R = PF;
        end

        %% Generate the image of Pareto front
        function R = GetPF(obj)
            load('RLP_PSPF_data.mat');
            R = PF;
        end

        %% Calculate the metric value
        function score = CalMetric(obj,metName,Population)
            switch metName
                case 'IGDX'
                    score = feval(metName,Population,obj.POS);
                case 'PSP'
                    score = feval(metName,Population,obj.POS);
                otherwise
                    score = feval(metName,Population,obj.optimum);
            end
        end
        function DrawObj(obj, Population)
            hold on;
            axis([0 22 0 25]);
            plot(obj.A(:, 1), obj.A(:, 2), '^', 'MarkerSize', 8, 'MarkerFaceColor', '#FFBC4C', 'MarkerEdgeColor', '#C75D2C', 'LineWidth', 1.5,'DisplayName', 'Hospital'); 
            plot(obj.B(:, 1), obj.B(:, 2), 's', 'MarkerSize', 10,'MarkerFaceColor', '#FF6B6B', 'MarkerEdgeColor', '#850000', 'LineWidth', 1.5, 'DisplayName', 'School'); 
            plot(obj.C(:, 1), obj.C(:, 2), 'o', 'MarkerSize', 9, 'MarkerFaceColor', '#77BEF0', 'MarkerEdgeColor', '#3D74B6','LineWidth', 1.5,'DisplayName', 'Office Building');
            triangleColors = {'#E14434','#E14434','#E14434', '#7E99F4'};
            fillColors = {[1,0,0], [1,0,0], [1,0,0], [0,0,1]};
            
            for i = 1:length(obj.regions)
                tri = obj.regions{i};
                if i == 3
                    fill([tri(1, 1), tri(2, 1), tri(3, 1)], [tri(1, 2), tri(2, 2), tri(3, 2)], fillColors{i},'FaceAlpha', 0.2, 'EdgeColor', 'none', 'DisplayName', 'Global PS');
                elseif i==4
                    fill([tri(1, 1), tri(2, 1), tri(3, 1)], [tri(1, 2), tri(2, 2), tri(3, 2)], fillColors{i},'FaceAlpha', 0.2, 'EdgeColor', 'none', 'DisplayName', 'Local PS');
                else
                    fill([tri(1, 1), tri(2, 1), tri(3, 1)], [tri(1, 2), tri(2, 2), tri(3, 2)], fillColors{i},'FaceAlpha', 0.2, 'EdgeColor', 'none', 'HandleVisibility', 'off');
                end
                plot([tri(1, 1), tri(2, 1), tri(3, 1), tri(1, 1)], [tri(1, 2), tri(2, 2), tri(3, 2), tri(1, 2)], '--', 'Color', triangleColors{i}, 'LineWidth', 3, 'HandleVisibility', 'off');
            end

           obtain_ps = Population.decs;
            plot(obtain_ps(:, 1), obtain_ps(:, 2),  'o', 'MarkerSize', 4, 'MarkerFaceColor', [0,1,0], 'MarkerEdgeColor', [0,1,0] ,'DisplayName', 'Obtained PS');
            
            title(' ');
            box on; 
           legend('Location','best','FontName','Times New Roman','FontSize',10);
            hold off;
        end
    end
end