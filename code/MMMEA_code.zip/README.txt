Welcome to access Hu Peng's Homepage, https://whuph.github.io/index.html,
Our papers and codes are avaliable on the website. 

It is worth noting that the simple demo of MMMEA needs to run on modified PlatEMO v2.9.

If you find this code useful in your work, please cite the 
following paper  "H. Peng, S. Zhang, L. Li, B. Qu, X. Yue, Z. Wu, Multi-strategy multi-modal multi-objective evolutionary algorithm using macro and micro archive sets, Information Sciences 663 (2024) 120301".