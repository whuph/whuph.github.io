Welcome to access Hu Peng's Homepage, https://whuph.github.io/index.html,
Our papers and codes are avaliable on the website. 

It is worth noting that the simple demo of MMODE_SPDN needs to run on modified PlatEMO v2.9.

If you find this code useful in your work, please
 cite the following paper "H. Peng, W. Xia, Z. Luo, C. Deng, H. Wang, Z. Wu, A multimodal multi-objective differential evolution with series-parallel combination and dynamic neighbor strategy, Information Sciences, 2024".
