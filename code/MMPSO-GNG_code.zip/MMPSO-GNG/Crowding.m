function CD = Crowding(Pop)
    N = size(Pop,1);
    Dist = pdist2(Pop,Pop);
    Dist(logical(eye(size(Pop,1)))) = inf;
    Dist = sort(Dist,2);
    CD = 1./(sum(Dist(:,1:floor(sqrt(N))),2)+2);
end