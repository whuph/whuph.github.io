function [Net, Params] = GNGInitialization(Population)
    Params.eta_winner = 0.2; 
    Params.eta_neighbor = 0.006;
    Params.lambda = 30;
    Params.alpha = 0.5;
    Params.gamma = 0.995;
    Params.maxAge = 30;

    nodeCount = 2;
    [~, Net.node] = kmeans(Population.decs, nodeCount, 'Distance', 'cityblock');
    Net.edge = zeros(nodeCount, nodeCount);
    Net.age = zeros(nodeCount, nodeCount);
    Net.error = zeros(nodeCount, 1);
    Net.ageSumBefore = zeros(nodeCount, 1);
    Net.activityRank = zeros(nodeCount, 1);
    Net.inputCounter = 0;
end
