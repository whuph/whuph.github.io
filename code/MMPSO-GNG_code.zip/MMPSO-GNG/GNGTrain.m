function Net = GNGTrain(Population, Net, Params, Problem)
    N = Problem.N;
    gen = ceil(Problem.FE / Problem.N);
    maxgen = ceil(Problem.maxFE / Problem.N);
    maxN = 1.5;
    node = Net.node;
    error = Net.error;
    edge = Net.edge;
    age = Net.age;
    ageSumBefore = Net.ageSumBefore;
    activityRank = Net.activityRank;
    inputCounter = Net.inputCounter;
    eta_winner = Params.eta_winner;
    eta_neighbor = Params.eta_neighbor;
    lambda = Params.lambda;
    alpha = Params.alpha;
    gamma = Params.gamma;
    maxAge = Params.maxAge;

    for i = 1:size(node, 1)
        neighbor = edge(i, :) == 1;
        ageSum(i, :) = sum(age(i, neighbor, :), 2);
        if ageSum(i, :) == ageSumBefore(i, :)
            activityRank(i, :) = activityRank(i, :) + 1;
        end
    end
    ageSumBefore = ageSum;

    if gen <= round(0.9 * maxgen)
        maxIter = 1;
        maxPZ = maxN;
        if size(node, 1) == round(maxN * N)
            [~, idx] = sort(activityRank, 'descend');
            r = idx(1:round(maxN * N) - N);
            edge(r, :) = [];
            edge(:, r) = [];
            age(r, :) = [];
            age(:, r) = [];
            node(r, :) = [];
            error(r) = [];
            ageSumBefore(r, :) = [];
            activityRank(r, :) = [];
            activityRank = zeros(N, 1);
        end
    else
        if size(node, 1) < round(maxN * N)
            maxPZ = maxN;
            maxIter = 1;
        else
            maxPZ = 1;
            maxIter = 0;
        end
        if size(node, 1) == round(maxN * N)
            maxPZ = 1;
            maxIter = 0;
        end
    end

    [FrontNo,~]=NDSort(Population.objs,N);
    NDPopulation=Population(FrontNo==1);
    Data = NDPopulation.decs;

    for iter = 1:maxIter
        for i = 1:length(Data)
            inputCounter = inputCounter + 1;
            input = Data(i, :);
            dist = pdist2(input, node);
            [~, idx] = sort(dist);
            s1 = idx(1);
            s2 = idx(2);
            error(s1) = error(s1) + dist(s1) ^ 2;
            node(s1, :) = node(s1, :) + eta_winner * (input - node(s1, :));
            neighbor = find(edge(s1, :) == 1);
            for j = neighbor
                node(j, :) = node(j, :) + eta_neighbor * (input - node(j, :));
            end
            age(s1, :) = age(s1, :) + 1;
            age(:, s1) = age(:, s1) + 1;
            edge(s1, s2) = 1;
            edge(s2, s1) = 1;
            age(s1, s2) = 0;
            age(s2, s1) = 0;
            edge(age > maxAge) = 0;
            aloneNodes = (sum(edge) == 0);
            if any(aloneNodes)
                edge(aloneNodes, :) = [];
                edge(:, aloneNodes) = [];
                age(aloneNodes, :) = [];
                age(:, aloneNodes) = [];
                node(aloneNodes, :) = [];
                error(aloneNodes) = [];
                ageSumBefore(aloneNodes, :) = [];
                activityRank(aloneNodes, :) = [];
            end

            if mod(inputCounter, lambda) == 0 && size(node, 1) < round(maxPZ * N)
                [~, q] = max(error);
                [~, f] = max(edge(:, q) .* error);
                r = size(node, 1) + 1;
                node(r, :) = (node(q, :) + node(f, :)) / 2;
                edge(q, f) = 0;
                edge(f, q) = 0;
                edge(q, r) = 1;
                edge(r, q) = 1;
                edge(r, f) = 1;
                edge(f, r) = 1;
                age(r, :) = 0;
                age(:, r) = 0;
                error(q) = alpha * error(q);
                error(f) = alpha * error(f);
                error(r) = error(q);
                ageSumBefore(r, :) = 0;
                activityRank(r, :) = 0;
                if mod(inputCounter, 2 * lambda) == 0 && size(node, 1) < round(maxPZ * N)
                    edgeSum=sum(edge);
                    [~, q] = min(edgeSum);

                    D = pdist2(node, node, 'cityblock');
                    D(logical(eye(length(D)))) = inf;
                    D = D(q, :);
                    D(edge(q, :) == 1) = inf;
                    D(edge(:, q) == 1) = inf;
                    [~, f] = min(D);

                    r = size(node, 1) + 1;
                    node(r, :) = (node(q, :) + node(f, :)) / 2;
                    edge(q, f) = 0;
                    edge(f, q) = 0;
                    edge(q, r) = 1;
                    edge(r, q) = 1;
                    edge(r, f) = 1;
                    edge(f, r) = 1;
                    age(r, :) = 0;
                    age(:, r) = 0;
                    error(q) = alpha * error(q);
                    error(f) = alpha * error(f);
                    error(r) = error(q);
                    ageSumBefore(r, :) = 0;
                    activityRank(r, :) = 0;
                end
            end
            error = error * gamma;
        end
    end
    Net.node = node;
    Net.edge = edge;
    Net.age = age;
    Net.error = error;
    Net.ageSumBefore = ageSumBefore;
    Net.activityRank = activityRank;
    Net.inputCounter = inputCounter;
end