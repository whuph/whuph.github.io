classdef MMPSOGNG < ALGORITHM
% <2025> <multi> <real/integer> <multimodal>
%------------------------------- Reference --------------------------------
% Li, M., Peng, H., Peng, D., Wu, Z. (2026). Multi-modal Multi-objective 
% Particle Swarm Optimization Using Growing Neural Gas Network. 
% In: Mei, Y., Qian, C., Bai, Q., Xue, B., Khanna, S. (eds) PRICAI 2025: 
% Trends in Artificial Intelligence. PRICAI 2025. Lecture Notes in 
% Computer Science(), vol 16452. Springer, Singapore. 
% https://doi.org/10.1007/978-981-95-7072-0_2

% This function is written by Mengfan Li
    methods
        function main(Algorithm, Problem)
            n_PBA = Algorithm.ParameterSet(5);
            n_NBA = Algorithm.ParameterSet(10);
            mv = 0.5 * (Problem.upper - Problem.lower);
            Vmin = -mv;
            Vmax = mv;
            ParticleDec = Problem.lower + (Problem.upper - Problem.lower) .* rand(Problem.N, Problem.D);
            ParticleVel = Vmin + 2 .* Vmax .* rand(Problem.N, Problem.D);

            %% Initialization
            Particle = Problem.Evaluation(ParticleDec, ParticleVel);
            PBA = cell(1, Problem.N); % personal best archive
            NBA = cell(1, Problem.N); % neighborhood best archive

            for i = 1:Problem.N
                PBA{i} = Particle(i);
                NBA{i} = Particle(i);
            end

            [Net, Params] = GNGInitialization(Particle);
            Archive = Particle;
            MaxGen = ceil(Problem.maxFE/Problem.N);
            gen = 0;
            %% Optimization
            while Algorithm.NotTerminated(Archive)
                gen = gen + 1;
                Net = GNGTrain([Archive, Particle], Net, Params, Problem);
                [Particle, PBA, NBA] = Net_Based_Generator(Particle, PBA, NBA, n_PBA, n_NBA, Net, Problem);
               if gen > 0.2 * MaxGen
                    MatingPool = randi(length(Net.node),1,Problem.N);
                    Offspring = Problem.Evaluation(OperatorGAhalf(Problem,Net.node(MatingPool,:)));
                     Archive = Net_Based_Selector([Archive, Particle,Offspring], Net, Problem.N);
               else
                    Archive = Net_Based_Selector([Archive, Particle], Net, Problem.N);
               end
            end
        end
    end
end
