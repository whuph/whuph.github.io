function [Particle, PBA, NBA] = Net_Based_Generator(Particle, PBA, NBA, n_PBA, n_NBA, Net, Problem)
    [N, ~] = size(Particle.decs);
    node = Net.node;
    nodeN = size(node, 1);

    distPN = pdist2(Particle.decs, node);
    [~, idx2] = min(distPN, [], 2);
    C = cell(nodeN, 1);

    for i = 1:N
        nodeIdx = idx2(i);
        C{nodeIdx} = [C{nodeIdx}, i];
    end

    distNN = pdist2(node, node);
    distNN (distNN == 0) = Inf;
    nodeNeighbors = zeros(nodeN, 2);

    for i = 1:nodeN
        [~, idx1] = sort(distNN(i, :));
        nodeNeighbors(i, :) = idx1(1:2);
    end

    for i = 1:N
        closestNode = idx2(i);
        neighborNodes = nodeNeighbors(closestNode, :);
        neighbor = [C{closestNode}, C{neighborNodes(1)}, C{neighborNodes(2)}];
        neighbor(neighbor == i) = [];
        tempNBA = [NBA{i}, Particle(neighbor)];
        [tempNBA, FrontNo, SpCrowdDis] = non_domination_scd_sort(tempNBA, n_NBA);
        [~, index] = sortrows([FrontNo; -SpCrowdDis]');
        NBA{i} = tempNBA(index);
    end

    newParticle = ParticleUpdate(Problem, Particle, PBA, NBA);

    for i = 1:N
        tempPBA = [PBA{i}, newParticle(i)];
        [tempPBA, FrontNo, SpCrowdDis] = non_domination_scd_sort(tempPBA, n_PBA);
        [~, index] = sortrows([FrontNo; -SpCrowdDis]');
        PBA{i} = tempPBA(index);
    end
    Particle=newParticle;
end


function Offspring = ParticleUpdate(Problem, Particle, PBA, NBA)
    ParticleDec = Particle.decs;
    [N, D] = size(ParticleDec);
    PbestDec = zeros(N, D);
    NbestDec = zeros(N, D);

    for i = 1:N
        PbestDec(i, :) = PBA{i}(1).dec;
        NbestDec(i, :) = NBA{i}(1).dec;
    end

    ParticleVel = Particle.adds(zeros(N, D));

    W = repmat(0.7298, N, D);
    r1 = rand(N, D);
    r2 = rand(N, D);
    C1 = repmat(2.05, N, D);
    C2 = repmat(2.05, N, D);
    OffVel = W .* ParticleVel + C1 .* r1 .* (PbestDec - ParticleDec) + C2 .* r2 .* (NbestDec - ParticleDec);
    delta = repmat((Problem.upper - Problem.lower) / 2, N, 1);
    OffVel = max(min(OffVel, delta), -delta);
    OffDec = ParticleDec + OffVel;
    Lower = repmat(Problem.lower, N, 1);
    Upper = repmat(Problem.upper, N, 1);
    temp = OffDec < Lower;
    OffDec(temp) = Lower(temp) + 0.25 * (Upper(temp) - Lower(temp)) .* rand(size(OffDec(temp)));
    temp = OffDec > Upper;
    OffDec(temp) = Upper(temp) - 0.25 * (Upper(temp) - Lower(temp)) .* rand(size(OffDec(temp)));
    Offspring = Problem.Evaluation(OffDec, OffVel);
end
