function Archive = Net_Based_Selector(Particle, Net, N)
    Fitness = CalFitness(Particle);
    Next = Fitness < 1;
    if sum(Next) < N
        [~,Rank] = sort(Fitness);
        Next(Rank(1:N)) = true;
    elseif sum(Next) > N
%         Del  = Truncation(Particle(Next),sum(Next)-N, Net);
        Del = Truncation2(Particle(Next).objs,Particle(Next).decs,sum(Next)-N);
        Temp = find(Next);
        Next(Temp(Del)) = false;
    end
    Archive = Particle(Next);
end

function Del = Truncation(Pop, K, Net)
    node = Net.node;
    nodeN = size(node, 1);
    [FrontNo,~]=NDSort(Pop.objs,length(Pop.objs));
    NDPop = FrontNo ==1;
    Pop = Pop(NDPop);
    PopDec = Pop.decs;
    distPN = pdist2(PopDec, node, 'cityblock');
    [~, idx] = min(distPN, [], 2);
    C = cell(nodeN, 1);
    for i = 1:length(PopDec)
        nodeIdx = idx(i);
        C{nodeIdx} = [C{nodeIdx}, i];
    end
    Del = false(1, length(PopDec));
    while sum(Del) < K
        clusterSizes = zeros(nodeN, 1);
        for i = 1:nodeN
            clusterSizes(i) = sum(~Del(C{i}));
        end
        [~, mostCrowded] = max(clusterSizes);
        cluster = C{mostCrowded};
        cluster = cluster(~Del(cluster));
        if isempty(cluster)
            continue;
        end
        distObj = pdist2(Pop(cluster).objs, Pop(cluster).objs, 'cityblock');
        distObj(logical(eye(length(distObj)))) = inf;
        minDist = min(distObj, [], 2);
        [~, minIdx] = min(minDist);
        Del(cluster(minIdx)) = true;
    end
end
function Del = Truncation2(PopObj,PopDec,K)
    Distance_Pop = pdist2(PopObj,PopObj);
    Distance_Pop(logical(eye(length(Distance_Pop)))) = inf;
    
    Distance_Dec = pdist2(PopDec,PopDec);
    Distance_Dec(logical(eye(length(Distance_Dec)))) = inf;
    
    D = Distance_Pop + Distance_Dec;
    
    Del = false(1,size(PopObj,1));
    while sum(Del) < K
        Remain   = find(~Del);
        Temp     = sort(D(Remain,Remain),2);
        [~,Rank] = sortrows(Temp);
        Del(Remain(Rank(1))) = true;
    end
end

