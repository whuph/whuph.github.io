Welcome to Hu Peng's Homepage at https://whuph.github.io/. Our research papers and the corresponding codes are publicly available on this website.

This repository includes the MMPSO-GNG folder, which contains the main code of the MMPSO-GNG algorithm and the implementation for constructing the Growing Neural Gas (GNG) network.

NOTE: Users are encouraged to adapt the code to their specific problem domains while maintaining proper attribution. If the code implementation contributes to your research, please cite our paper: Li, M., Peng, H., Peng, D., Wu, Z. (2026). Multi-modal Multi-objective Particle Swarm Optimization Using Growing Neural Gas Network. In: Mei, Y., Qian, C., Bai, Q., Xue, B., Khanna, S. (eds) PRICAI 2025: Trends in Artificial Intelligence. PRICAI 2025. Lecture Notes in Computer Science(), vol 16452. Springer, Singapore. https://doi.org/10.1007/978-981-95-7072-0_2.

Furthermore, if the initialization and training code of the Growing Neural Gas Network—which incorporates our specific innovations—is utilized, it should also be acknowledged by citing our paper.

This implementation is based on the PlatEMO platform: Ye Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, "PlatEMO: A MATLAB Platform for Evolutionary Multi‑Objective Optimization", IEEE Computational Intelligence Magazine, 2017, 12(4): 73‑87.