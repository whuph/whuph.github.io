
function MSEFA
% This is a simple demo of MSEFA
%--------------------------------------------------------------------------------------------------------
% If you find this code useful in your work, please cite the 
% following paper by the author of the code "Peng H, Xiao W, Han Y, et al. 
% Multi-strategy firefly algorithm with selective ensemble for complex engineering optimization problems[J]. 
% Applied Soft Computing, 2022. 
%--------------------------------------------------------------------------------------------------------
% This function is implmented by Wenhui Xiao
%--------------------------------------------------------------------------------------------------------
% More information can visit H Peng's homepage: https://whuph.github.io/index.html
%--------------------------------------------------------------------------------------------------------

tic; 
fprintf('Now is running MSEFA\n');

fhd=str2func('cec13_func'); % two parameters can be set, cec13_func or yao_13
fun=16;
% for cec13_func
funopt = [-1400,-1300,-1200,-1100,-1000,-900,-800,-700,-600,-500,-400,-300,-200,-100,100,200,300,400,500,600,700,800,900,1000,1100,1200,1300,1400];
Xmin = [-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100];

%% Parameter setting for algorithm

n=20;               % The size of population
D=30;               % The size of dimension

s1=1;               %The priority of the first strategy
s2=1;               %The priority of the second strategy
s3=1;               %The priority of the third strategy

alpha=0.5;
gamma=1;
beta0=1;
betamin=0.2;

FES_max = 5.0E5;         % The maximum number of function evaluations
FES = 0;             % The current number of function evaluations
G = FES_max/(2*n);  % The maximum number of iterations
t = 1;              % The current number of iterations

Kmax=0.3;           
Kmin=0.1;
Kmid=0.2;
K=Kmid;
flag=-1;
%% Simple bounds of the search domain
lb=Xmin(fun);
ub=-lb;

pop = lb + rand(n,D).*(ub - lb);  %Generate the population randomly

%% Evaluate new solutions
Light=zeros(1,n);
for i=1:n 
    Light(i)  = feval(fhd,pop(i,:)',fun);    
end            
%% Sort the population                  
p=fix(rand*3)+1;
[~,Lightsort]=sort(Light);
ibest=pop(Lightsort(p),:); %Randomly selected from the top three in the population 

FES=FES+n;
[GlobalMin,best]=min(Light);
gbest=pop(best,:);%The best individual of the current generation 
PastMin=GlobalMin;%The best solution of the previous generation
%% Starting iterations
 while FES<FES_max && t<G
   t=t+1; 
   alpha=exp(-K*t/G)*alpha;
%% The parameter �� adaptive dynamic update
   if flag==1 && K<Kmax 
       K=K+0.01;
   elseif flag==-1 && K>Kmin
       K=K-0.01;
   end 

   for i=1:n
          pop2(i,:)=pop(i,:);
          for j=1:n
               if Light(i)>Light(j)
              %% Priority roulette wheel selection
                   V=1./[s1,s2,s3];
                   V = V./sum(V);
                   sp=RouletteWheelSelect(V); %Roulette wheel selection
            
                    r = norm(pop(i,:)-pop(j,:));
                    beta=betamin+(beta0-betamin)*exp(-gamma*r^2);
                    
                    rd=randperm(n); %Random selection
                    k=1;
                    if rd(k)~=i
                        rr(k)=rd(k);
                    else
                        rr(k)=rd(2);
                    end
            %% Broad learning strategy
                   if sp==1
                       pop2(i,:)=pop(i,:)+(pop(i,:)-pop(rr(1),:)).*(2*rand-1)+(pop(j,:)-pop(i,:)).*beta+alpha.*(rand(1,D)-0.5).*abs(ub-lb);
                   end
            %% Elite learning strategy
                   if sp==2
                       pop2(i,:)=pop(i,:)+(gbest-pop(rr(1),:)).*(2*rand-1)+(pop(j,:)-pop(i,:)).*beta+alpha.*(rand(1,D)-0.5).*abs(ub-lb);
                   end
            %% Coordinated learning strategy
                   if sp==3
                       pop2(i,:)=pop(rr(1),:)+(ibest-pop(rr(1),:)).*beta+alpha.*(rand(1,D)-0.5).*abs(ub-lb);
                   end
                pop2(i,:) = ( (pop2(i,:) >= lb) & (pop2(i,:) <= ub) ) .* pop2(i,:)...
                       + (pop2(i,:) < lb) .* ( lb + (ub-lb) .* rand(1,D) )...
                       + (pop2(i,:) > ub) .* ( lb + (ub-lb) .* rand(1,D) );
                   
                Light2(i) = feval(fhd,pop2(i,:)',fun);
              %% Greedy Selection    
                if Light2(i)<Light(i)
                    Light(i)=Light2(i);
                    pop(i,:)=pop2(i,:);
                    if sp==1
                        s1=s1+1;
                    elseif sp==2
                        s2=s2+1;
                    elseif sp==3
                        s3=s3+1;
                    end
                
                end  
               FES=FES+1;
              end
         end % end for j            
    end % end for i
%% Upset
    s1=1;
    s2=1;
    s3=1;
%% Sort the population
     p=fix(rand*3)+1;
     [~,Lightsort]=sort(Light);
     ibest=pop(Lightsort(p),:);%Randomly selected from the top three in the population
     gbest=pop(Lightsort(1),:);%The best individual of the current generation
%% Memorize Best
    [CycleMin,~]=min(Light);
    if CycleMin<PastMin 
    else
        flag=-flag;    
    end
    PastMin=CycleMin;%The best solution of the previous generation
    if CycleMin<GlobalMin 
       GlobalMin=CycleMin; 
    end 
 end %% End of iterations
 
GlobalMin=GlobalMin-funopt(fun);
fprintf('best value=%d\n',GlobalMin);
CPUtime   = toc;
end
%% Roulette Wheel Selection
function index = RouletteWheelSelect(Fitness)
    Fitness = reshape(Fitness,1,[]);
    Fitness = cumsum(1./Fitness);
    Fitness = Fitness./max(Fitness);
    index   = arrayfun(@(S)find(rand<=Fitness,1),1);
end
