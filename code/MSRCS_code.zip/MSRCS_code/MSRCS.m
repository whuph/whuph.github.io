function MSRCS
% 2021-1-14 programming by YuanHan Li

tic;
fprintf('Now is running MSRCS\n');

fhd=str2func('cec13_func');
fun=1;
% for cec13_func
funopt = [-1400,-1300,-1200,-1100,-1000,-900,-800,-700,-600,-500,-400,-300,-200,-100,100,200,300,400,500,600,700,800,900,1000,1100,1200,1300,1400];
Xmin = [-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100];

%------------------- Parameter settings------------------------%
n=20;       % Number of nests
d=30;       % Number of dimension
pa=0.25;    % Discovery rate of alien eggs/solutions

p_1 = 0.8;
p_2 = 0.5;

FE_max = 1E6;           % The maximum number of function evaluations
FE = 0;                 % The current number of function evaluations
t_max = FE_max/(2*n);   % The maximum number of iterations
t = 1;                  % The current number of iterations

%% Simple bounds of the search domain
lb=Xmin(fun);
ub=-lb;
Lb=lb*ones(1,d);    % Lower bounds
Ub=ub*ones(1,d);    % Upper bounds

% Random initial solutions
for i=1:n
    nest(i,:)=Lb+(Ub-Lb).*rand(size(Lb));
end

fitness=10^10*ones(n,1);
[fmin,bestnest,nest,fitness]=get_best_nest(nest,nest,fitness,fhd, fun);
FE=FE+n;

outcome=[];

%% Starting iterations
while FE<FE_max && t<t_max
    t=t+1;
    
    % linear decreasing probability rule
    if rand<=(1-t/t_max)
        % reconciliatory strategy 1
        new_nest=get_cuckoos_MSR1(nest,bestnest,Lb,Ub,t,t_max,p_1);
    else
        % reconciliatory strategy 2
        new_nest=get_cuckoos_MSR2(nest,bestnest,Lb,Ub,t,t_max,p_1,p_2);
    end
    % Evaluate this set of solutions
    [fnew,best,nest,fitness]=get_best_nest(nest,new_nest,fitness,fhd, fun);
    % Update the counter
    FE=FE+n;
    
    % Discovery and randomization
    new_nest=empty_nests(nest,Lb,Ub,pa);
    [fnew,best,nest,fitness]=get_best_nest(nest,new_nest,fitness,fhd, fun);
    FE=FE+n;
    
    % Find the best objective so far
    if fnew<fmin
        fmin=fnew;
        bestnest=best;
    end
    
    outcome = [outcome fmin];  % Store the result
end %% End of iterations
GlobalMin=fmin-funopt(fun);
fprintf('best value=%d\n',GlobalMin);
CPUtime = toc;
end

%% --------------- All subfunctions are list below ------------------
%% Get cuckoos by ramdom walk
function nest=get_cuckoos_MSR1(nest,best,Lb,Ub,t,t_max,p_1)
n=size(nest,1);
d=size(nest,2);
beta=3/2;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
for j=1:n
    if rand<p_1
        % Self-adaptive Stepsize
        s=nest(j,:);
        u=randn(size(s))*sigma;
        v=randn(size(s));
        step=u./abs(v).^(1/beta);
        a=0.5*cos((pi/3)*(1+t/(2*t_max)));
        stepsize=a*step.*(s-best);
        s=s+stepsize.*randn(size(s));
        nest(j,:)=simplebounds(s,Lb,Ub);
    else
        % CS-current Strategy
        s=nest(j,:);
        b=ceil(rand(1,2)*n);
        w=s+rand(1,d).*((best-s)+nest(b(1),:)-nest(b(2),:));
        nest(j,:)=simplebounds(w,Lb,Ub);
    end
end
end

function nest=get_cuckoos_MSR2(nest,best,Lb,Ub,t,t_max,p_1,p_2)
n=size(nest,1);
d=size(nest,2);
beta=3/2;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
for j=1:n
    if rand<p_2
        % Self-adaptive Stepsize
        s=nest(j,:);
        u=randn(size(s))*sigma;
        v=randn(size(s));
        step=u./abs(v).^(1/beta);
        a=0.5*cos((pi/3)*(1+t/(2*t_max)));
        stepsize=a*step.*(s-best);
        s=s+stepsize.*randn(size(s));
        nest(j,:)=simplebounds(s,Lb,Ub);
    else
        if rand<p_1
            % CS-best Strategy
            s=nest(j,:);
            b=ceil(rand(1,2)*n);
            w=best+rand(1,d).*((best-nest(b(1),:))+(nest(b(2),:)-s));
            nest(j,:)=simplebounds(w,Lb,Ub);
        else
            % CS-rand Strategy
            s=nest(j,:);
            b=ceil(rand(1,4)*n);
            r=rand();
            w=r*nest(b(1),:)+(1-r)*nest(b(2),:)+rand*rand(1,d).*((nest(b(3),:)-s)+(nest(b(4),:)-s));
            nest(j,:)=simplebounds(w,Lb,Ub);
        end
    end
end
end

%% Find the current best nest
function [fmin,best,nest,fitness]=get_best_nest(nest,newnest,fitness,fhd, fun)
% Evaluating all new solutions
for j=1:size(nest,1)
    fnew=feval(fhd,newnest(j,:)',fun);
    if fnew<=fitness(j)
       fitness(j)=fnew;
       nest(j,:)=newnest(j,:);
    end
end
% Find the current best
[fmin,K]=min(fitness) ;
best=nest(K,:);
end

%% Replace some nests by constructing new solutions/nests
function new_nest=empty_nests(nest,Lb,Ub,pa)
% A fraction of worse nests are discovered with a probability pa
n=size(nest,1);
% Discovered or not -- a status vector
K=rand(size(nest))>pa;

%% New solution by biased/selective random walks
stepsize=rand*(nest(randperm(n),:)-nest(randperm(n),:));
new_nest=nest+stepsize.*K;
for j=1:n
    new_nest(j,:)=simplebounds(new_nest(j,:),Lb,Ub);
end
end

% Application of simple constraints
function s=simplebounds(s,Lb,Ub)
% Apply the lower bound
ns_tmp=s;
I=ns_tmp<Lb;
ns_tmp(I)=Lb(I);

% Apply the upper bounds
J=ns_tmp>Ub;
ns_tmp(J)=Ub(J);
% Update this new move
s=ns_tmp;
end