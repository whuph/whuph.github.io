Welcome to access Hu Peng's Homepage, https://whuph.github.io/index.html,
Our papers and codes are avaliable on the website. 

If you find this code useful in your work, please cite the 
following paper "PENG Hu, LI Yuanhan, DENG Changshou, WU Zhijian. 
Multi-strategy reconciliatory cuckoo search algorithm[J]. 
Computer Engineering, 2021, DOI:10.19678/j.issn.1000-3428.0061622".