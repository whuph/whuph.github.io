
function MSSCS
% This is a simple demo of MSSCS
%--------------------------------------------------------------------------------------------------------
% If you find this code useful in your work, please cite the 
% following paper "Peng H, Zeng Z, Deng C, et al. 
% Multi-strategy serial cuckoo search algorithm for global optimization[J]. 
% Knowledge-Based Systems, 2020, DOI:10.1016/j.knosys.2020.106729".
%--------------------------------------------------------------------------------------------------------
% This function is implmented by Zhaogan Zeng
%--------------------------------------------------------------------------------------------------------


tic; 
fprintf('Now is running MSSCS\n');

fhd=str2func('cec13_func'); % two parameters can be set, cec13_func or yao_13
fun=1;
% for cec13_func
funopt = [-1400,-1300,-1200,-1100,-1000,-900,-800,-700,-600,-500,-400,-300,-200,-100,100,200,300,400,500,600,700,800,900,1000,1100,1200,1300,1400];
Xmin = [-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100,-100];

%------------------- Parameter settings------------------------%

N=25;               % Number of nests (or different solutions)
D=30;               % Number of dimension
pa=0.25;            % The switch parameter(Probability that the host bird discovers the egg)

PA_max = 0.35;
PA_min = 0.25;
PA = PA_min + (PA_max - PA_min)*(1/D);
T = N/2.5;          % Threshold T

FES = 100000;         % The maximum number of function evaluations
FE = 0;             % The current number of function evaluations
MaxIt = FES/(2*N);  % The maximum number of iterations
t = 1;              % The current number of iterations

%% Simple bounds of the search domain

lb=Xmin(fun);
ub=-lb;
Lb=lb*ones(1,D);   % Lower bounds
Ub=ub*ones(1,D);   % Upper bounds

% Random initial solutions
for i=1:N
    nest(i,:)=Lb+(Ub-Lb).*rand(size(Lb));
end              
                 
fitness=10^10*ones(N,1);
[fmin,bestnest,nest,fitness,SP,worstnest]=get_best_nest(nest,nest,fitness,fhd, fun);

outcome=[];

%% Starting iterations

%% -------------------The following is: Multi-strategy serial--------------------
L=0;
while FE<FES
    if L == 0
        if SP >= T
            if t < PA*MaxIt 
                % the update of solution by using Saltation learning
                new_nest = SL(nest,bestnest,worstnest,Lb,Ub);   
            elseif t>=PA*MaxIt && t<=(1-PA)*MaxIt
                % the update of solution by using GaussIan walk learning
                new_nest = GWL(nest,bestnest,worstnest,Lb,Ub,t,MaxIt);
            else
                % the update of solution by using Single dimension learning
                new_nest = SDL(nest,bestnest,worstnest,Lb,Ub);
            end
            [fnew,best,nest,fitness,SP,worstnest]=get_best_nest(nest,new_nest,fitness,fhd, fun);
            % the update of the current number of function evaluations
            FE = FE + N;
        else
            L = 1;
        end
        
    else
        new_nest=get_cuckoos(nest,bestnest,Lb,Ub);
        [fnew,best,nest,fitness,SP,worstnest]=get_best_nest(nest,new_nest,fitness,fhd, fun);
        L = L-1;
        FE = FE + N;
    end
     
     new_nest=empty_nests(nest,Lb,Ub,pa);
     
    % Evaluate this set of solutions
     [fnew,best,nest,fitness,~,worstnest]=get_best_nest(nest,new_nest,fitness,fhd, fun);
     FE = FE + N;
     t = t + 1;
     
    % Find the best objective so far   
    if fnew<fmin
        fmin=fnew;
        bestnest=best;
    end
    
    outcome = [outcome fmin];  % Store the result
end %% End of iterations
%% -------------------The above for: Multi-strategy serial--------------------
GlobalMin=fmin-funopt(fun);
fprintf('best value=%d\n',GlobalMin);
CPUtime   = toc;
end


%% --------------- All subfunctions are list below ------------------

%% Saltation learning
function nest = SL(nest,best,worst,Lb,Ub)
[N,D]=size(nest);
for i=1:N
   R = randperm(D,3);
   j = R(1);
   m = R(2);
   n = R(3);
   r=2*rand-1;
   r1=fix(N*rand)+1;
   nest(i,j)=best(m)+r*(nest(r1,n)-worst(n));
   nest(i,:)=simplebounds(nest(i,:),Lb,Ub);
end
end

%% GaussIan walk learning
function nest=GWL(nest,best,worst,Lb,Ub,t,t_max)
N = size(nest,1);
for j=1:N
    s=nest(j,:);
    ga=best+0.2*exp(-t/t_max)*(s-worst).*randn(size(s));
    r1=rand;
    r2=rand;
    s=ga+(r1*best-r2*s).*randn(size(s));
    nest(j,:)=simplebounds(s,Lb,Ub);
end
end

%% Single dimension learning
function nest = SDL(nest,best,worst,Lb,Ub)
[N,D]=size(nest);
for i=1:N
   j=fix(D*rand)+1;
   r=2*rand-1;
   r1=fix(N*rand)+1;
   nest(i,j)=best(j)+r*(nest(r1,j)-worst(j));
   nest(i,:)=simplebounds(nest(i,:),Lb,Ub);
end
end

%% Get cuckoos by ramdom walk
function nest=get_cuckoos(nest,best,Lb,Ub)
% Levy flights
n=size(nest,1);
% Levy exponent and coefficient
beta=3/2;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);

for j=1:n
    s=nest(j,:);

    %% Levy flights by Mantegna's algorithm
    u=randn(size(s))*sigma;
    v=randn(size(s));
    step=u./abs(v).^(1/beta);   
    stepsize=0.01*step.*(s-best);
    s=s+stepsize.*randn(size(s));
   % Apply simple bounds/limits
   nest(j,:)=simplebounds(s,Lb,Ub);
end
end

 
%% Find the current best nest
function [fmin,best,nest,fitness,SP,worst]=get_best_nest(nest,newnest,fitness,fhd, fun)
% Evaluating all new solutions
SP=0;
for j=1:size(nest,1)
    fnew=feval(fhd,newnest(j,:)',fun);
    if fnew<=fitness(j)
       fitness(j)=fnew;
       nest(j,:)=newnest(j,:);
    else
        SP=SP+1;
    end
end

% Find the current best
[fmin,K]=min(fitness) ;
[~,h]=max(fitness);
best=nest(K,:);
worst=nest(h,:);

end


%% Replace some nests by constructing new solutions/nests
function new_nest=empty_nests(nest,Lb,Ub,pa)
% A fraction of worse nests are discovered with a probability pa
n=size(nest,1);
% Discovered or not -- a status vector
K=rand(size(nest))>pa;
%% New solution by biased/selective random walks
stepsize=rand*(nest(randperm(n),:)-nest(randperm(n),:));
new_nest=nest+stepsize.*K;
for j=1:n
    new_nest(j,:)=simplebounds(new_nest(j,:),Lb,Ub);
end
end

%% Application of simple constraints
function s=simplebounds(s,Lb,Ub)
  % Apply the lower bound
  ns_tmp=s;
  I=ns_tmp<Lb;
  ns_tmp(I)=Lb(I);
  
  % Apply the upper bounds 
  J=ns_tmp>Ub;
  ns_tmp(J)=Ub(J);  

  % Update this new move 
  s=ns_tmp;
end