Welcome to access Hu Peng's Homepage, https://whuph.github.io/index.html,
Our papers and codes are avaliable on the website. 

If you find this code useful in your work, please cite the 
following paper "Peng H, Zeng Z, Deng C, et al. 
Multi-strategy serial cuckoo search algorithm for global optimization[J]. 
Knowledge-Based Systems, 2020, DOI:10.1016/j.knosys.2020.106729".