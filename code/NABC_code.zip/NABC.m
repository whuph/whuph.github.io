function [GlobalMin, outcome, CPUtime] = NABC(fhd, fun, lb, ub)
%--------------------------------------------------------------------------------------------------------
% 2016-8-12 programming by Hu Peng at JJU
%--------------------------------------------------------------------------------------------------------
% Peng H, Deng C*, Wu Z. Best neighbor guided artificial bee colony algorithm for continuous optimization problems[J]. 
% Soft computing, 2019,23(18):8723-8740.
%--------------------------------------------------------------------------------------------------------
% More information can visit H Peng's homepage: https://whuph.github.io/index.html
%--------------------------------------------------------------------------------------------------------
    tic;

    global initial_flag
    initial_flag = 0;

    Dim  = 30;
    SN = Dim;    
    Limit = 50;
    N=5;
    
    nfevalmax = 5000*Dim;

    outcome = [];
    
    Employed = lb + rand(SN,Dim).*(ub - lb);
    
    Bas=zeros(1,(SN));

    FitEmp = zeros(1,SN); 
    for i=1:SN 
        FitEmp(i)  = feval(fhd,Employed(i,:),fun);
    end
    [GlobalMin,BestInd]=min(FitEmp);
    GlobalPara=Employed(BestInd,:);
    nfeval=SN;
    cycle=1;
 
    while nfeval <nfevalmax
        
       %% Employed phase
        for i=1:SN
            Param2Change=fix(rand*Dim)+1;

            rd=randperm(SN);
            [~,id]=min(FitEmp(rd(1:N)));
            neighbour=rd(id);
            
            Employed2(i,:)=Employed(i,:);
                Employed2(i,Param2Change)=Employed(neighbour,Param2Change)+(Employed(neighbour,Param2Change)-Employed(i,Param2Change))*(rand-0.5)*2;
                
            if (Employed2(i,Param2Change)<lb || Employed2(i,Param2Change)>ub)
                Employed2(i,Param2Change)=lb+rand*(ub-lb);
            end;
            
            FitEmp2(i) = feval(fhd,Employed2(i,:),fun);
            nfeval  = nfeval + 1;
            if (FitEmp2(i)<FitEmp(i))
                Bas(i)=0;
                FitEmp(i)=FitEmp2(i);
                Employed(i,:)=Employed2(i,:);
            else
                Bas(i)=Bas(i)+1;
            end;            
        end;

      
        %Normalize
        fFitness=calculateFitness(FitEmp);
        NormFit=fFitness./sum(fFitness);
        
       %% Onlooker phase  
        i=1;
        t=0;
        while(t<SN)
            if(rand<NormFit(i))
                t=t+1;
                Param2Change=fix(rand*Dim)+1;

                rd=randperm(SN);
                [~,id]=min(FitEmp(rd(1:N)));
                neighbour=rd(id);

                Employed2(i,:)=Employed(i,:);                
                Employed2(i,Param2Change)=Employed(neighbour,Param2Change)+(Employed(neighbour,Param2Change)-Employed(i,Param2Change))*(rand-0.5)*2;
                
                if (Employed2(i,Param2Change)<lb || Employed2(i,Param2Change)>ub)
                    Employed2(i,Param2Change)=lb+rand*(ub-lb);
                end;
                
                FitEmp2(i) = feval(fhd,Employed2(i,:),fun);
                nfeval  = nfeval + 1;
                if (FitEmp2(i)<FitEmp(i))
                    Bas(i)=0;
                    FitEmp(i)=FitEmp2(i);
                    Employed(i,:)=Employed2(i,:);
                else
                    Bas(i)=Bas(i)+1;
                end;
            end;

            i=i+1;
            if (i==SN+1) 
               i=1;
            end;   
         end;
         
         
        %% Scout phase
         for i=1:SN
             if (Bas(i)>Limit)
                Bas(i)=0;
                
                rd = randperm(SN);
                for j=1:2
                    if rd(j)~=i; r(j) = rd(j);
                    else r(j) = rd(3); end
                end
                r1=rand; r2=rand*(1-r1);r3=1-r1-r2;
                for j=1:Dim
                    Employed(i,j)=r1*Employed(i,j)+r2*GlobalPara(j)+r3*(Employed(r(1),j)-Employed(r(2),j));
                    if (Employed(i,j)<lb || Employed(i,j)>ub)
                        Employed(i,j)=lb+rand*(ub-lb);
                    end;
                end
                FitEmp(i) = feval(fhd,Employed(i,:),fun);
                
%                 Employed(i,:)=lb+rand(1,Dim)*(ub-lb);
%                 FitEmp(i) = feval(fhd,Employed(i,:),fun);
                
                nfeval = nfeval + 1;
             end;
         end
                 
        %% Memorize Best
         [CycleMin,BestInd]=min(FitEmp);
         if CycleMin<GlobalMin 
            GlobalMin=CycleMin;
            GlobalPara=Employed(BestInd,:);
         end
         outcome = [outcome GlobalMin];
         
         cycle=cycle+1;

    end

    CPUtime   = toc;

end

function fFitness=calculateFitness(fObjV)
    fFitness=zeros(size(fObjV));
    ind=find(fObjV>=0);
    fFitness(ind)=1./(fObjV(ind)+1);
    ind=find(fObjV<0);
    fFitness(ind)=1+abs(fObjV(ind));
end