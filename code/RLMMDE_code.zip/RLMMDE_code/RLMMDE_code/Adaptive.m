function Z = Adaptive(PopObj,Z,N,interval)
% Addition and deletion of reference points
    
    M = size(PopObj,2);   
    rho   = Associate(PopObj,Z); % Associate each solution with one reference point    
    
    %% Addition of reference points    
    old_Z = []; 
    while any(rho>=2) && ~isequal(old_Z,Z)
        old_Z = Z;
        for i = find(rho>=2)
            p = repmat(Z(i,:),M,1) - interval/M;
            p(logical(eye(M))) = p(logical(eye(M))) + interval;
            Z = [Z;p];
        end
        Z(any(Z<0,2),:) = []; 
        [~,index]       = unique(roundn(Z,-4),'rows','stable');
        Z               = Z(index,:);
        rho = Associate(PopObj,Z);
    end
    
    %% Deletion of reference points
    Z(intersect(N+1:size(Z,1),find(~rho)),:) = [];
end