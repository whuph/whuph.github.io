function [Z,rho,NoPointSum,originalState,Q] = AdaptiveJudgment(PopObj,Z,gen,maxgen,...
            NoPointSum,originalState,Q,action)  
   
    rho   = Associate(PopObj,Z);
    NoPointSum(1,gen) = size(find(rho==0),2);
    
    if NoPointSum(1,gen) > 50
        nextState = 1;
    else
        nextState = 2;
    end
    
    [Q,originalState]=RL(originalState,Q,nextState,action,gen,maxgen);
end