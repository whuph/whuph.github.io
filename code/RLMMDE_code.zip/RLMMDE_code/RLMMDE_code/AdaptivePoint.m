function Z = AdaptivePoint(PopObj,Z,gen,rho)
    [N,M]  = size(PopObj);
    rho_sum = sum(rho); % ZDT 100 or DTLZ 91
    Noindex = find(rho==0);
    index = find(rho); 
    num = ceil(rho(index)./rho_sum.*length(Noindex));
    sum_num = sum(num);
    
    Remain = true(1,N);
    Remain_1 = 1:N;
    Associate_Z_num = length(index);
    Temp = [];
    while(Associate_Z_num<N)
        for i=1:length(index)
            temp = zeros(num(i),M);
            for j=1:num(i)
                index2 = find_index_with_largest_distance(PopObj(Remain,:),Z(index(i),:));
                temp(j,:) = PopObj(Remain_1(index2),:);
                Remain(Remain_1(index2)) = false;
                Remain_1 = find(Remain);
                Associate_Z_num = Associate_Z_num + 1;
                if (Associate_Z_num >= N)
                    break;
                end 
            end                   
            Temp = [Temp;temp];
        end  
    end
    
    Z(Noindex,:) = [];
    Z = [Z;Temp(randperm(size(Temp,1),N-size(Z,1)),:)];

end
    
function index = find_index_with_largest_distance(PopObj,Z)
    Distance = pdist2(PopObj,Z);
    Temp     = sort(Distance,2);
    [~,Rank] = sortrows(Temp);
    index=Rank(length(Rank));
end