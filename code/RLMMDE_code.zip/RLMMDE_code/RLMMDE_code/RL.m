function [Q,originalState]=RL(originalState,Q,nextState,action,gen,maxgen)
   
    mu = 1-0.9*(gen/maxgen);

    eta = 0.8;

    R = [-10,5;
        -10,5];

    Q(originalState,action)= Q(originalState,action) + ...
        mu * ( R(originalState,nextState) + eta * max(Q(nextState,:)) - ...
        Q(originalState,action) );
    originalState = nextState;
end