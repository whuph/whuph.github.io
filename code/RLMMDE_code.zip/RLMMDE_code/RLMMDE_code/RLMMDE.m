function RLMMDE(Global)
% <algorithm> <M>
% Multi-strategy multi-objective differential evolutionary algorithm with reinforcement learning
%--------------------------------------------------------------------------------------------------------
% If you find this code useful in your work, please cite the following paper " Yupeng Han and Hu Peng and 
% Changrong Mei and Lianglin Cao and Changshou Deng and Hui Wang and Zhijian Wu. Multi-strategy dynamic 
% multi-objective evolutionary algorithm with hybrid environmental change responses. Knowledge-Based
% Systems, 2023 ".
%--------------------------------------------------------------------------------------------------------
% This function is implmented by Yupeng Han
%--------------------------------------------------------------------------------------------------------
% More information can visit Hu Peng's homepage: https://whuph.github.io/index.html
%--------------------------------------------------------------------------------------------------------

    %% Generate the reference points and random population
    % All the reference points
    [Z,Global.N] = UniformPoint(Global.N,Global.M);
    Z = sortrows(Z); 
    % Initial population
    Population = Global.Initialization();
    % Ideal point
    Zmin = min(Population(all(Population.cons<=0,2)).objs,[],1);
    
    %% for RL 
    NoPointSum = []; 
    originalState = 2; 
    Q = zeros(2,2);
    count_adaptive = zeros(1,2); 
    count_actions = zeros(2,2); 

    %% Optimization
    while Global.NotTermination(Population)
        
        parent_Population = Population;               
        % For each solution
        for i = 1 : Global.N     
            
            F = 0.9 + rand*0.1;
            CR = 0.1 + randn*0.1;
            
            scheme2 = randi(3); 
            scheme1 = randi(2); 

            P = randperm(Global.N);
            while ( P(1)==i || P(2)==i || P(3)==i || P(4)==i)
                P = randperm(Global.N);
            end
            
            [FrontNo,~] = NDSort(Population.objs,Global.N);
            [~, index] = find(FrontNo == 1);
            random_one_bestindex = index( randperm(length(index),1) );
            % Generate an offspring            
            Offspring(i) = MCDE(parent_Population(i),...
                parent_Population(random_one_bestindex),parent_Population(P(2)),...
                parent_Population(P(3)),parent_Population(P(4)),F,CR,...
                scheme2,scheme1,Global.lower,Global.upper);          
        end
        
        Zmin       = min([Zmin;Offspring(all(Offspring.cons<=0,2)).objs],[],1);
        Population = EnvironmentalSelection([Population,Offspring],Global.N,Z,Zmin);
        
        if Global.gen > 0.8 * Global.maxgen
            
            [~,action] = max(Q(originalState,:));
            count_actions(originalState,action) = count_actions(originalState,action) + 1;
                        
            [Z,rho,NoPointSum,originalState,Q] = AdaptiveJudgment(Population.objs,Z,Global.gen,Global.maxgen,...
                NoPointSum,originalState,Q,action);
       
            if originalState ==1 && action == 1  
                Z = AdaptivePoint(Population.objs,Z,Global.gen,rho);
                count_adaptive(1,1) = count_adaptive(1,1) + 1;
            elseif originalState ==1 && action == 2
                count_adaptive(1,2) = count_adaptive(1,2) + 1;           
            end         
            
        end          
    end
end