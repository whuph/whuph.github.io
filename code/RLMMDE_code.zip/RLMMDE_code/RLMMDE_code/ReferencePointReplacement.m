function Z = ReferencePointReplacement(PopObj,Z,interval)
% Reference point replacement

    [N,M]  = size(PopObj);
    %% Normalization
    % Detect the extreme points
    Extreme = zeros(1,M);
    w       = zeros(M)+1e-6+eye(M);
    for i = 1 : M
        temp = max(PopObj./repmat(w(i,:),N,1),[],2);
        [~,Extreme(i)] = min(temp);
    end
    % Calculate the intercepts of the hyperplane constructed by the extreme
    % points and the axes
    Hyperplane = PopObj(Extreme,:)\ones(M,1);
    a = 1./Hyperplane;
    if any(isnan(a))
        a = max(PopObj,[],1)';
    end
    % Normalization
    PopObj = PopObj./repmat(a',N,1);
    
    %% Reference point replacement
    [~,associate] = max(1-pdist2(PopObj,Z,'cosine'),[],2);
    inValid       = setdiff(1:size(Z,1),associate); 

    %% Replacement of reference points 
    M = size(PopObj,2);   
    rho   = Associate(PopObj,Z); % Associate each solution with one reference point    
    
    old_Z = []; 
    while any(rho>=2) && ~isequal(old_Z,Z)
        old_Z = Z;
        for i = find(rho>=2)
            p = repmat(Z(i,:),1,1) - interval/M;
            p(logical(eye(1))) = p(logical(eye(1))) + interval;
            Z = [Z;p];
        end
        Z(any(Z<0,2),:) = []; 
        [~,index]       = unique(roundn(Z,-4),'rows','stable');
        Z               = Z(index,:);
        rho = Associate(PopObj,Z);
    end
    
    for i = 1:length( Z(length(PopObj)+1:size(Z,1)) )
        Z(inValid(i),:) = Z(length(PopObj)+i,:);
    end
    
    Z = Z(1:length(PopObj),:);
    
end