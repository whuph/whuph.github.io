function ind = gaussian_mutation( ind,lower,upper)
%GAUSSIAN_MUTATE Summary of this function goes here
%Detailed explanation goes here

    x=ind;
   parDim = length(upper);
   sigma = (upper-lower)./20;
   prob=1/parDim;
   newparam = min(max(normrnd(x, sigma), lower), upper);
   C = rand(parDim, 1)<prob;
   x(C) = newparam(C);
   ind=x;
end
    