function RNDE
% This is a simple demo of RNDE
%--------------------------------------------------------------------------------------------------------
% If you find this code useful in your work, please cite the 
% following paper "Peng H, Guo Z, Deng C, Wu Z. Enhancing differential evolution with random neighbors 
% based strategy[J]. Journal of Computational Science, 2018, 26:501-511."
%--------------------------------------------------------------------------------------------------------
% This function is implmented by Hu Peng
%--------------------------------------------------------------------------------------------------------
%--------------------------------------------------------------------------------------------------------
% More information can visit H Peng's homepage: https://whuph.github.io/index.html
%--------------------------------------------------------------------------------------------------------
    clear;clc;
    fprintf('Now is running RNDE\n');
    %% Parameter setting for test function
    addpath('../TestFunction');
    fhd=str2func('yao_13'); 
    fun=1;
    
    % for yao_13
    funopt=zeros(1,13);
    Xmin    = [-100,-10,-100,-100,-30,-100,-1.28,-500,-5.12,-32,-600,-50,-50];
    Xmax    = -Xmin;
    
    %% Parameter setting for algorithm
    D  = 30;
    NP = 100;
    CR1=0.1;
    CR2=0.85;
    
    CR=CR2+randn*0.1;
    F=0.5;
    nfevalmax = 10000*D;
    outcome = [];
    
    lowbound  = ones(1,D).*Xmin(fun);
    highbound = ones(1,D).*Xmax(fun);
    pop       = zeros(NP,D);

    for i=1:NP
        pop(i,:) = lowbound + rand(1,D).*(highbound - lowbound);
    end

    val       = zeros(1,NP);
    nfeval    = 0;

    for i=1:NP
        val(i)  = feval(fhd,pop(i,:),fun);
    end
    nfeval  = nfeval + NP;    

    r = zeros(1,3);
    flag=1;
    
    
    while nfeval <nfevalmax
        N = scope_cal(val, NP);
        for i=1:NP
            rd=randperm(NP);
            for j=1:2
                if rd(j)~=i; r(j)=rd(j);
                else r(j)=rd(3); end
            end 
            tempx = pop(i, :);
            
                rd=randperm(NP);
                [~,id]=min(val(rd(1:N(i))));
                lbest=rd(id);
                for j=1:D
                    if (rand<CR) 
                        tempx(j) = pop(lbest,j)+F.*(pop(r(1),j)-pop(r(2),j));
                        if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                            tempx(j) = lowbound(j) + rand*(highbound(j) - lowbound(j));
                        end
                    end
                end
            
            tempval = feval(fhd, tempx, fun);
            nfeval  = nfeval + 1;

            if tempval < val(i)
                val(i)   = tempval;
                pop(i,:) = tempx;
            else
                flag=~flag;
                if flag==1
                    CR=CR1+0.1*randn;
                else
                    CR=CR2+0.1*randn;
                end
            end
            
        end %--for i=1:NP
       
        [GlobalMin,~] = min(val);
        outcome   = [outcome GlobalMin];  

    end %--while nfeval <nfevalmax

    GlobalMin=GlobalMin-funopt(fun);
    fprintf('best value=%d\n',GlobalMin);

end

function scope_array = scope_cal(fitness_array, NP)

    eps=1E-5;

    fitness_max = min(fitness_array); 
    fitness_sub_max = abs(fitness_max - fitness_array);
    fitness_sub_max_sum = sum(fitness_sub_max);
    scope_array = zeros(NP);

    for i=1:NP
        scope_array(i) =3+7 * (fitness_sub_max(i) + eps) / (fitness_sub_max_sum + eps);  
    end
    scope_array=round(scope_array);
end

