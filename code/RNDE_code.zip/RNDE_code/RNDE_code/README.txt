 If you find this code useful in your work, please cite the following paper 
 Peng H, Guo Z, Deng C, Wu Z. Enhancing differential evolution with random neighbors based strategy[J]. Journal of Computational Science, 2018, 26:501-511.

%--------------------------------------------------------------------------------------------------------
% More information can visit H Peng's homepage: https://whuph.github.io/index.html
%--------------------------------------------------------------------------------------------------------