function RPBSO
% This is a simple demo of RPBSO
%--------------------------------------------------------------------------------------------------------
% If you find this code useful in your work, please cite the 
% following paper by the author of the code "Chen J, Deng C, Peng H, et al. 
% Enhanced Brain Storm Optimization with Role-playing Strategy[C]// 
% 2019 IEEE Congress on Evolutionary Computation (CEC). IEEE, 2019: 1132-1139".
%--------------------------------------------------------------------------------------------------------
% This function is implmented by Jianqiang Chen
%--------------------------------------------------------------------------------------------------------
%--------------------------------------------------------------------------------------------------------
% More information can visit H Peng's homepage: https://whuph.github.io/index.html
%--------------------------------------------------------------------------------------------------------

    clear;clc;
    fprintf('Now is running RPBSO\n');
    addpath(genpath('../TestFunction')); 
    fhd = str2func('cec13_func');
     
    %% Parameter setting for test function
    fun = 1; % number of functions
    % for cec13_func
    funopt = [-1400,-1300,-1200,-1100,-1000,-900,-800,-700,-600,-500,-400,-300,-200,-100,100,200,300,400,500,600,700,800,900,1000,1100,1200,1300,1400];
    xmin = -100;
    xmax  = 100;

    %% Parameter setting for algorithm
    D=30;%dimension of idea
    NP=100;%pop size
    NC=3; %number of clusters
    nfevalmax = 10000*D; %maximum number of evaluate
    max_iteration=fix(nfevalmax/NP);
    prob_one_cluster = 0.5; % probability for select one cluster to form new individual;
    popu = xmin + (xmax - xmin) * rand(NP,D); % initialize the population of individuals
    popu_sorted  = xmin + (xmax - xmin) * rand(NP,D); % initialize the  population of individuals sorted according to clusters
    n_iteration = 0; % current iteration number
    fitness_popu = zeros(NP,1);  % store fitness value for each individual
    fitness_popu_sorted = zeros(NP,1);  % store  fitness value for each sorted individual
    indi_temp = zeros(1,D);  % store temperary individual
    cluster = zeros(NP,1);
    classA = zeros(max_iteration,3);
    n_c = 0;

    %% calculate fitness for each individual in the initialized population
    for idx = 1:NP
        fitness_popu(idx,1) = feval(fhd,popu(idx,:)',fun);
    end
    nfeval=NP;    
    %% Carry out iterative calculation
    while nfeval <nfevalmax
        %% Reinitialize 
        n_c = n_c + 1;
        if n_c > 2
            if classA(n_c - 1,1) == 0
                for i = 50:100
                    popu(i,:) = xmin + (xmax - xmin) * rand(1,D); 
                    fitness_popu(i,1) = feval(fhd,popu(i,:)',fun);
                    nfeval = nfeval + 1;
                end
            end
        end
        %% Role-playing Strategy
        deta_dis = 0;
        set = zeros(NP,2);
        [~,bInd] = min(fitness_popu);
        [~,sInd] = sort(fitness_popu);
        deta_mean = sum(fitness_popu(1:NP)-fitness_popu(bInd))/(NP-1);%Calculate the average fitness value
        for i=1:NP
            deta_dis0 = sum((popu(i,:)-popu(bInd,:)).^2)^0.5;%Calculate the average Euclidean distance
            deta_dis = deta_dis +deta_dis0;
        end           
        for i=1:NP
            if fitness_popu(i)-fitness_popu(bInd) < deta_mean
                set(i,1) = 1;%Idea marker 1 with better fitness value
            end
            if sum((popu(i,:)-popu(bInd,:)).^2)^0.5 < deta_dis/(NP-1)
                set(i,2) = 2;%Idea marker 2 close to the best idea             
            end
            if set(i,1) ==1 && set(i,2)==2
                cluster(i)=1;% ideas with good fitness values and close to the best idea
                classA(n_c,1) = classA(n_c,1) + 1;
            elseif set(i,1)==1&&set(i,2)==0
                cluster(i)=2;% good fitness values of ideas which are away from the best idea
                classA(n_c,2) = classA(n_c,2) + 1;
            elseif set(i,1)==0
                cluster(i)=3;% the ideas with poor fitness value
                classA(n_c,3) = classA(n_c,3) + 1;
            end
        end
        % form ideas sorted according to clusters
        counter_cluster = zeros(NC,1);
        acculate_num_cluster = zeros(NC,1);
        for idx =2:NC
            acculate_num_cluster(idx,1) = acculate_num_cluster((idx-1),1) + classA(n_c,(idx-1));
        end
        %start form sorted ideas
        for idx = 1:NP
            counter_cluster(cluster(idx,1),1) = counter_cluster(cluster(idx,1),1) + 1 ;
            temIdx = acculate_num_cluster(cluster(idx,1),1) +  counter_cluster(cluster(idx,1),1);
            popu_sorted(temIdx,:) = popu(sInd(idx),:);
            fitness_popu_sorted(temIdx,1) = fitness_popu(sInd(idx),1);
        end           
        %% The process of generating new ideas
        for idx = 1:NP
            r_1 = rand();
            if r_1 < prob_one_cluster
                ind_1 = ceil(rand()*NP);
                indi_temp(1,:) = popu_sorted(ind_1,:);%randomly choose an idea to generate a new idea
            else  % combine the two ideas selected to generate a new idea              
                tem = rand();
                if (acculate_num_cluster(3,1)-acculate_num_cluster(2,1)<5 ) && (NP-acculate_num_cluster(3,1))>5
                    indi_1 = ceil(rand()*5);
                    indi_2 = NP - ceil(rand()*(NP-0.5*NP));
                    indi_temp(1,:) = tem * popu_sorted(indi_1,:) + (1-tem) * popu_sorted(indi_2,:);
                else
                    rc = randperm(NC);
                    indi_1 = acculate_num_cluster(rc(1),1) + ceil(rand() * classA(n_c,rc(1)));
                    indi_2 = acculate_num_cluster(rc(2),1) + ceil(rand() * classA(n_c,rc(2)));
                    indi_temp(1,:) = tem * popu_sorted(indi_1,:) + (1-tem) * popu_sorted(indi_2,:);
                end
            end

            %the idea difference strategy
            if rand<=0.005
                indi_temp = xmin + (xmax-xmin) .* rand(1,D);
            else            
                a=ceil(rand(1,2)*NP); 
                indi_temp(1,:) = indi_temp(1,:) + (popu(a(1),:)-popu(a(2),:)).*rand(1,D);
            end
            indi_temp = ( (indi_temp >= xmin) & (indi_temp <= xmax) ) .* indi_temp...
                + (indi_temp < xmin) .* ( xmin + (xmax-xmin) .* rand(1,D) )...
                + (indi_temp > xmax) .* ( xmin + (xmax-xmin) .* rand(1,D) );
            % if better than the previous one, replace it
            fv = feval(fhd,indi_temp',fun);
            if fv < fitness_popu(idx,1)  % better than the previous one, replace
                fitness_popu(idx,1) = fv;
                popu(idx,:) = indi_temp(1,:);
            end 

        end %end for idx

        nfeval = nfeval +NP;
        n_iteration=n_iteration+1;      
        [GlobalMin,~] = min(fitness_popu);

    end% end of iterations
    GlobalMin=GlobalMin-funopt(fun);
    fprintf('function=%d best value=%d\n',fun,GlobalMin);
    
end






