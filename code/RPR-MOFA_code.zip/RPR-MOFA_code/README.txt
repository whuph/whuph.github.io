If you want to run this algorithm, you should download PlatEMO firstly. Then, copy the code folder to 'Algorithm' folder.
Then, you can run this algorithm. It is necessary to emphasize that the version of PlatEMO is 2.X when I implemented the code.
While, for higher version, some changes may need to be made.