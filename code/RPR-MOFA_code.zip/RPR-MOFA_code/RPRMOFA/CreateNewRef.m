function Z = CreateNewRef(record,Z,addNum)
    interval = max(record);
    % Worsepoint represents inactive points according to the associated numbers.
    worsePoint = find(record<interval*0.6); 
    NZ=size(Z,1);
    if~isempty(worsePoint)
        activePos = true(1,NZ);
        activePos(worsePoint) = 0;
        % Create translate point.
        [tranW] = CreateTran(Z);         
        distance = pdist2(Z,tranW);
        [~,rho] = sort(distance,1);
        [makePoint] = IdentifyActiveTran(rho,Z,activePos);
        for j=1:length(makePoint)
           newZ = CreateNewPoints(makePoint(j,:),Z,addNum); 
           Z=[Z;newZ];
        end        
    end
end

function makePoint = IdentifyActiveTran(rho,Z,activePos)
    NTran = size(rho,2);
    activeTran = false(1,NTran);
    M=size(Z,2);
    for i = 1:NTran
       for j=1:M
          if activePos(rho(j,i)) == 0
             break; 
          end
       end
       if j==M
          activeTran(i)=1; 
       end
    end
    [~,pos] = find(activeTran==1);
    if ~isempty(pos)
        makePoint = zeros(length(pos),M);
        for z=1:length(pos)
            makePoint(z,:)=rho(1:M,pos(z));
        end
    end
end
function newRef = CreateNewPoints(relation,Z,addNum)   
    M = size(Z,2);
    nearZ = Z(relation,:);
    % Prevent precision errors in floating-point operations.
    % After the generation, dividing 1E6 is necessary.
    test = nearZ.*1e6;
    maxNum = max(test);
    minNum = min(test);
    period = zeros(1,M);
    rr1 =[];
    len=1;
    for i=1:M
        period(i)=len;
        margin = linspace(minNum(i),maxNum(i),addNum);
        rr1 = [rr1,margin']; 
        len = len*length(margin);
    end
    restore = zeros(len,M);
    t=1;temp = ones(1,M);
    while t<= len
        for i=1:M
            restore(t,i) = rr1(temp(i),i);
        end
        r = mod(t,period);
        isZero = find(r==0);
        temp(isZero) = temp(isZero) + 1;
        r1 = mod(temp,size(rr1,1)+1);
        isZero2 = find(r1==0);
        temp(isZero2) = 1;
        t=t+1;
    end
    restore = restore./1e6;
    restore = roundn(restore,-4);
    W1 = roundn(Z,-4);
    sumW = sum(W1,2);
    minS = min(sumW);
    maxS = max(sumW);
    sumRe = sum(restore,2);
    correct = find(sumRe>=minS & sumRe<=maxS);
    newRef = restore(correct,:);
    newRef = max(newRef,1e-6);
    nearZ = roundn(nearZ,-4);
    nearZ = max(nearZ,1e-6);
    [~,~,ib] = intersect(nearZ,newRef,'rows');
    newRef(ib,:)=[];% Delete the duplicate points.
end