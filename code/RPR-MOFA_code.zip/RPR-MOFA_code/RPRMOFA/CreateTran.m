function [tranW] = CreateTran(W)
[NW,M] = size(W);
W1=sortrows(W);
interval=W1(1,end)-W1(2,end);
info=zeros(M,2);
info(1,1)=1;info(1,2)=NW;
% create translate point
for i=1:M-1
    usedW=W1(info(i,1):info(i,2),:);
    for j=1:size(usedW,1)
        p = repmat(usedW(j,:),M,1) - interval/M;
        p(logical(eye(M))) = p(logical(eye(M))) + interval;
        W1=[W1;p];
    end
    W1(any(W1<0,2),:) = [];
    [~,index] = unique(roundn(W1,-4),'rows','stable');
    W1 = W1(index,:);
    info(i+1,1)=info(i,2)+1;info(i+1,2)=size(W1,1);
end
tranW = W1(NW+1:end,:);
end