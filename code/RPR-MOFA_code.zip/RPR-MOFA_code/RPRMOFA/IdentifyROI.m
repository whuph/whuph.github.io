function [record] = IdentifyROI(Population,Z,record)
    objs = Population.objs;
    Zmin = min(objs,[],1);
    NZ = size(Z,1);
    PopObj = objs-repmat(Zmin,size(objs,1),1);
    [N,M] = size(PopObj);
    if isempty(record)
       record = zeros(1,size(Z,1)); 
    end
    %% Normalization
    % Detect the extreme points
    Extreme = zeros(1,M);
    w       = zeros(M)+1e-6+eye(M);
    for i = 1 : M
        [~,Extreme(i)] = min(max(PopObj./repmat(w(i,:),N,1),[],2));
    end
    % Calculate the intercepts of the hyperplane constructed by the extreme
    % points and the axes
    Hyperplane = PopObj(Extreme,:)\ones(M,1);
    a = 1./Hyperplane;
    if any(isnan(a))
        a = max(PopObj,[],1)';
    end
    % Normalization
    PopObj = PopObj./repmat(a',N,1);
     %% Associate each solution with one reference point
    % Calculate the distance of each solution to each reference vector
    Cosine   = 1 - pdist2(PopObj,Z,'cosine');
    Distance = repmat(sqrt(sum(PopObj.^2,2)),1,NZ).*sqrt(1-Cosine.^2);
    % Associate each solution with its nearest reference point
    [~,pi] = min(Distance',[],1);
    rho = hist(pi(1:N),1:NZ);
    [~,col] = find(rho~=0);
    record(col) = record(col)+1;
end