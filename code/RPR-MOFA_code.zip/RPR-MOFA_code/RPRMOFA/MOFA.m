function [Population1] = MOFA(Population,obj)
    %% FA parameters
    lb=obj.Global.lower;
    ub=obj.Global.upper;
    %gamma=1./(ub-lb).^2;
    gamma=1;
    beta0=1;
    pop=Population.decs;
    PopObj=Population.objs;
    [N,D] = size(pop);
    M=size(PopObj,2);
    %% Dominance
    Front=NDSort(PopObj,1);
    ndSol=PopObj(Front==1,:);
    moveCount=zeros(1,N);
    %% Move
    notMove=[];
    for i=1:N
        isMove=0;
        for j=1:N            
            if all(PopObj(i,:)>=PopObj(j,:)) && any(PopObj(i,:)>PopObj(j,:))
                moveCount(j)=moveCount(j)+1;
                isMove=1;
                r = norm(pop(i,:)-pop(j,:));
                beta=beta0.*exp(-gamma.*r^2);
                r1=randi([0 1],1,D);
                pop(i,:)=pop(i,:)+(pop(j,:)-pop(i,:)).*beta+0.02.*(rand(1,D)-0.5).*r1;
                pop(i,:) = ( (pop(i,:) >= lb) & (pop(i,:) <= ub) ) .* pop(i,:)...
                    + (pop(i,:) < lb) .* ( lb + (ub-lb) .* rand(1,D) )...
                    + (pop(i,:) > ub) .* ( lb + (ub-lb) .* rand(1,D) );                             
            end
        end     
        if ~isMove
            notMove=[notMove,i];
        end
    end
    % The movement focuses on non-moving individuals
     if ~isempty(notMove)
         moveCount=moveCount(notMove);
         moveCount(moveCount==0)=1;
         for i=1:length(notMove)
             tempCount=moveCount;
             tempCount(i)=1e6;
             index=RouletteWheelSelection(1,tempCount);             
             moveCount(index)=moveCount(index)+1;
             r = norm(pop(notMove(i),:)-pop(notMove(index)));
             beta=beta0.*exp(-gamma.*r^2);
             r1=randi([0 1],1,D);
             pop(notMove(i),:)=pop(notMove(i),:)+(pop(notMove(index),:)-pop(notMove(i),:)).*beta+0.02.*(rand(1,D)-0.5).*r1;
             pop(notMove(i),:) = ( (pop(notMove(i),:) >= lb) & (pop(notMove(i),:) <= ub) ) .* pop(notMove(i),:)...
                    + (pop(notMove(i),:) < lb) .* ( lb + (ub-lb) .* rand(1,D) )...
                    + (pop(notMove(i),:) > ub) .* ( lb + (ub-lb) .* rand(1,D) );           
         end
     end     
    Population1=INDIVIDUAL(pop);
end