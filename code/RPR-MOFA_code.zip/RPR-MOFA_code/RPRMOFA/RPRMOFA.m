function RPRMOFA(Global)
%<algorithm> <A>
% alpha ---  3 --- The parameter controlling the rate of change of penalty

    %% Parameter setting
    [alpha] = Global.ParameterSet(3);
    
    %% Initialization  
    [Z,Global.N] = UniformPoint(Global.N,Global.M);
    Population    = Global.Initialization();
    obj = Global.problem;
    Zmin       = min(Population.objs,[],1);
    Archive = Population;
    flag = 0;
    tao = 0.5;
    l_period = 0.6;
    record=[];
    while Global.NotTermination(Archive)
        [Population] = MOFA(Archive,obj);
        Zmin = min([Zmin;Population.objs],[],1);
        [Archive] = EnvironmentalSelection([Archive,Population],Global.N,Z,Zmin);
        OriArchive = Archive;
        Global.NotTermination(Archive);
        % This method is also employed in NMPSO
        S = GAhalf(Archive([1:length(Archive),randi(ceil(length(Archive)/2),1,length(Archive))]));
        Zmin=min([Zmin;S.objs],[],1);
        [Archive] = EnvironmentalSelection([Archive,S],Global.N,Z,Zmin);
        if Global.gen >= tao*Global.maxgen && Global.gen <= l_period*Global.maxgen
            [record] = IdentifyROI([Archive,OriArchive],Z,record);                                       
        elseif Global.gen > l_period*Global.maxgen && flag == 0            
            [Z] = CreateNewRef(record,Z,alpha); % Generate new reference points if necessary
            flag = 1;
        end        
    end    
end