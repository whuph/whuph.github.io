Welcome to access Hu Peng's Homepage, https://whuph.github.io/index.html,
Our papers and codes are avaliable on the website. 

If you find this code useful in your work, please cite the following paper 
"Zhu W, Peng H, Leng C, Deng C, Wu Z. Surrogate-assisted firefly algorithm for breast cancer detection[J]. 
Journal of Intelligent & Fuzzy Systems, 2021, DOI:10.3233/JIFS-201124"

%--------------------------------------------------------------------------------------------------------
% More information can visit H Peng's homepage: https://whuph.github.io/index.html
%--------------------------------------------------------------------------------------------------------