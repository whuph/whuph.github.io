function SFA_BCD_RaFA
% This is a simple demo of SFA-BCD
%--------------------------------------------------------------------------------------------------------
% If you find this code useful in your work, please cite the
% following paper "Zhu W, Peng H, Leng C, Deng C, Wu Z. Surrogate-assisted firefly algorithm for breast cancer detection[J].
% Journal of Intelligent & Fuzzy Systems, 2021"
%--------------------------------------------------------------------------------------------------------
% This function is implmented by Wenhua Zhu
%--------------------------------------------------------------------------------------------------------
%--------------------------------------------------------------------------------------------------------
% More information can visit H Peng's homepage: https://whuph.github.io/index.html
%--------------------------------------------------------------------------------------------------------
clear;clc;
fprintf('Now is running SFA-BCD\n');
format long;
format compact;

load breastcancerwisconsin.mat
A=breastcancerwisconsin;
A = A(all(~isnan(A),2),:);
[data_r, data_c] = size(A);
B=A(:,data_c);
A=A(:,1:data_c-1);

mapData=mapminmax(A',0,1);
data=[mapData',B];

a=load('offlinebrea10.mat', 'offline');
ofData=a.offline;
ofData=ofData(all(~isnan(ofData),2),:);
nd=size(ofData,2)-1;
c=nd;
% Lower bounds
[ub,~]=max(ofData);
[lb,~]=min(ofData);
ub=ub(:,1:(size(ub,2)-1));
lb=lb(:,1:(size(lb,2)-1));

B=load('SMvalue10.mat', 'Para1');
Para=B.Para1;
global initial_flag
initial_flag = 0;
start=tic;
n = 20;
nfevalmax = 5E3;
outcome = [];
alpha=0.2;
gamma=1;
beta0=1;
nfeval=0;
pop=lhsdesign(n,nd).*(ones(n,1)*(ub-lb))+ones(n,1)*lb;
Light=10^10*zeros(1,n);
for i=1:10
    if sum(round(pop(i,:)))>0
        a=svm(round(pop(i,:)),data);
        Light(i)=svm(round(pop(i,:)),data);
    end
end
for i=11:20
    Light(i)=RBF_predictor(Para,pop(i,:));
end
nfeval=nfeval+n;
[GlobalMax,~]=max(Light);
ti=0;
t=0;
G=fix(nfevalmax/n);
Rand=zeros(1,n);
G=nfevalmax/n;
while nfeval<nfevalmax && t<G
    t=t+1;
    Rand=rand(1,n);
    for i=1:n
        j=fix(rand*n)+1;
        while(j==i)
            j=fix(rand*n)+1;
        end;
        if Light(i)<Light(j)
            r = norm(pop(i,:)-pop(j,:));
            beta=beta0*exp(-gamma*r^2);
            pop(i,:)=pop(i,:)+(pop(j,:)-pop(i,:)).*beta+alpha.*(rand(1,nd)-0.5);
            pop(i,:) = ( (pop(i,:) >= lb) & (pop(i,:) <= ub) ) .* pop(i,:)...
                + (pop(i,:) < lb) .* ( lb + (ub-lb) .* rand(1,nd) )...
                + (pop(i,:) > ub) .* ( lb + (ub-lb) .* rand(1,nd) );
            if Rand(i)<0.3
                if sum(round(pop(i,:)))>0
                    Light(i)=svm(round(pop(i,:)),data);
                    ti=ti+1;
                end
            else
                Light(i)=RBF_predictor(Para,pop(i,:));
            end
            
            nfeval=nfeval+1;
        end
        
        
        
    end % end for i
    
    % Memorize Best
    [CycleMax,~]=max(Light);
    if CycleMax>GlobalMax
        GlobalMax=CycleMax;
    end
    outcome = [outcome GlobalMax];
    
end   % end of iterations
CPUtime  = toc(start);
fprintf('best accuracy=%d\n',GlobalMax);
fprintf('runtime =%d\n',CPUtime);

end

function [allEvaluate]=svm(pop,data)
warning('off')
tic;

[data_r, data_c] = size(data);

FeatIndex = find(pop==1);

indices = crossvalind('Kfold', data_r, 10);
ac=zeros(1,10);
pre=zeros(1,10);
reca=zeros(1,10);
spec=zeros(1,10);
fmea=zeros(1,10);
TP=0;
FN=0;
TN=0;
FP=0;
allEvaluate=0;

for i = 1 : 10
    
    test = (indices == i);
    
    train = ~test;
    
    test_data = data(test, 1 : data_c - 1);
    test_data=test_data(:,[FeatIndex]);
    test_label = data(test, data_c);
    
    train_data = data(train, 1 : data_c - 1);
    train_data = train_data(:,[FeatIndex]);
    train_label = data(train, data_c);
    
    
    SVMStruct = fitcsvm(train_data, train_label,'KernelFunction','rbf','KernelScale','auto');
    %predict_label  = classificationSVM(SVMStruct, test_data);
    [predict_label,score] = predict(SVMStruct,test_data);
    
    
    accuracy=length(find(predict_label == test_label))/length(test_label);
    
    for j=1:size(predict_label)
        if (predict_label(j,1)==1)
            if (test_label(j,1)==1)
                TP=TP+1;
            else
                FP=FP+1;
            end
            
        else
            if(test_label(j,1)==1)
                FN=FN+1;
            else
                TN=TN+1;
            end
        end
    end
    precision=TP/(TP+FP);
    recall=TP/(TP+FN);
    specificity=TN/(TN+FP);
    Fmeasure=2*(precision*recall)/(precision+recall);
    ac(i)=accuracy;
    pre(i)=precision;
    reca(i)=recall;
    spec(i)=specificity;
    fmea(i)=Fmeasure;
    
end

allEvaluate=sum(ac)/10;
cputime=toc;
end


function [TestNNOut]=RBF_predictor(Para,TestSamIn)
% Usage: [TestNNOut]=RBF_predictor(W2,B2,Centers,Spreads,TestSamIn)
% Single RBF Predictor
% Input:
% W2             - Weights of RBF Model
% B2             - Bais of RBF Model
% Centers        - Centers of RBF Model
% Spreads        - Widths of RBF model
% TestSamIn      - Test Data

%
% Output:
% TestNNOut      - Prediction of RBF Model for TestSamIn
W2=Para.W;
B2=Para.B;
Centers=Para.C;
Spreads=Para.S;

N=size(TestSamIn,1);
TestDistance = dist(Centers',TestSamIn');
TestSpreadsMat = repmat(Spreads,1,N);
TestHiddenUnitOut = radbas(TestDistance./TestSpreadsMat);
TestNNOut = W2*TestHiddenUnitOut+B2;
TestNNOut=TestNNOut';
end

