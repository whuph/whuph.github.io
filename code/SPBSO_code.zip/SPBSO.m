function [GlobalMin, outcome, CPUtime] = SPBSO(fhd, fun, xmin, xmax)
% 2017-6-13 programming by Hu Peng at JJU
    tic;

    global initial_flag
    initial_flag = 0;
    
    D=30;
    NP=100;
   
    nfevalmax = 10000*D;
    max_iteration=fix(nfevalmax/NP);
    
    outcome = [];

    popu = xmin + (xmax - xmin) * rand(NP,D); % initialize the population of individuals

    popu_sorted  = xmin + (xmax - xmin) * rand(NP,D); % initialize the  population of individuals sorted according to clusters

    n_iteration = 0; % current iteration number

    NC=10;
    
    best = ones(NC,1);  % index of best individual in each cluster
    
    fitness_popu = zeros(NP,1);  % store fitness value for each individual
    fitness_popu_sorted = zeros(NP,1);  % store  fitness value for each sorted individual

    indi_temp = zeros(1,D);  % store temperary individual

    % calculate fitness for each individual in the initialized population
    for idx = 1:NP
        fitness_popu(idx,1) = feval(fhd,popu(idx,:)',fun);
    end
    nfeval=NP;
    [GlobalMin,~] = min(fitness_popu);
    
    si=fix(rand*4)+1;

    while nfeval <nfevalmax
        
        top= NP - ceil( (nfeval/nfevalmax)*(NP-1) );        
        [~,RankIdx]=sort(fitness_popu);
        
        NC=5+fix(5*logsig(((0.5*max_iteration - n_iteration)/20))); % adaptive adjust the number of clusters

        rd=randperm(NP);
        centers = popu(rd(1:NC),:);
    
        cluster = kmeans(popu, NC,'Distance','cityblock','Start',centers,'EmptyAction','singleton'); % k-mean cluster
        
        % clustering
        [~,wInd] = max(fitness_popu);
        fitCB_values = repmat(fitness_popu(wInd,1),NC,1);  % assign a initial big fitness value  as best fitness for each cluster in minimization problems

        number_iNCluster = zeros(NC,1);  % initialize 0 individual in each cluster

        for idx = 1:NP
            number_iNCluster(cluster(idx,1),1)= number_iNCluster(cluster(idx,1),1) + 1;

            % find the best individual in each cluster
            if fitCB_values(cluster(idx,1),1) > fitness_popu(idx,1)  % minimization
                fitCB_values(cluster(idx,1),1) = fitness_popu(idx,1);
                best(cluster(idx,1),1) = idx;
            end
        end

        % form population sorted according to clusters
        counter_cluster = zeros(NC,1);  % initialize cluster counter to be 0 

        acculate_num_cluster = zeros(NC,1);  % initialize accumulated number of individuals in previous clusters

        for idx =2:NC
            acculate_num_cluster(idx,1) = acculate_num_cluster((idx-1),1) + number_iNCluster((idx-1),1);
        end

        %start form sorted population
        for idx = 1:NP
            counter_cluster(cluster(idx,1),1) = counter_cluster(cluster(idx,1),1) + 1 ;
            temIdx = acculate_num_cluster(cluster(idx,1),1) +  counter_cluster(cluster(idx,1),1);
            popu_sorted(temIdx,:) = popu(idx,:);
            fitness_popu_sorted(temIdx,1) = fitness_popu(idx,1);
        end

        % record the best individual in each cluster
        for idx = 1:NC              
            centers(idx,:) = popu(best(idx,1),:);        
        end

        centers_copy = centers;  % make a copy

%         if (rand() < 0.2) %  select one cluster center to be replaced by a randomly generated center
%             cenIdx = ceil(rand()*NC);
%             centers(cenIdx,:) = xmin + (xmax - xmin) * rand(1,D);
%         end 

        % generate NP new individuals by adding Gaussian random values

        for idx = 1:NP
            
              if si==1
                  indi_temp(1,:) = centers(ceil(rand() * NC),:); 
              end
              
              if si==2
                  idj=ceil(rand() * NC);
                  indi_1 = acculate_num_cluster(idj,1) + ceil(rand() * number_iNCluster(idj,1));
                  indi_temp(1,:) = popu_sorted(indi_1,:); 
              end
              
              if si==3
                  tem = rand();       
                  cluster_1 = ceil(rand() * NC);
                  cluster_2 = ceil(rand() * NC);
                  indi_temp(1,:) = tem * centers(cluster_1,:) + (1-tem) * centers(cluster_2,:); 
              end
              
              if si==4  
                  tem = rand();
                  cluster_1 = ceil(rand() * NC);
                  cluster_2 = ceil(rand() * NC);
                  indi_1 = acculate_num_cluster(cluster_1,1) + ceil(rand() * number_iNCluster(cluster_1,1));
                  indi_2 = acculate_num_cluster(cluster_2,1) + ceil(rand() * number_iNCluster(cluster_2,1));
                  indi_temp(1,:) = tem * popu_sorted(indi_1,:) + (1-tem) * popu_sorted(indi_2,:); 
              end
              
            BestId=RankIdx( ceil(rand*top) );
            stepSize = (popu(BestId,:)-popu(idx,:)).*rand(1,D);           
            indi_temp(1,:) = indi_temp(1,:) + stepSize .* normrnd(0,1,1,D);      
            
            indi_temp = ( (indi_temp >= xmin) & (indi_temp <= xmax) ) .* indi_temp...
                       + (indi_temp < xmin) .* ( xmin + (xmax-xmin) .* rand(1,D) )...
                       + (indi_temp > xmax) .* ( xmin + (xmax-xmin) .* rand(1,D) );
            
            % if better than the previous one, replace it
            fv = feval(fhd,indi_temp',fun);
            if fv < fitness_popu(idx,1)  % better than the previous one, replace
                fitness_popu(idx,1) = fv;
                popu(idx,:) = indi_temp(1,:);
            else
                tsi=fix(rand*4)+1;
                if tsi==si
                    tsi=mod(tsi,4)+1;
                end
                si=tsi;
            end;  

        end

        % keep the best for each cluster
        for idx = 1:NC
            popu(best(idx,1),:) = centers_copy(idx,:);  
            fitness_popu(best(idx,1),1) = fitCB_values(idx,1);
        end

        nfeval = nfeval +NP;
        n_iteration=n_iteration+1;
      
        [GlobalMin,~] = min(fitness_popu);
        outcome   = [outcome GlobalMin];
        
    end
    
    CPUtime   = toc;
    
end


