## CEC 2013 Test

### Directory Structure

|         Name         |  Type  |         Description          |
| :------------------: | :----: | :--------------------------: |
|         SWFA         | folder |         SWFA program         |
|      input_data      | folder |      CEC2013 input data      |
|  **cec2013_test.m**  |  file  |         Main program         |
|  cec13_func.mexw64   |  file  | CEC2013 function for Windows |
| cec13_func.mexmaci64 |  file  |  CEC2013 function for MacOS  |

