function val = DI(pop,lb,ub)
    % Compute DI
    % @param pop {array} Population
    % @param lb {array} lower bound
    % @param ub {array} upper bound
    % @return val {array} DI value
    val = mean(std(pop)/(ub-lb));
end