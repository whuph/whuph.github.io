function [GlobalMin, outcome, CPUtime, optimum] = SWFA(fhd, fun, lb, ub, D)
    
    tic;
    global beta0 betamin gamma alpha
    n = 20;    

    nfevalmax = 5E5;

    outcome = [];

    alpha = 0.5;
    gamma = 1./(ub-lb).^2;
    %gamma=1;
    beta0 = 1;
    betamin = 0.2;
    nfeval = 0;
    pop = lb + rand(n,D).*(ub - lb);
    
    Array = 1:n;
    window_size =8;
    offset = 5;
    window = Window(Array,window_size,offset);
    
    % Compute fitness
    Light = zeros(n,1);
    for i = 1:n 
        Light(i)  = feval(fhd,pop(i,:)',fun);    
    end
    
    nfeval = nfeval + n;
    GlobalMin = min(Light);
    optimum = pop(Light==GlobalMin,:);
    t = 0;
    G = fix(nfevalmax/n);
    while nfeval<nfevalmax && t<G
        t = t + 1;
        % Adaptive update alpha
        DI_cur = DI(pop,lb,ub);
        alpha =  10^(-31) + alpha*exp(-0.0045*(1-DI_cur));
        % Sliding window attraction
        unfocus  = window.get_unfocus();
        for i = 1:(n-window_size)
            for j = 1:window_size
                if Light(window.index(j)) < Light(unfocus(i))
                    offspring = flyTo(pop(unfocus(i),:),pop(window.index(j),:),pop(window.index(j),:),lb,ub,D);
                    offspring = gaussian_mutation(offspring,lb,ub);
                    tmp = feval(fhd,offspring',fun);
                    if tmp < Light(unfocus(i))
                        % Greedy selection
                        pop(unfocus(i),:) = offspring;
                        Light(unfocus(i)) = tmp;
                    end
                else
                    % Mutual learning
                    offspring = flyTo(pop(window.index(j),:),pop(unfocus(i),:),pop(unfocus(i),:),lb,ub,D);
                    tmp = feval(fhd,offspring',fun);
                    pop(window.index(j),:) = offspring;
                    Light(window.index(j)) = tmp;
                end
                nfeval = nfeval + 1;
            end
        end
        window.next();
        CycleMin = min(Light);
        CycleSolution = pop(Light==CycleMin,:);
        if CycleMin < GlobalMin
           optimum = CycleSolution;
           GlobalMin = CycleMin;
        end
        outcome = [outcome GlobalMin];
    end
    CPUtime = toc;
end
%%
function offspring = flyTo(Xi,Xj,Xg,lb,ub,D)
    global beta0 betamin gamma alpha
    r_ij = norm(Xi - Xj);
    r_ig = norm(Xi - Xg);
    beta_ij = (betamin + (beta0 - betamin)*exp(-gamma*r_ij^2));
    beta_ig = (betamin + (beta0 - betamin)*exp(-gamma*r_ig^2));
    omega = rand;
    offspring = Xi + omega*beta_ij.*(Xj - Xi) + (1-omega)*beta_ig.*(Xg - Xi) + alpha.*(rand(1,D)-0.5).*abs(ub-lb); % ��ͬά��
    offspring = ( (offspring >= lb) & (offspring <= ub) ) .* offspring...
                       + (offspring < lb) .* ( lb + (ub-lb) .* rand(1,D) )...
                       + (offspring > ub) .* ( lb + (ub-lb) .* rand(1,D) );
end