classdef Window < handle
    % Sliding Window Class
    properties
        index; % The selected indices list
        Array; % All indices list
        window_size; % Window size
        offset; % Offset of window
        controller; % Counter
    end
    methods
        function obj = Window(Array,window_size,offset)
            % Constructor
            % @param Array {array} all indices list
            % @param window_size {int} Window size
            % @param offset {int} Offset of window
            obj.Array = Array; 
            obj.offset = offset; 
            obj.window_size = window_size;
            obj.index = [];
            for i = 1:obj.window_size
                obj.index = [obj.index,obj.Array(i)];
            end
            obj.controller = 1 + obj.offset;
        end
        function unfocus = get_unfocus(obj)
            % Get the indices not in window
            unfocus = obj.Array;
            for i = 1:length(obj.index)
                unfocus = unfocus(unfocus~=obj.index(i));
            end
        end
        function index = next(obj)
            % Get the next indices in window
            obj.index = [];
            for i = 1:obj.window_size
                obj.index = [obj.index,mod(obj.controller+i-1,length(obj.Array))];
                obj.index(obj.index==0) = length(obj.Array);
            end
            obj.controller = mod(obj.controller+obj.offset,length(obj.Array));
            index = obj.index;
        end
    end
end

