function x = gaussian_mutation(x,lb,ub)
    % Gaussian mutation
    % @param x {array} Parents
    % @param min_range {array} lower bound
    % @param max_range {array} upper bound
    % @return x {array} The individual after mutation
    dim = length(x); 
    prob = 1 / dim; % Mutation probability
    sigma = (ub - lb) ./ 20;
    new_ind = min(max(normrnd(x, sigma), lb), ub);
    C = rand(1,dim) < prob;
    x(C) = new_ind(C);
end