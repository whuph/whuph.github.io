% cec2013 28 test functions
addpath(genpath(cd));
format long
format compact
clc

rand('state',sum(100*clock));
randn('state',sum(100*clock));

funopt = [-1400,-1300,-1200,-1100,-1000,-900,-800,-700,-600,-500,-400,-300,-200,-100,100,200,300,400,500,600,700,800,900,1000,1100,1200,1300,1400];
Xmin = -100.*ones(1,30);
Xmax = -Xmin;
algorithm_name = 'SWFA';
algorithm = str2func(algorithm_name);
fprintf('Run %s for Cec2013 Test\n',algorithm_name);
max_number = 30; % run 30 times
D = 30;
for i = 1:28 
    bestval_sum = 0; % Sum of optimal solutions for averaging
    CPUtime_sum = 0; % Sum of running times for averaging
    for j = 1:max_number
        [GlobalMin, outcome, CPUtime] = algorithm(@cec13_func,i,Xmin(i),Xmax(i),D);
        bestval_sum = bestval_sum + GlobalMin-funopt(i);
        CPUtime_sum = CPUtime_sum + CPUtime;
        result(i,j).bestval = GlobalMin - funopt(i); % optimal
        result(i,j).CPUtime = CPUtime; % Algorithm execution time
        result(i,j).bestArray = outcome; % Record the optimal solution for each generation
        fprintf('function %d run %d [cost time:%fs] best solution is %d\n',i,j,CPUtime,GlobalMin-funopt(i));
    end
    fprintf('function %d [average cost time:%fs] average best solution is %d\n',i,CPUtime_sum/max_number,bestval_sum/max_number);
    mean_val(i) = bestval_sum/max_number;
end