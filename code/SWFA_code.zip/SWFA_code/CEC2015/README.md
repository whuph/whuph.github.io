## CEC 2015 Test

### Directory Structure

|         Name         |  Type  |         Description          |
| :------------------: | :----: | :--------------------------: |
|         SWFA         | folder |         SWFA program         |
|      input_data      | folder |      CEC2013 input data      |
|   **test_cec15.m**   |  file  |         Main program         |
|  cec15_func.mexw64   |  file  | CEC2015 function for Windows |
| cec15_func.mexmaci64 |  file  |  CEC2015 function for MacOS  |

