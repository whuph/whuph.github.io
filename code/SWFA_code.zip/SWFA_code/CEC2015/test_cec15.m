% cec2015 15 test functions
addpath(genpath(cd));
D = 50;
Xmin = -100;
Xmax = 100;
runs = 30;
fhd = str2func('cec15_func');
algorithm_name = 'SWFA';
algorithm = str2func(algorithm_name);
fprintf('Run %s for Cec2015 Test\n',algorithm_name);
for i = 1:15
    func_num = i;
    bestval_sum = 0; % Sum of optimal solutions for averaging
    CPUtime_sum = 0; % Sum of running times for averaging
    for j=1:runs
        [GlobalMin, outcome, CPUtime] = algorithm(@cec15_func,i,Xmin,Xmax,D);
        bestval_sum = bestval_sum + GlobalMin;
        CPUtime_sum = CPUtime_sum + CPUtime;
        result(i,j).bestval = GlobalMin; % optimal
        result(i,j).CPUtime = CPUtime; % Algorithm execution time
        result(i,j).bestArray = outcome; % Record the optimal solution for each generation
        fprintf('function %d run %d [cost time:%fs] best solution is %d\n',i,j,CPUtime,GlobalMin);
    end
    mean_val(i) = bestval_sum/runs;
end