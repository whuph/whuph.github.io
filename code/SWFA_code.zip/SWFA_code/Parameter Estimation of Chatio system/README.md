## Parameters Estimation of Chaotic system

### Directory Structure

|          Name           |  Type  |               Description                |
| :---------------------: | :----: | :--------------------------------------: |
|          SWFA           | folder |               SWFA program               |
|          data           | folder |            output data folder            |
|   experimentSettings    | folder |     experimental algorithms settings     |
| **chaotic_system_test** |  file  |               Main program               |
|    chaotic_system.m     |  file  |    Chaotic system fitness calculation    |
|   get_chaotic_desc.m    |  file  | Get Chaotic system variables information |



