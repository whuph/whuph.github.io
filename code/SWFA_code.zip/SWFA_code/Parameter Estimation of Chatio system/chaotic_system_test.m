addpath(genpath(cd));
format long
format compact
clc

rand('state',sum(100*clock));
randn('state',sum(100*clock));

% ###### Read the experimental settings ######
% algorithm name,dimension,run times
setting = importdata('setting.txt');
% ########################
disp('Parameters estimation of chaotic system')       
for index = 1:length(setting.textdata)
    initial_flag = 0; % Reset the current settings, as the benchmark will follow the dimensions of the last run
    algorithm_name = setting.textdata{index};
    algorithm = str2func(algorithm_name);
    runs = setting.data(index,2);
    fprintf('algorithm:%s,run times:%d\n',algorithm_name,runs)
    for fun = 1:5
        bestval_sum = 0; % Sum of optimal solutions for averaging
        CPUtime_sum = 0; % Sum of running times for averaging
        for run = 1:runs
            [lb,ub,D] = get_chaotic_desc(fun); % Get decision variable boundary
            [GlobalMin, outcome, CPUtime, optimum] = algorithm(@chaotic_system,fun,lb,ub,D);
            bestval_sum = bestval_sum + GlobalMin;
            result(fun,run).bestval = GlobalMin; % Optimal value
            result(fun,run).CPUtime = CPUtime; % Algorithm execution time
            result(fun,run).bestArray = outcome; % Record the optimal solution for each generation
            result(fun,run).optimum = optimum; % Optimal
            fprintf('function %d run %d [cost time:%fs] best solution is %d\n',fun,run,CPUtime,GlobalMin);        
        end
        mean_val(fun) = bestval_sum/runs;
    end
    % Save the data
    filename = sprintf('data/%s-D%d-%d.mat',algorithm_name,D,runs);
    save(filename, 'result', 'mean_val', '-mat');
end