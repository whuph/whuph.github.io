## Enhancing firefly algorithm with sliding window for continuous optimization problems

Welcome to access Hu Peng's Homepage, https://whuph.github.io/index.html,
Our papers and codes are avaliable on the website. 

If you find this code useful in your work, please cite the 
following paper "**Peng H\***, Qian J, Kong F, Fan D, Shao P, Wu Z. Enhancing firefly algorithm with sliding window for continuous optimization problems[J]. Neural Computing and Applications, 2022."

---

### Instruction

All codes are developed using `Matlab`, and the codes are classified according to different experiments for your further study.