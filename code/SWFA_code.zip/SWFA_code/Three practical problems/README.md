## Practical problems

### Directory Structure

|       Name        |  Type  |    Description     |
| :---------------: | :----: | :----------------: |
|       SWFA        | folder |    SWFA program    |
|     problems      | folder | Practical problems |
| **application.m** |  file  |    Main program    |

