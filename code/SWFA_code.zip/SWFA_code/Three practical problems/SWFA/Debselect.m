function  [p,objF,conV]=Debselect(p,objF,conV,trial,objFtrial,conVtrial)
%% input parameters
    % p -- the parent population/the target vectors
    % objF -- the objective function value of the parent population
    % conV -- the degree of constraint violation of the parent population
    % trial -- the generated offspring population/the generated trail vectors
    % objFtrial -- the objective function value of the offspring population
    % conVtrial -- the degree of constraint violation of the offspring population
%% output parameters
    % p -- the new parent population/the target vectors after selection operation
    % objF -- the objective function value of the new parent population
    % conV -- the degree of constraint violation of the new parent population
%%
% temporary value to record the objective function value and degree of
% constraint violation
% ��ʱֵ��¼Ŀ�꺯��ֵ��Լ��Υ���̶�
   termconV=conV; 
   termobjF=objF;
   
%  selection operator according to feasibility rule
%   ���ݿ����Թ���ѡ�����

  %1.feasible solutions are better than infeasible solutions 
  %2.infeasible solution with less degree of constraint violation is better than the one with larger degree of constraint violation 
  % ���н����ڲ����н⣬��Լ��Υ���̶�С�Ĳ����н�����Լ��Υ���̶ȴ�Ĳ����н�
   betterIndex=find(conVtrial < termconV);
   p(betterIndex,:)=trial(betterIndex,:);
   objF(betterIndex)=objFtrial(betterIndex);
   conV(betterIndex)=conVtrial(betterIndex);
   
  % feasible solution with less objective function value is better than the one with larger objective function value
  % Ŀ�꺯��ֵ��С�Ŀ��н�����Ŀ�꺯��ֵ�ϴ�Ŀ��н�
   betterIndex=find(conVtrial==termconV & objFtrial < termobjF);      
   p(betterIndex,:)=trial(betterIndex,:);
   objF(betterIndex)=objFtrial(betterIndex);
   conV(betterIndex)=conVtrial(betterIndex);

