function [proportion,GlobalMin] = SWFA(problem)
    tic;
    global beta0 betamin gamma alpha
    n = 20;    
    lb = problem.lu(1,:);
    ub = problem.lu(2,:);
    nfevalmax = 5E5;
    D = problem.D;
    alpha = 0.5;
    gamma = 1./(ub-lb).^2;
    beta0 = 1;
    betamin = 0.2;
    nfeval = 0;
    for i=1:D
        pop(:,i) = lb(i) + rand(n,1).*(ub(i) - lb(i));
    end
    
    Array = 1:n;
    window_size = 8;
    offset = 5;
    window = Window(Array,window_size,offset);
    
    % Compute fitness and feasibility
    [objF,conV] = problem.evaluate(pop);
    GlobalMin = min(objF);
    
    nfeval = nfeval + n;
    
    t = 0;
    G = fix(nfevalmax/n);
    while nfeval<nfevalmax && t<G
        t = t + 1;
        DI_cur = DI(pop,lb,ub);
        alpha = 10^-31 + alpha*exp(-0.0045*(1-DI_cur));
        unfocus  = window.get_unfocus();
        for i = 1:(n-window_size)
            for j = 1:window_size
                if objF(window.index(j)) < objF(unfocus(i))
                    offspring = flyTo(pop(unfocus(i),:),pop(window.index(j),:),pop(window.index(j),:),lb,ub,D);
                    offspring = gaussian_mutation(offspring,lb,ub);
                    [objF_offspring,conV_offspring] = problem.evaluate(offspring);
                    [pop(unfocus(i),:),objF(unfocus(i)),conV(unfocus(i))] = Debselect(pop(unfocus(i),:),objF(unfocus(i)),conV(unfocus(i)),offspring,objF_offspring,conV_offspring);
                else
                    offspring = flyTo(pop(window.index(j),:),pop(unfocus(i),:),pop(unfocus(i),:),lb,ub,D);
                    [objF_offspring,conV_offspring] = problem.evaluate(offspring);
                    [pop(window.index(j),:),objF(window.index(j)),conV(window.index(j))] = Debselect(pop(window.index(j),:),objF(window.index(j)),conV(window.index(j)),offspring,objF_offspring,conV_offspring);
                end
                nfeval = nfeval + 1;
            end
        end
        Cyclemin=min(objF);
        GlobalMin = min([Cyclemin;GlobalMin]);
        window.next();
    end
    feasiIndex=find(conV==0);
    proportion = length(feasiIndex)/20;
        
end
function offspring = flyTo(Xi,Xj,Xg,lb,ub,D)
    global beta0 betamin gamma alpha
    r_ij = norm(Xi - Xj);
    r_ig = norm(Xi - Xg);
    beta_ij = (betamin + (beta0 - betamin)*exp(-gamma*r_ij^2));
    beta_ig = (betamin + (beta0 - betamin)*exp(-gamma*r_ig^2));
    omega = rand;
    offspring = Xi + omega*beta_ij.*(Xj - Xi) + (1-omega)*beta_ig.*(Xg - Xi) + alpha.*(rand(1,D)-0.5).*abs(ub-lb); % ��ͬά��
    offspring = ( (offspring >= lb) & (offspring <= ub) ) .* offspring...
                       + (offspring < lb) .* ( lb + (ub-lb) .* rand(1,D) )...
                       + (offspring > ub) .* ( lb + (ub-lb) .* rand(1,D) );
    offspring = ( (offspring >= lb) & (offspring <= ub) ) .* offspring...
                       + (offspring < lb) .* ( lb + (ub-lb) .* rand(1,D) )...
                       + (offspring > ub) .* ( lb + (ub-lb) .* rand(1,D) );
end