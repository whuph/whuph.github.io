%% Practical problem test
addpath(genpath(cd));
clear all
clc
run_time = 30;
problem = eval('WB'); % Problem name, it can be obtained from `problems` folder
fprintf('Test %s\n',problem.name);
solutions = [];
for i = 1:run_time
    [proportion,bestSolution] = SWFA(problem);
    fprintf('proportion=%f\n',proportion);
    if proportion ~= 0
        fprintf('optimal solution is %f\n',bestSolution);
        solutions = [solutions,bestSolution];
    else
        fprintf('No feasible solution\n');
    end
end
if ~isempty(solutions)
    meanBestSolution = mean(solutions);
    fprintf('average optimal solution is %f\n', meanBestSolution);
end