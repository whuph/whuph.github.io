classdef PVD
    %% ��������1��ѹ������
    %R,L,Ts,Th----1,2,3,4
    properties
        lu;
        D;
        name;
    end
    
    methods
        function obj = PVD()
            obj.name = "ѹ������";
            obj.lu = [10,10,0,0;200,200,99,99];
            [~,obj.D] = size(obj.lu);
        end
        
        function [objF, conV] = evaluate(obj,P)
           g(:, 1) = - P(:, 3) + 0.0193 * P(:, 1);
           g(:, 2) = - P(:, 4) + 0.00954 * P(:, 1);
           g(:, 3) = - pi * P(:, 1).^2 .* P(:, 2) - (4/3) * pi * P(:, 1).^3 + 750*1728;
           g(:, 4) = P(:, 2) - 240;

           f = 0.6224 * P(:, 3) .* P(:, 1) .* P(:, 2) + 1.7781 * P(:, 4) .* P(:, 1).^2 + 3.1611 * P(:, 3).^2 .* P(:, 2) + 19.84 * P(:, 3).^2 .* P(:, 1);
            
            objF= f;
            term = max(0, g);
            conV = sum(term, 2);
        end
    end
end

