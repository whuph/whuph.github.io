classdef TCS
    %% ��������1����ѹ�������ɵ����
    properties
        lu;
        D;
        name;
    end
    
    methods
        function obj = TCS()
            obj.name = '��ѹ�������ɵ����';
            obj.lu = [2.0,0.25,0.05;15.0,1.3,2.0];
            [~,obj.D] = size(obj.lu);
        end
        
        function [objF, conV] = evaluate(obj,P)
            g = [];
            g(:,1) = 1- (P(:, 1).*P(:, 2).^3)./(71785*P(:, 3).^4);
            g(:,2) = (4*P(:, 2).^2-P(:, 2).*P(:, 3))./(12566*(P(:, 2).*P(:, 3).^3-P(:, 3).^4)) +(1./(5108*P(:, 3).^2)) - 1;
            g(:,3) = 1-(140.45*P(:, 3))./(P(:, 1).*P(:, 2).^2);
            g(:,4) = (P(:, 2)+P(:, 3))./1.5 - 1;
            f = (P(:, 1) + 2).*P(:, 2).*P(:, 3).^2;

            % g denotes the constraints
            % f denotes the objective function

            % Obtain the fitness
            objF = f;
            term = max(0, g);
            conV = sum(term, 2);
        end
    end
end

