classdef WB
    %% ��������1��������
    properties
        lu;
        D;
        name;
    end
    
    methods
        function obj = WB()
            obj.name = "������";
            obj.lu = [0.1,0.1,0.1,0.1;2,10,10,2];
            [~,obj.D] = size(obj.lu);
        end
        
        function [objF, conV] = evaluate(obj,x)
            P = 6000;
            L = 14;
            E = 30*10^6;
            G = 12*10^6;
            tauMax = 13600;
            sigmaMax = 30000;
            deltaMax = 0.25;
            
            tau1 = P./(sqrt(2).*x(:,1).*x(:,2));
            M = P.*(L + x(:,2)/2);
            R = sqrt((x(:,2).^2)/4 + ((x(:,1) + x(:,3))/2).^2);
            J = 2*(sqrt(2) .* x(:,1) .*x(:,2).* ( (x(:,2).^2)/12 + ((x(:,1) + x(:,2))/2).^2 )  );
            tau2 = (M.*R) ./ J;
            tau = sqrt(tau1.^2 + 2.*tau1.*tau2.*(x(:,2))./(2.*R) + tau2.^2);
            
            sigma = (6.*P .* L)./(x(:,3).^2.*x(:,4));
            
            Pc = ((4.013*E*sqrt((x(:,3).^2 .* x(:,4).^6)/36))./L^2) .* (1 - x(:,3)/(2*L).*sqrt(E/(4*G)));
            
            delta = (4*P*L^3)./(E.*x(:,3).^3.*x(:,4));
            g(:,1) = tau - tauMax;
            g(:,2) = sigma - sigmaMax;
            g(:,3) = x(:,1) - x(:,4);
            g(:,4) = 0.125 - x(:,1);
            g(:,5) = delta - deltaMax;
            g(:,6) = P - Pc;
            g(:,7) = 0.10471.*x(:,1).^2 + 0.04811 .* x(:,3) .* x(:,4).*(14 + x(:,2)) - 5;
            
            f = 1.10471.*x(:,1).^2.*x(:,2) + 0.04811 .* x(:,3) .* x(:,4) .* (14 + x(:,2));
            
            objF= f;
            term = max(0, g);
            conV = sum(term, 2);
        end
    end
end
