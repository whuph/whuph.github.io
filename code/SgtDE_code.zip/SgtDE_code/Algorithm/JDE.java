﻿package com.island.SparkStrategies;

import cec2010.Function;
import com.java.tools.RandSet;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mouse
 */
public class JDE extends Algorithm {
    static protected double F = 0.5;
    static protected double CR = 0.9;

    static protected double p; //percento najlepsich pre krizenie
    static protected int numP; //pocet najlepsich pre krizenie, vychadza z hodnoty p
    static protected double tau1,tau2;
    static protected double Fl, Fu, SF, SF2; //sucet a mocnina uspesnych F hodnot
    double SCR, nSCR; //sucet a pocet uspesnych CR hodnot
    static protected Random rng;
    int generations;

    public JDE(){

    }
    public JDE(Function f, int D_, int popSize_) {
        //super(f, D_, popSize_);

        dimensions = D_;
        popSize = popSize_;
        function = f;
        population.setFitnessFunction(f);
        minPopulationSize = 5;
        tau1 = 0.1;
        tau2 = 0.1;
        Fl = 0.1;
        Fu = 0.9;

        rng = new Random( System.currentTimeMillis());
    }
    public JDE(Function f, int D_, int popSize_, int generationsPerRound) {
        this(f,D_,popSize_);
        this.generations=generationsPerRound;
    }

    //DE/current-to-p-best
    @Override
    public SiPDEIndividuals generation() {
        try {
            if (popSize < minPopulationSize) {
                throw new Exception("popSize can't be smaller than " + minPopulationSize + ".");
            }
        } catch (Exception ex) {
            Logger.getLogger(DERand1bin.class.getName()).log(Level.SEVERE, null, ex);
        }

        population.computeFandCR();
        SCR = 0; nSCR = 0;
        SF = 0; SF2 = 0;

        SiPDEIndividuals rand1, rand2, rand3;

        RealVector noisy;
        RealVector trial;
        double[] active;
        int rand1Index = 0;
        int rand2Index = 0;
        int rand3Index = 0;
        double randF1 = 0;
        double randF2 = 0;
        double randF3 = 0;
        double randF4 = 0;
        double trialFitness, activeFitness;

        double[][] Fm = new double[popSize][940];
        double[][] CRm = new double[popSize][940];
        int iter=0;
        //Mutation iteration strategy
        while (iter<940 ) {//generations
            iter = iter + 1;
            for (int ind = 0; ind < popSize; ind++) {
                trial = new ArrayRealVector(dimensions); //new double[dimensions];
                noisy = new ArrayRealVector(dimensions);//new double[dimensions];

                randF1 = Math.random();
                randF2 = Math.random();
                randF3 = Math.random();
                randF4 = Math.random();
                active = population.get(ind).getGeno().toArray();
                activeFitness = population.get(ind).getFitness();

                Fm[ind][iter-1] = F;  
                CRm[ind][iter-1] = CR;  //CR  0.9
               //The F value

                if(randF2<tau1){
                    F = Fl + randF1*Fu;
                }else {
                    F = Fm[ind][iter-1];
                }
                //The CR value
                if(randF4<tau2){
                    CR = randF3;
                }else {
                    CR = CRm[ind][iter-1];
                }

                Fm[ind][iter-1] = F;
                CRm[ind][iter-1] = CR;

                int[] randIndex = RandSet.randomArray1(0, popSize - 1, 3, ind);//Generate 3 different random Numbers                rand1 = population.get(randIndex[0]);
                rand2 = population.get(randIndex[1]);
                rand3 = population.get(randIndex[2]);

                for (int j = 0; j < dimensions; j++) {
                    double pom = (rand1.getGene(j) - rand2.getGene(j)) * F + rand3.getGene(j);

                    if (pom < function.getMin() || pom > function.getMax()) {
                        //pom = function.getRandomValueInDomains(j);
                        pom = function.getMin() + (Math.random() * ((function.getMax() - function.getMin()) + 1)); //function.getRandomValueInDomains(j);
                    }

                    noisy.addToEntry(j, pom);
                    /*double tr = (Math.random() < CR) ? noisy.getEntry(j) : active[j];
                    trial.addToEntry(j, tr);*/
                    trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
                }

                trialFitness = function.compute(trial.toArray());
                // Replace if trial is better
                if (trialFitness < activeFitness) {
                    SiPDEIndividuals indiv = new SiPDEIndividuals(population, trial);
                    indiv.setFitness(trialFitness);
                    population.set(ind, indiv);
                }
                if (population.get(ind).getFitness() < bestFitness) {
                    bestIndividual = population.get(ind);
                    bestFitness = bestIndividual.getFitness();
                }
            }
        }

            bestFitness=population.getBestIndividual().getFitness();
            bestIndividual = population.getBestIndividual();
            return bestIndividual;
    }

    public SubPopulation generationCC(HashMap<Integer, RealVector> pop, RealVector bestind, double bestvalue, List<Integer> subscript, int itermax, ArrayList tracerst) throws IOException {
        return null;
    }

    @Override
    public SiPDEPopulation getPopulation() {
        // TODO Auto-generated method stub
        return population;
    }

    @Override
    public void newRound() {
        // TODO Auto-generated method stub

    }

    public void setParameter(String configName, double value) {
        // TODO Auto-generated method stub
        if (configName.equals("F")) {
            F = value;
        } else if (configName.equals("CR")) {
            CR = value;
        }
    }
}
