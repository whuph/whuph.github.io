﻿package com.island.SparkStrategies;

import cec2010.Function;
import com.java.tools.RandSet;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mouse
 */
public class epsDE extends Algorithm {
    static protected double F= 0.1;
    static protected double CR= 0.1;
    static protected double uF[], uCR[];//static protected ArrayList<Double> uF, uCR;
    static protected double SF, SF2; //sucet a mocnina uspesnych F hodnot
    double SCR, nSCR; //sucet a pocet uspesnych CR hodnot
    static protected Random rng;
    int generations;

    public epsDE(){

    }
    public epsDE(Function f, int D_, int popSize_) {
        //super(f, D_, popSize_);

        dimensions = D_;
        popSize = popSize_;
        function = f;
        population.setFitnessFunction(f);
        minPopulationSize = 5;

        uF = new double[]{0.4,0.5,0.6,0.7,0.8,0.9};  //len=6
        uCR = new double[]{0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9};  //len=9
        rng = new Random( System.currentTimeMillis());

    }
    public epsDE(Function f, int D_, int popSize_, int generationsPerRound) {
        this(f,D_,popSize_);
        this.generations=generationsPerRound;
    }

    //DE/current-to-p-best
    @Override
    public SiPDEIndividuals generation() {
        try {
            if (popSize < minPopulationSize) {
                throw new Exception("popSize can't be smaller than " + minPopulationSize + ".");
            }
        } catch (Exception ex) {
            Logger.getLogger(DERand1bin.class.getName()).log(Level.SEVERE, null, ex);
        }



        SiPDEIndividuals rand1, rand2, rand3, rand4, rand5;

        RealVector noisy;
        RealVector trial;
        double[] active;
        int rand1Index = 0;
        int rand2Index = 0;
        int rand3Index = 0;
        int rand4Index = 0;
        int rand5Index = 0;
        double trialFitness, activeFitness;
        double Fm,CRm;  //F value and CR value selected each time

        int scheme1 = rng.nextInt(3)+1;
        Fm = uF[rng.nextInt(uF.length)];
        CRm = uCR[rng.nextInt(uCR.length)];

        int iter=0;
        //Mutation iteration strategy        while (iter<940 ) {//generations
            iter = iter + 1;
            for (int ind = 0; ind < popSize; ind++) {
                trial = new ArrayRealVector(dimensions); //new double[dimensions];
                noisy = new ArrayRealVector(dimensions);//new double[dimensions];

                active = population.get(ind).getGeno().toArray();
                activeFitness = population.get(ind).getFitness();

                double randF = 0;
                SiPDEIndividuals best = null;
                F = Fm;
                CR = CRm;
                int scheme = scheme1;

                switch (scheme) {
                    case 1:
                        //best/2/bin
                        int[] randIndex1 = RandSet.randomArray1(0, popSize - 1, 4, ind);//Generate 3 different random Numbers                        rand1 = population.get(randIndex1[0]);
                        rand2 = population.get(randIndex1[1]);
                        rand3 = population.get(randIndex1[2]);
                        rand4 = population.get(randIndex1[3]);
                        best = population.getBestIndividual();
                        for (int j = 0; j < dimensions; j++) {
                            //variation
                            double pom = ((rand1.getGene(j) + rand2.getGene(j) - rand3.getGene(j) - rand4.getGene(j)) * F) + best.getGene(j);
                            if (pom < function.getMin() || pom > function.getMax()) {
                                pom = function.getMin() + (Math.random() * ((function.getMax() - function.getMin()) + 1)); //function.getRandomValueInDomains(j);
                            }
                            noisy.addToEntry(j, pom);
                            // Create trial Individual from noisy and active
                            //cross                            trial.addToEntry(j, (Math.random() < CRm) ? noisy.getEntry(j) : active[j]);
                        }
                        break;
                    case 2:
                       //rand/2/bin
                        int[] randIndex2 = RandSet.randomArray1(0, popSize - 1, 5, ind);//Generate 3 different random Numbers
                        rand1 = population.get(randIndex2[0]);
                        rand2 = population.get(randIndex2[1]);
                        rand3 = population.get(randIndex2[2]);
                        rand4 = population.get(randIndex2[3]);
                        rand5 = population.get(randIndex2[4]);
                        for (int j = 0; j < dimensions; j++) {
                            double pom =  ((rand1.getGene(j) + rand2.getGene(j) - rand3.getGene(j) - rand4.getGene(j)) * F) + rand5.getGene(j);
                            if (pom < function.getMin() || pom > function.getMax()) {
                                pom = function.getMin() + (Math.random() * ((function.getMax() - function.getMin()) + 1));//function.getRandomValueInDomains(j);
                            }

                            noisy.addToEntry(j, pom);
                            // Create trial Individual from noisy and active
                            trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
                        }
                        break;
                    case 3:
                        //current-to-rand/1/bin/
                        randF = Math.random();
                        int[] randIndex3 = RandSet.randomArray1(0, popSize - 1, 3, ind);//Generate 3 different random Numbers
                        rand1 = population.get(randIndex3[0]);
                        rand2 = population.get(randIndex3[1]);
                        rand3 = population.get(randIndex3[2]);
                        for (int j = 0; j < dimensions; j++) {//rand3.getGene(j)
                            double temp = population.get(ind).getGene(j); //(rand1.getGene(j) - rand2.getGene(j)) * F + + best.getGene(j);
                            double pom = temp + randF * (rand1.getGene(j) - temp)
                                    + F * (rand2.getGene(j) - rand3.getGene(j));
                            if (pom < function.getMin() || pom > function.getMax()) {
                                pom = function.getMin() + (Math.random() * ((function.getMax() - function.getMin()) + 1));//function.getRandomValueInDomains(j);
                            }

                            noisy.addToEntry(j, pom);
                            // Create trial Individual from noisy and active
                            trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
                        }
                        break;
                }

                trialFitness = function.compute(trial.toArray());
                // Replace if trial is better
                if (trialFitness < activeFitness) {
                    SiPDEIndividuals indiv = new SiPDEIndividuals(population, trial);
                    indiv.setFitness(trialFitness);
                    population.set(ind, indiv);
                    F = Fm;
                    CR = CRm;
                    scheme = scheme1;
                }else {
                    scheme1 = rng.nextInt(3)+1;
                    Fm = uF[rng.nextInt(uF.length)];
                    CRm = uCR[rng.nextInt(uCR.length)];
                }

                if (population.get(ind).getFitness() < bestFitness) {
                    bestIndividual = population.get(ind);
                    bestFitness = bestIndividual.getFitness();
                }
            }
        }

            bestFitness=population.getBestIndividual().getFitness();
            bestIndividual = population.getBestIndividual();
            return bestIndividual;
    }

    public SubPopulation generationCC(HashMap<Integer, RealVector> pop, RealVector bestind, double bestvalue, List<Integer> subscript, int itermax, ArrayList tracerst) throws IOException {
        return null;
    }

    @Override
    public SiPDEPopulation getPopulation() {
        // TODO Auto-generated method stub
        return population;
    }

    @Override
    public void newRound() {
        // TODO Auto-generated method stub

    }

    public void setParameter(String configName, double value) {
        // TODO Auto-generated method stub
        if (configName.equals("F")) {
            F = value;
        } else if (configName.equals("CR")) {
            CR = value;
        }
    }
}
