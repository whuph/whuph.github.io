The test set is CEC2010

If you want to run the project, run the SgtDETest.scala file under the SgtDE project, which path is SGTDE\src\com\island\SparkTest\SgtDETest.scala.

If you want to understand about this model, you can start with files SgtDETest.scala, hzhDEDeaf.scala.
The paths of the two files in turn are:
1)SGTDE\src\com\island\SparkTest\SgtDETest.scala.
2)SGTDE\src\com\island\SparkStrategies\hzhDEDeaf.scala

If you find this code useful in your work, please cite the 
following paper by the author of the code "He, Z., Peng, H., Chen, J. et al. A Spark-based differential evolution with grouping topology model for large-scale global optimization. Cluster Computing (2020).".