package com.island


import java.util.Random
import org.apache.commons.math3.linear.{ArrayRealVector, RealVector, Array2DRowRealMatrix, RealMatrix}

import scala.collection.mutable.ArrayBuffer
import scala.math.exp
import breeze.linalg.{Vector, DenseVector}
import org.apache.spark._
import org.apache.spark.SparkContext

import org.apache.spark.SparkContext._
import org.apache.spark.{SparkConf,SparkContext}
import cer2003._
import com.txj.Commons._
import cer2003.Function

/**
 * Created by hadoop on 2015-7-5.
 * The basic idea of the island model��
 * 1��An N*D population was distributed to the generationsPerRound generation in the islands
 * 2��After the completion of the evolution of each island, the populations of all islands were recovered, and the individuals with the optimal fitness values of the first N/islands were selected from each island to form a new population
 * 3��And then the next evolution
 * Note: N is the number of islands
 */
object DE {
  var min = -100.0
  var max = 100.0

  var D = 100   // The dimension
  var N = 10*D  // The number of individuals times D
  val F = 0.5  // The zoom factor
  val CR= 0.9  //Crossover probability
  var run=0//The number of times the function runs
  var startFun=0//Starting function
  var endFun=0//End function
  var generationsPerRound=100;//The number of times per round of evolution
  var islands=4;//The number of islands is islands+1;20 island
  //The running time depends on the number of islands
  //The number of islands is related to the number of nodes
  //Crossover probability
  var migrationRounds = 1000//The number of rounds of evolution
  val rand = new Random()
  //Generates a matrix for rows and cols columns
  private def randomMatrix(rows: Int, cols: Int): RealMatrix =
    new Array2DRowRealMatrix(Array.fill(rows, cols)(min+(rand.nextDouble()*(max-min))))

  def generateR(): RealMatrix = {
    randomMatrix(N, D)//It produces a population of N by D;
  }
  //Calculate the fitness value of P
  //I is the line number, ifun is the function, and pop is the population.Find the fitness value of the individual
  def getPopFitness(i: Int,ifun: Int, pop: RealVector): Double = {
    var popf: RealVector = new ArrayRealVector(N)
    var fitness=0.0
    //Call function 2 in Java
    var f=new Function()
    ifun match {
      case 1 => f = new F1();
      case 2 => f = new F2();
      case 3 => f = new F3();
      case 4 => f = new F4();
      case 5 => f = new F5();
      case 6 => f = new F6();
      case 7 => f = new F7();
      case 8 => f = new F8();
      case 9 => f = new F9();
      case 10 => f = new F10();
      case 11 => f = new F11();
      case 12 => f = new F12();
      case 13 => f = new F13();
    }
    //Calculate the value of fitness
    fitness=f.compute(pop.toArray)
    fitness
  }
  //The fitness value of the individual is calculated, and the fitness value is stored in the last column of the individual to form a new individual
  def generalFitPop(i: Int,ifun: Int, pop: RealMatrix):Array[Double]={
    //Define a variable for RealMatrix
    var row=pop.getRowDimension
    var column=pop.getColumnDimension
    //var r = new Array2DRowRealMatrix(row, column)
    var newpop=new Array[Double](column+1)
    //println(newpop.length)
    var fitness=0.0
    //Call function 2 in Java
    var f=new Function()
    ifun match {
      case 1 => f = new F1();
      case 2 => f = new F2();
      case 3 => f = new F3();
      case 4 => f = new F4();
      case 5 => f = new F5();
      case 6 => f = new F6();
      case 7 => f = new F7();
      case 8 => f = new F8();
      case 9 => f = new F9();
      case 10 => f = new F10();
      case 11 => f = new F11();
      case 12 => f = new F12();
      case 13 => f = new F13();
    }
    fitness=f.compute(pop.getRow(i))
    for(j<-0 to pop.getColumnDimension-1){
      newpop(j)=pop.getEntry(i,j)
    }
    newpop(column)=fitness
    newpop
  }

  //Store the dimensions in a variable-length array
  var coordinates = ArrayBuffer[Int]()
  for (i <- 0 to N - 1) {
    coordinates += i
  }
  //Temporarily stored array
  val tempcoordinates = ArrayBuffer[Int]()
  coordinates.copyToBuffer(tempcoordinates)

  //Evolutionary computation;Pop is the population;Pop is read-only and cannot be written
  //Type of return (island number, population)
  def evaluate(island: Int,ifun: Int,pop:RealMatrix,best:Double,generationsPerRound:Int):(Int,RealMatrix,Double) ={
      /*
      Dynamic difference
      1��Variation, crossover
      2��select
       */
    //
    var x1 = 0 //Three random variables, and they're not equal to each other
    var x2 = 0
    var x3 = 0
    val row=pop.getRowDimension()
    val column=pop.getColumnDimension()//The last one is the fitness value

    /*println("==island=="+island+"==start==")
    println("======pop start======")
    for (i<-0 to pop.getRowDimension-1){
      println("==="+i+"===")
      pop.getRow(i).foreach(println)
    }
    println("======pop end======")
    //println("==row=="+row+"==column=="+column)
    println("==island=="+island+"==end==")*/
    var coordinates = ArrayBuffer[Int]()
    for (i <- 0 to row - 1) {
      coordinates += i
    }
    //Temporarily stored array
    val tempcoordinates = ArrayBuffer[Int]()
    coordinates.copyToBuffer(tempcoordinates)
    //pop.getRowVector(0)

    var popu=new Array2DRowRealMatrix(row, column)
    for (i<-0 to row-1){
      for (j<-0 to column-1){
        popu.setEntry(i,j,pop.getEntry(i,j))
      }
      //popu.setRow(i,pop.getRow(i))
    }
    var bestFit = popu.getEntry(0, column - 1) //Gets the value of the column column in the row
    var newbest=best

    /*println("===coordinates===")
    coord.foreach(println)
    println("===coordinates end===")*/
    for (iter<-0 to generationsPerRound){//Number of iterations
      for (i <- 0 to row - 1) {
        //New individuals;The last one is the value of fitness
        var newpop = new Array[Double](column)

        coordinates.remove(i)
        var rnd = rand.nextInt(row - 2)
        x1 = coordinates.apply(rnd)

        coordinates.remove(rnd)
        rnd = rand.nextInt(row - 3)
        x2 = coordinates.apply(rnd)

        coordinates.remove(rnd)
        rnd = rand.nextInt(row - 4)
        x3 = coordinates.apply(rnd)

        var k = 0
        k = ((Math.random() * (column-1)) % (column-1)).toInt 
        
        for (j <- 0 to column - 2) {
          //
          if ((Math.random() < CR) || (j == k)) {
            newpop(j) = popu.getRow(x1).apply(j) + F * (popu.getRow(x2).apply(j) - popu.getRow(x3).apply(j))
            
            if (newpop(j) < min || newpop(j) > max) {
              newpop(j) = min + (rand.nextDouble() * (max - min)) //+1
            }
          } else {
            newpop(j) = popu.getRow(i).apply(j)
          }
        }
        
        var fitness = 0.0
        
        var f = new Function()
        ifun match {
          /*case 1 => f = new F1();
          case 2 => f = new F3();
          case 3 => f = new F5();
          case 4 => f = new F9();
          case 5 => f = new F10();
          case 6 => f = new F11();*/
          case 1 => f = new F1();
          case 2 => f = new F2();
          case 3 => f = new F3();
          case 4 => f = new F4();
          case 5 => f = new F5();
          case 6 => f = new F6();
          case 7 => f = new F7();
          case 8 => f = new F8();
          case 9 => f = new F9();
          case 10 => f = new F10();
          case 11 => f = new F11();
          case 12 => f = new F12();
          case 13 => f = new F13();
        }

        fitness = f.compute(newpop.take(column-1))//The last one is the fitness value;Therefore, when calculating fitness value, the last column should be removed
        newpop(column-1) = fitness
        /*println("======newpop======"+i)
        newpop.foreach(println)
        println("======newpop======"+i)
        println("===fitness==="+fitness)*/
        //println("popu.getRow(i).apply(column - 1)"+popu.getRow(i).apply(column - 1))

        if (fitness < popu.getRow(i).apply(column - 1)) {
          popu.setRow(i, newpop)
          bestFit=fitness
        }
        //Returns an array of three different Numbers to its original value
        coordinates.clear()
        tempcoordinates.copyToBuffer(coordinates)
      }
      if(bestFit<newbest){
        newbest=bestFit
      }
      /*
      println("===evaluate start==="+iter+"======")
      for (i<-0 to popu.getRowDimension-1){
        println("==="+i+"===")
        popu.getRow(i).foreach(println)
      }
      println("===evaluate end==="+iter+"======")*/
      //println("======��"+iter+"��������ֵ======")
      //println(newbest)
      /*println(pop.getRow(row-1).apply(column-1))*/
    }
    (island,popu,newbest)
  }

  def main(args: Array[String]){
    val minFit = ArrayBuffer[String]() //Set[Double]()//Store the optimal values for each generation
    System.setProperty("spark.akka.frameSize","1000000")//The unit is MB
    System.setProperty("spark.scheduler.mode", "FAIR")
    val sparkConf = new SparkConf()
      .setAppName("BroadcastDE")
      //.setMaster("local")
    //.set("spark.executor.memory","2g")
    //sparkConf.setExecutorEnv("spark.akka.frameSize","1000000")
    val sc = new SparkContext(sparkConf)
    //Number of partitions
    var numSlices = if (args.length > 0) args(0).toInt else 2
    D=args(1).toInt//Dimensions of 50 to 50
    N=10*D//500//args(2).toInt
    islands=4
        migrationRounds=10
    generationsPerRound=100
    ///The number of times the function runs
    run=args(2).toInt//The number of times the function runs: from 0
    startFun=args(3).toInt
    endFun=args(4).toInt
      for (ifun <- startFun to endFun) {
        ifun match {
          /*case 1 => min = -100; max = 100; //F1
          case 2 => min = -100; max = 100; //F3
          case 3 => min = -30; max = 30; //F5
          case 4 => min = -5.12; max = 5.12; //F9
          case 5 => min = -32; max = 32; //F10
          case 6 => min = -600; max = 600; //F11*/
          case 1 => min = -100; max = 100; //F1
          case 2 => min = -10; max = 10; //F2
          case 3 => min = -100; max = 100; //F3
          case 4 => min = -100; max = 100; //F4
          case 5 => min = -30; max = 30; //F5
          case 6 => min = -100; max = 100; //F6
          case 7 => min = -1.28; max = 1.28; //F7
          case 8 => min = -500; max = 500; //F8
          case 9 => min = -5.12; max = 5.12; //F9
          case 10 => min = -32; max = 32; //F10
          case 11 => min = -600; max = 600; //F11
          case 12 => min = -50; max = 50; //F12
          case 13 => min = -50; max = 50; //F13
        }
        //����
        for (slice<-0 to 1) {
          slice match {
            case 0 => numSlices = 1;
            case 1 => numSlices = 2;
            case 2 => numSlices = 4;
            case 3 => numSlices = 8;
            case 4 => numSlices = 12;
            case 5 => numSlices = 16;
            case 6 => numSlices = 20;
            case 7 => numSlices = 24;
          }
        var path = ""
        //path = "/home/hadoop/sparkDEResult/SparkDE/resultisland20150709"
         //path = "/home/hadoop/sparkDEResult/SparkDE/resultisland20151005"
         // path = "/home/hadoop/sparkDEResult/SparkDE/resultisland20151210"
          //path = "/home/hadoop/sparkDEResult/SparkDE/resultisland20151211" //30
          //path = "/home/hadoop/sparkDEResult/SparkDE/resultisland20151222" //50
          path = "/home/hadoop/sparkDEResult/SparkDE/resultisland20151224" //100
        //The number of times the function runs
        for (runk <- 1 to run) {
          minFit.clear()
          
          //var popSub: RealMatrix = new Array2DRowRealMatrix(N, 4)

          //Matrix (N*D) N d-dimensional populations
          val startTime = System.currentTimeMillis() //The start time
          //Evolution of pop
          val pop1 = generateR()
          /*
          println("===pop1 start===")
          for (i<-0 to pop1.getRowDimension-1){
            println("==="+i+"===")
            pop1.getRow(i).foreach(println)
          }
          println("===pop1 end===")*/
          var pop1RC=sc.broadcast(pop1)
          //Calculate the fitness value of pop1
          var pop2=sc.parallelize(0 until N,numSlices)
                     .map(i=>generalFitPop(i,ifun,pop1RC.value))
                     .collect()
          println("===pop3 start===")
          //Pop3 adds a list of fitness values to pop1

          var pop3= new Array2DRowRealMatrix(pop2)
          var pop3RC=sc.broadcast(pop3)
          //Find the optimal value of pop3 (initial population)
          var best=pop3.getEntry(0,pop3.getColumnDimension-1)
          for (i<-0 to pop3.getRowDimension-1){
            if (pop3.getEntry(i,pop3.getColumnDimension-1)<best){
              best=pop3.getEntry(i,pop3.getColumnDimension-1)
            }
          }
          println("==The initial optimal value=="+best)
          /*println("===pop3 start===")
          for (i<-0 to pop3.getRowDimension-1){
            println("==="+i+"===")
            pop3.getRow(i).foreach(println)
          }
          println("===pop3 end===")*/

          //Number of runs
          /*
          The optimal value for each round
           */
          var BestFit=0.0

          for (rounds<-0 to migrationRounds) {
            val generationPop = sc.parallelize(0 to islands, numSlices)
                                  .map(i => evaluate(i, ifun, pop3RC.value, best, generationsPerRound))
                                  .collect()
             
            BestFit=generationPop.apply(0)._3
            val p = N / (islands + 1)

            for (i <- 0 to islands) {//The number of the island
            
              val temporarypop = generationPop.apply(i)._2

              //Temp is a two-dimensional array
              val temp = temporarypop.getData
              //1��Ranking temporarypop;The fitness values of the population were arranged in ascending order
              sort.sortDoubleArray(temp, temporarypop.getColumnDimension() - 1)
              //2��Get the first p sorted individuals and assign them to pop3
              //println("Data in the island start")
              /*
              i=1:
              p=3:
             */
              for (j <- i * p to i * p + p - 1) {
               // println("===" + j + "=== j%p=" + j % p)
                //temp.apply(j % p).foreach(println)
                
                pop3.setRow(j, temp.take(p).apply(j % p))
              }
              
              if(generationPop.apply(i)._3<best){
                best=generationPop.apply(i)._3
              }
              /*if(generationPop.apply(i)._3<BestFit){
                BestFit=generationPop.apply(i)._3
              }*/
             // println("Data in the islandend")
              //println("The first "+p+" data of the island start")
              //(temp.take(p).apply(2).foreach(println))//.apply(i).foreach(println)
              //println("The first p data on the island  end")
            }
            pop3RC=sc.broadcast(pop3)
            /*println("=== the valueof pop3 evolved start===")
            for (i <- 0 to pop3.getRowDimension - 1) {
              println("===" + i + "===")
              pop3.getRow(i).foreach(println)
            }
            println("===the valueof pop3 evolved end===")*/
          }
          //Finally, whether to find the optimal value of pop3 again
          for (i<-0 to pop3.getRowDimension-1){
            if (pop3.getEntry(i,pop3.getColumnDimension-1)<best){
              best=pop3.getEntry(i,pop3.getColumnDimension-1)
            }
          }


         
          val endTime = System.currentTimeMillis() //The end of time
          //The deposit values are: F: function, run: times of operations, slices: partitioning, optimal value, and runtime (milliseconds)
          minFit += "F" + (ifun) +"  run:" + (runk) + "  " + "-Slices-" +
            numSlices+"  "+ BestFit.toString + "   " + (endTime - startTime) + "\n"
          //Store the run results locally
          Common.appendMethodB(path, minFit.toString)
        }
      }
    }
    sc.stop()
  }
}
