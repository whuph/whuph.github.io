package com.island.SparkStrategies;

import CEC2013.Function;
//import cer2003.FitnessFunction;
import org.apache.commons.math3.linear.RealVector;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
 * Abstract class for user-defined algorithm
 * @author Dann
 */
public abstract class Algorithm implements Serializable {
    /**
     * Minimal population size for algorithm to work
     */
    protected int minPopulationSize;
    /**
     * Number of dimensions of given fitness function
     */
    protected int dimensions;
    /**
     * Population size
     */
    protected int popSize;
    /**
     * Optimized function
     */
    protected Function function;
    //分组信息
    //public List<Integer> group;
    /**
     * Inidivual with the best fitness, returned by generation()
     */
    protected SiPDEIndividuals bestIndividual;
    /**
     * Population of Individuals for use in algorithm
     */
    protected SiPDEPopulation population;
    /**
     * Fitness of bestIndividual
     */
    protected double bestFitness = Double.MAX_VALUE;

    /**
     * Constructor
     */
    public Algorithm() {
        population = new SiPDEPopulation();
    }

    /**
     * Runs one generation/cycle of algorithm
     * 
     * @return Best Individual from the population
     * @throws IOException
     */
    abstract public SiPDEIndividuals generation() throws Exception;
    abstract public SubPopulation generationCC(HashMap<Integer, RealVector> pop,RealVector bestind,double bestvalue,   List<Integer> subscript,int itermax,ArrayList tracerst) throws IOException;

    /**
     * 
     * @return population used in algorithm
     */
    abstract public SiPDEPopulation getPopulation();

    /**
     * Sets main population to given Population
     * @param population_
     */
    public void setPopulation(SiPDEPopulation population_) {
        population = population_;
        popSize = population.size();
    }

    /**
     * newRound() is called at the end of each round (after emigration)
     * and can be used to alter algorithm configuration or left blank
     * if no alteration is not needed.
     */
    abstract public void newRound();

    /**
     * Sets externally defined algorithm specific parameters.
     * @param configName Name of the parameter to set
     * @param value Value of parameter
     */
    abstract public void setParameter(String configName, double value);
}