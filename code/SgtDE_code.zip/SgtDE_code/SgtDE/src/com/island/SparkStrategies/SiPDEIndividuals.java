﻿package com.island.SparkStrategies;

import org.apache.commons.math3.linear.RealVector;
import org.apache.commons.math3.linear.ArrayRealVector;


import java.io.IOException;
import java.io.Serializable;

/**
 * Created by hadoop on 16-11-10.
 */
public class SiPDEIndividuals implements Serializable {
    protected RealVector geno;
    protected double fitness = Double.POSITIVE_INFINITY;
    protected boolean evaluated = false;
    protected static SiPDEPopulation population;

    protected int index = Integer.MAX_VALUE;
    protected int Line=0;
    protected int dimensions;
    /**
     * @param pop Population in which Individual will be inserted into
     * @throws IOException
     */
    public SiPDEIndividuals(){
        geno=null;
    }
    public SiPDEIndividuals(SiPDEPopulation pop) throws IOException {
        population = pop;
    }
    /**
     *
     * @param pop Population in which Individual will be inserted into
     * @param vals Array of values used as genes
     */
    public SiPDEIndividuals(SiPDEPopulation pop, RealVector vals) {
        population = pop;
        geno = vals;
        dimensions = vals.getDimension();
        evaluated = false;
    }
    /**
     *
     * @param pop Population in which Individual will be inserted into
     * @param vals Array of values used as genes
     */
    public SiPDEIndividuals(SiPDEPopulation pop, RealVector vals,int line) {
        population = pop;
        geno = vals;
        dimensions = vals.getDimension();
        evaluated = false;
        Line=line;
    }
    /**
     *
     * @param pop Population in which Individual will be inserted into
     * @param vals Array of values used as genes

    public SiPDEIndividuals(SiPDEPopulation pop, double[] vals) {
        population = pop;
        geno = vals;
        dimensions = vals.length;

        evaluated = false;
    }*/
    /**
     *
     * @param pop Population in which Individual will be inserted into
     * @param d Number of dimensions
     */
    public SiPDEIndividuals(SiPDEPopulation pop, int d) {
        double min = 0, max = 0;
        dimensions = d;
        geno = new ArrayRealVector(dimensions);
        population = pop;
        evaluated = false;
    }

    public boolean isEvaluated() {
        return evaluated;
    }

    public void setEvaluated(boolean evaluated) {
        this.evaluated = evaluated;
    }

    public int getDimensions() {
        return dimensions;
    }

    public void setDimensions(int dimensions) {
        this.dimensions = dimensions;
    }

    public RealVector getGeno() {
        return geno;
    }

    public void setGeno(RealVector geno) {
        this.geno = geno;
    }

    public int getLine() {
        return Line;
    }

    public void setLine(int line) {
        Line = line;
    }

    /**
     *
     * @param i index of requested gene
     * @return gene with given index
     */
    public double getGeneVect(int i) {
        return geno.getEntry(i);
    }

    /**
     * 
     * @param i index of requested gene
     * @return gene with given index
     */
    public double getGene(int i) {
        return geno.getEntry(i);
    }

    /**
     * Sets one gene to defined value val
     * @param ind Index of gene to set
     * @param val Value to set to the gene
     */
    public void setGene(int ind, double val) {
        geno.setEntry(ind,val);
        evaluated = false;
    }

    /**
     * Sets Individuals fitness to given value f
     * @param f Value to set
     */
    public void setFitness(double f) {
        fitness = f;
        evaluated = true;
    }

    /**
     *
     * @return fitness of Individual
     */
    public double getFitness() {
        return fitness;
    }



    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public static SiPDEPopulation getPopulation() {
        return population;
    }

    public static void setPopulation(SiPDEPopulation population) {
        SiPDEIndividuals.population = population;
    }

    public int compareTo(SiPDEIndividuals o) {
        double cost1 = fitness;
        double cost2 = o.getFitness();

        return (cost1 < cost2 ? -1 : (cost1 == cost2 ? 0 : 1));
    }
    @Override
    public String toString() {
        String str = "";
        str += fitness + "\t";
        for (int i = 0; i < dimensions; i++) {
            str += String.format("%.6f", geno.getEntry(i));
            if (i != dimensions - 1) {
                str += '\t';
            }
        }

        return str;
    }
    /**
     * Sets whole genotype
     * @param values
     */
    public void setValues(RealVector values) {
        geno = values;
        evaluated = false;
    }
    /**
     * Sets value of one gene
     * @param i Index of gene to set
     * @param value Value to set
     */
    public void setValue(int i, double value) {
        //genotype[i] =  value;
        geno.setEntry(i,value);
        evaluated = false;
    }

    /**
     * Sets genes to random values within restrictions
     */
    public void randomize() {
        double min, max;
        for (int i = 0; i < dimensions; i++) {
            min = population.getMinRestriction(i);
            max = population.getMaxRestriction(i);
        }
        evaluated = false;
    }
}
