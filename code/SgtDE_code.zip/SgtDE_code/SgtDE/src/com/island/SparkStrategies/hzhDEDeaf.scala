package com.island.SparkStrategies

import java.{lang, util}

import CEC2013.Common
import com.island.SparkStrategies.Topologies.Ring
import com.util._
import org.apache.spark.rdd.RDD
import org.apache.spark._
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.{SparkConf, SparkContext}
import java.lang.reflect.Constructor

import com.island.SparkTest.SgtDETest.path

import scala.IndexedSeq
//Rename
import java.util.{HashMap => JHashMap}
import scala.collection.mutable.{ArrayBuffer, HashMap}
//import cec2010.{Randomizer, Function}
import CEC2013.Function
import java.util._
/**
  * Created by txj on 2017-06-22.
  */
class hzhDEDeaf extends java.io.Serializable {
  private var nMapTasks: Int = arr_islandCount//*islands  //3
  private[SparkStrategies] var VERBOSE: Boolean = false
  private[SparkStrategies] var WRITEHISTORY: Boolean = false
  private var defaultPopSize: Int = 0
  private[SparkStrategies] var islands: Int = 0
  private[SparkStrategies] var migrationRounds: Int = 0
  private[SparkStrategies] var round: Integer = 0
  var dimensions: Int = 0
  var migratingPopSize: Int = 1
  private[SparkStrategies] var generations: Int = 0
  private[SparkStrategies] var subPopulationSizes: util.ArrayList[Int] = new util.ArrayList[Int] {}
  private[SparkStrategies] var defaultPopulationAlgorithm: Class[_] = null
  private[SparkStrategies] var subPopulationAlgorithms: util.ArrayList[Class[_]] = new util.ArrayList[Class[_]]
  private var function: Class[_] = null
  private var algorithm: Algorithm = null;
  private var fInstance: Function = null
  private var configuredSubpopulations: Int = 0
  private var topology: Class[_] = classOf[Topology]
  private var immigrationMethod: SiPDEPopulation.acceptImmigrantsMethod = null
  private var emigrationMethod: SiPDEPopulation.expelEmigrantsMethod = null
  private[SparkStrategies] var DELETE_HISTORY: Boolean = true

  private[SparkStrategies] var RANDOM_ALGS_AND_PARAMS: Boolean = false

  private[SparkStrategies] var arr_islandCount = 3
  private[SparkStrategies] var min:(Array[(Int, SiPDEPopulation)], Int)=null
  private var min_rdd:Int=0

  //There are five optimizers
  private[SparkStrategies] var NO_OF_ALGORITHMS: Int = 6
  //Start-stop time
  var StartTime: Long = 0
  var EndTime: Long = 0
  var path = ""
  //config Store basic data��such as��F��CR��
  //private var configDouble:HashMap[String,Double]=null
  private var configDouble: util.ArrayList[JHashMap[String, Double]] = new util.ArrayList[JHashMap[String, Double]]()
  //The algorithm for storing the ith island
  private var configAlg: JHashMap[Int, Algorithm] = new JHashMap[Int, Algorithm]()
  //Store the population size of the ith island
  private val configClass: JHashMap[Int, Int] = new JHashMap[Int, Int]()
  //private val genValue:util.ArrayList[Int,Double]=new util.ArrayList[Int,Double]()
  private val genValue: JHashMap[Int, Double] = new JHashMap[Int, Double]()
  var strArrayVar = ArrayBuffer((0, 0.0))

  private var subscript: JHashMap[Integer, List[Integer]] = new JHashMap[Integer, List[Integer]]

  var fun_num: Int = 0

  //object noarr_rdd: Array

  //private val NO_OF_ALGORITHMS:Int = 5
  /**
    *
    * @param fitFunction          FitnessFunction class implementation with optimalized fitness function.
    * @param D                    Number of dimensions of defined fitness function.
    * @param algorithm            Algorithm class implementation with computational algorithm for optimalization of fitness function
    * @param generationsPerRound  Number of generations (cycles of algorithm)
    * @param islandCount          Number of islands for populations. Equals number of Hadoop Map Tasks if not set with setMapTasks().
    * @param populationSize       Default size of populations if not set specifically.
    * @param migratingIndividuals Default number of migrating individuals if not set specifically.
    *                             fitFunction: Class[_ <: FitnessFunction]
    *                             algorithm: Class[_ <: Algorithm]
    */
  def this(temppath: String, fitFunction: Function, D: Int, algorithm: Algorithm, generationsPerRound: Int, islandCount: Int, populationSize: Int, migratingIndividuals: Int,f_num:Int) {
    this()
    this.path = temppath
    generations = generationsPerRound
    islands = islandCount
    defaultPopSize = populationSize
    nMapTasks = islandCount
    migratingPopSize = migratingIndividuals
    this.algorithm = algorithm
    dimensions = D
    fun_num = f_num
    //function = fitFunction
    fInstance = fitFunction
    round = 0
  }

  //RDD data set, configure data for each island, and pass it into RDD, RDD {function F1, population individual}
  private def configureInitialization(sc: SparkContext): RDD[(Int,Array[(Int,SiPDEPopulation)])] = {
    //Initial population
    //System.out.println("Initial population"+nMapTasks+" "+islands+" "+defaultPopSize+" "+dimensions)
    val rdd = sc.parallelize(0 to arr_islandCount - 1, arr_islandCount).map(i => {
    val arr_island2 = Array(1,2,3,4,5)
      val arr_pop=arr_island2.map(r=>{
        val popSize: Int = defaultPopSize //Number of neutrons per island
        //System.out.println("popSize="+popSize+";fInstance="+fInstance)
        val population: SiPDEPopulation = new SiPDEPopulation
        population.clear
        population.setFitnessFunction(fInstance) //Set the function;
        population.addRandomIndividuals(popSize, dimensions) //Generate specific individual value, generate 20 1000-dimensional individuals, loop 5 times
        population.resetIndividualsPopulation //If the generated individual index is messy, reorder
        population.setKey(i) //Set the island number
        val arr=(r, population)
        arr
      })
      val arr2=(i,arr_pop)
      arr2
    }).cache()

    rdd

  }

  val arr_island1 = Array(1,2,3)
  val arr_island2 = Array(1,2,3,4,5)
  def arr1_rdd(fitFunction: Function, D: Int,generationsPerRound: Int)={
    var arr2_rdd = arr_island2.map(r =>{
      val popSize: Int = 20//defaultPopSize //The number of subpopulations of each island.
      this.fInstance = fitFunction
      this.dimensions = D
      //System.out.println("popSize="+popSize+";fInstance="+fInstance)
      val population: SiPDEPopulation = new SiPDEPopulation
      population.clear
      population.setFitnessFunction(fInstance) //Set the function;
      population.addRandomIndividuals(popSize, dimensions) //Generate specific individual value, generate 20 1000-dimensional individuals, loop 5 times
      population.resetIndividualsPopulation //If the generated individual index is messy, reorder
      population.setKey(r) //Set the island number
      (r, population)
    })

    var arr3_rdd = arr_island2.map(r =>{
      val popSize: Int = 20//defaultPopSize //The number of subpopulations of each island.
      this.fInstance = fitFunction
      this.dimensions = D
      //System.out.println("popSize="+popSize+";fInstance="+fInstance)
      val population: SiPDEPopulation = new SiPDEPopulation
      population.clear
      population.setFitnessFunction(fInstance) //Set the function;
      population.addRandomIndividuals(popSize, dimensions) //Generate specific individual value, generate 20 1000-dimensional individuals, loop 5 times
      population.resetIndividualsPopulation //If the generated individual index is messy, reorder
      population.setKey(r) //Set the island number
      (r, population)
    })

    var arr4_rdd = arr_island2.map(r =>{
      val popSize: Int = 20//defaultPopSize //The number of subpopulations of each island.
      this.fInstance = fitFunction
      this.dimensions = D
      //System.out.println("popSize="+popSize+";fInstance="+fInstance)
      val population: SiPDEPopulation = new SiPDEPopulation
      population.clear
      population.setFitnessFunction(fInstance) //Set the function;
      population.addRandomIndividuals(popSize, dimensions) //Generate specific individual value, generate 20 1000-dimensional individuals, loop 5 times
      population.resetIndividualsPopulation //If the generated individual index is messy, reorder
      population.setKey(r) //Set the island number
      (r, population)
    })
    val noarr_rdd =  Array(arr2_rdd,arr3_rdd,arr4_rdd)
    val arr_rdd= noarr_rdd.zipWithIndex
    arr_rdd
  }

  private def arr_configureInitialization(sc: SparkContext): RDD[(Array[(Int,SiPDEPopulation)],Int)] = {  //Array[(Int,SiPDEPopulation)
    val arr5_rdd = arr1_rdd(fInstance, dimensions, generations)
    val arr_rdd=arr5_rdd
    val rdd = sc.parallelize(arr_rdd,3).cache() //sc.parallelize(arr_rdd,islands)The first parameter is the data set to be parallelized, and the second parameter is to cut the data set into several pieces
    rdd
  }


  //Find the best individual from all groups
  private def findBest_arrayIndividual(rdd:RDD[(Int,Array[(Int,SiPDEPopulation)])]) = {
    //private def findBestIndividual(rdd:RDD[(Int,SiPDEPopulation)]): (Int, SiPDEPopulation) = {
    //Group RDD.
    val arr6_rdd = rdd.map(r => {
      (r._2,r._1)
    })
    arr6_rdd
    //X and y represent each of the groups in RDD
    val minrdd= arr6_rdd.reduce((x,y)=>{
      //x._2.map��Find the optimal value for each group's island and save it in an array variable
      val rbf_x:Array[Double]=x._1.map(population=>{
        var bf_x:Double = 0
        val rep_x=population._2.getBestIndividual.getFitness  //rbf:replace_bestFitness replaceable
        if(bf_x<rep_x){
          bf_x = rep_x
        }
        bf_x
      })
      //Find the optimal fitness values for all islands and assign them to bf_x
      val bf_x:Double=rbf_x.min
      val rbf_y:Array[Double]=y._1.map(population=>{
        var bf_y:Double = 0
        val rep_y=population._2.getBestIndividual.getFitness  //rbf:replace_bestFitness need to replace
        if(bf_y<rep_y){
          bf_y = rep_y
        }
        bf_y
      })
      //Find the optimal fitness values for all islands and assign them to bf_y
      val bf_y=rbf_y.min
      //The optimal fitness values of each group were compared to find the optimal group
      if(bf_x < bf_y){
        (x._1,x._2)
      }else{
        (y._1,y._2)
      }
    })
    //Prints the optimal fitness value for the optimal group
    var rep_fitness:Array[Double]=minrdd._1.map(fitness=>{
      var rep_fitness=fitness._2.getBestIndividual.getFitness
      rep_fitness
    })
    val besfFitness = rep_fitness.min
    //System.out.println(minrdd._1+"The optimal value of= "+minrdd._2.getBestIndividual.getFitness)
    System.out.println("minrdd._1 is "+minrdd._2+"The optimal value of = "+besfFitness)
    minrdd

  }

  private def findBestIndividual(rdd:RDD[(Int,Array[(Int,SiPDEPopulation)])]) = {
    val arr6_rdd = rdd.map(r => {
      (r._2,r._1)
    })
    arr6_rdd
    val minrdd= arr6_rdd.reduce((x,y)=>{
      val rbf_x:Array[Double]=x._1.map(population=>{
        var bf_x:Double = 0
        val rep_x=population._2.getBestIndividual.getFitness  //rbf:replace_bestFitness need to replace
        if(bf_x<rep_x){
          bf_x = rep_x
        }
        bf_x
      })
      //Find the optimal fitness values for all islands and assign them to bf_x
      val bf_x:Double=rbf_x.min
      val rbf_y:Array[Double]=y._1.map(population=>{
        var bf_y:Double = 0
        val rep_y=population._2.getBestIndividual.getFitness  //rbf:replace_bestFitness need to replace
        if(bf_y<rep_y){
          bf_y = rep_y
        }
        bf_y
      })
      //Find the optimal fitness values for all islands and assign them to bf_y
      val bf_y=rbf_y.min
      //The optimal fitness values of each group were compared to find the optimal group
      if(bf_x < bf_y){
        (x._1,x._2)
      }else{
        (y._1,y._2)
      }
    })
    //Prints the optimal fitness value for the optimal group
    var rep_fitness:Array[Double]=minrdd._1.map(fitness=>{
      var rep_fitness=fitness._2.getBestIndividual.getFitness
      rep_fitness
    })
    val besfFitness = rep_fitness.min
    System.out.println("minrdd._1 is "+minrdd._2+"The optimal value of = "+besfFitness)
    besfFitness
   
  }

  def test_rdd1(arr7_rdd:RDD[(Int,Array[(Int,SiPDEPopulation)])]) ={
         val arr_rdd3=arr_rdd2.reduce((n,m) => {
             (n._1,n._2)
     })
     val arr_rdd4=arr_rdd2.reduce((n,m) => {
         (m._1,m._2)
     })
     val rdd6=arr_rdd3
        algorithm.setPopulation(arr_pop._2)
        arr_pop._2.resetIndividualsPopulation()//Reset the individual population.
        //Get the F and CR values of each island and assign them to the F and CR values of algorithm
        algorithm.setParameter("F",configDouble.get(r._2).get("F"))
        algorithm.setParameter("CR",configDouble.get(r._2).get("CR"))
        val sipdeindividuals:SiPDEIndividuals= algorithm.generation(); //Call the GDCS.generation() method, mutate, cross, iterate 1000 times
        val pop=algorithm.getPopulation //Get the population attribute in algorithm, including function, pop, bestind, FS, CRS, etc
        val arr=(r._1(2)._1,pop)//,strArrayVar��pop contains population data
      (arr,r._2)
    })//.cache()
    arr8_rdd
  }


  private def printBestIndividual(winner: (Int, SiPDEPopulation)) {
    if (winner == null) {
      System.out.println("---- Unable to print best individual !")
    }
    else {
      System.out.println("---- Best so far : \n" + winner._2.getBestIndividual.getFitness)
    }
  }

  def createRandomPopulation(sc: SparkContext): RDD[(Int,Array[(Int,SiPDEPopulation)])] = {  //Array[(Int,SiPDEPopulation)]
    val arr_rdd=configureInitialization(sc)//Configure initial population
    val bestInd: (Array[(Int,SiPDEPopulation)],Int) = findBest_arrayIndividual(arr_rdd)
    arr_rdd
  }
  val bestInd: (Array[(Int,SiPDEPopulation)],Int) = null
  def run(arr_rdd:RDD[(Int,Array[(Int,SiPDEPopulation)])],round:Int,arr_islandCount:Int)= {
    var generationsPerRound: Int = 0
    var oldRdd=arr_rdd
    var  topology:Topology =new Ring(islands); 
    var tempvalue=""
    val tempvalue1 = " F" + (fun_num) +"  run " +  "  " + " Slices " + "\n"
    Common.appendMethodB(path, tempvalue1)//Store data.
    for (i <-0 to round-1) {//round=30
      System.out.println("The"+i+"round.")
      val arr8_rdd=oldRdd.map(r=>{ //This step is to assign values of F and CR to each island.
        //R._1 is the island number, and r._2 is the number of individuals (20) contained in each island.
          if(false){
            this.NO_OF_ALGORITHMS=2//r._1
            setRandomAlgAndParams1(algorithm.function,algorithm.dimensions,algorithm.popSize,islands, NO_OF_ALGORITHMS,generationsPerRound,i,min_rdd);
          }
        val arr_population = r._2//Take one island each time and group.
        //var arr:Array[(Int,SiPDEPopulation)]=new Array[(Int,SiPDEPopulation)]
        val arr1_pop=arr_population.map(arr2_pop=>{
          algorithm.setPopulation(arr2_pop._2)
          arr2_pop._2.resetIndividualsPopulation()//Reset the individual population.
          //Get the F and CR values of each island and assign them to the F and CR values of algorithm
          algorithm.setParameter("F",configDouble.get(r._1).get("F"))
          algorithm.setParameter("CR",configDouble.get(r._1).get("CR"))
          val sipdeindividuals:SiPDEIndividuals= algorithm.generation(); 
          val pop=algorithm.getPopulation //Get the population attribute in algorithm, including function, pop, bestind, FS, CRS, etc
          var arr3=(arr2_pop._1,pop)
          arr3
        })  
        var arr9_rdd=(r._1,arr1_pop)
        arr9_rdd
      })
      var arr10_rdd=arr8_rdd
               val pop=algorithm.getPopulation //Get the population attribute in algorithm, including function, pop, bestind, FS, CRS, etc
                   (r._1,(population._1,pop))//,strArrayVar��pop contains population data
               })
           })

      //Exchange between emigrants1 are grouped.
      val emigrants1:RDD[(Int,Array[(Int,SiPDEPopulation)])]=arr10_rdd.map(arr=> {
        val arr_population = arr._2
        val arr1_emig = arr_population.map(ind => {
          val emig = ind._2.getEmigrants(migratingPopSize, emigrationMethod)
          emig.resetIndividualsPopulation();
          //emig contains 15 individuals to be migrated, reassigned to 15 individuals,0-14 
          val arr2_emig = (ind._1, emig) //r._1��Island number��emig��15 migrating individuals
          arr2_emig
        })
        val arr11_rdd=(arr._1,arr1_emig)
        arr11_rdd
      })
      //SiPDEPartitioner is switching between packets
      val partitioner1=new SiPDEPartitioner_wang(emigrants1,topology,arr_islandCount,islands,immigrationMethod)
      val rdd2=arr10_rdd.map(r=>{
        (r._2,r._1)
      }).partitionBy(partitioner1).cache()

      //The outgoing population is passed into the partition function
        oldRdd=rdd2.map(r=>{
          (r._2,r._1)
        })
        })
      }





           //System.out.print("rdd2.partitioner:"+rdd2.partitioner)
           StartTime=System.currentTimeMillis()
           min = findBest_arrayIndividual(arr8_rdd)  //new
           var rep_fitness:Array[Double]=min._1.map(fitness=>{
            var rep_fitness=fitness._2.getBestIndividual.getFitness
            rep_fitness
          })
           val temp_besfFitness = rep_fitness.min
           System.out.println("minrdd._1 is "+min._2+"The optimal value of = "+temp_besfFitness)
           temp_besfFitness
           tempvalue += (i+1)+" "+temp_besfFitness
           /*var tempbestInd = findBestIndividual(arr8_rdd)
           tempvalue += (i+1)+" "+tempbestInd*/
           EndTime=System.currentTimeMillis()
           tempvalue+= " "+(EndTime - StartTime)+" \n"
           System.out.println(tempvalue);


       }
       //Output the optimal value
       val bestInd = findBest_arrayIndividual(arr_rdd)
       //tempvalue+=bestInd._2.getBestIndividual.getFitness
       Common.appendMethodB(path, tempvalue)
       //printBestIndividual(bestInd)
       bestInd
     //arr8_rdd
    }
  //override def partitionBy(partitioner : org.apache.spark.Partitioner):  org.apache.spark =
  def getRound: Int = {
    round
  }

  def setRound(nr: Int) {
    val round = nr
  }

  def getGenValue(): JHashMap[Int, Double] ={
    genValue
  }

  /***
    count Is the number of islands
    nAlgs Is the type of algorithm
    **/
  def setRandomAlgAndParams(count:Int, nAlgs:Int) {
    var generator:Random = new Random();
    for (i <- 0 to count) {
      var r:Int = generator.nextInt(nAlgs)
      var names:String = ""
      //var alg  //Class[_ <:Algorithm]
      var F=0.0
      var CR=0.0
      var printArgs:String = "";
      r match {
        case 0=>
          var alg = new GBCS
          configAlg.put(i,alg)
          F = generator.nextFloat()*2;
          CR = generator.nextFloat();
          val subpopParameters = new JHashMap[String, Double]();
          subpopParameters.put("F", F)
          subpopParameters.put("CR", CR)
          configDouble.add(i,subpopParameters)
        case 1=>
          var alg =new GBCS
          configAlg.put(i,alg)
          F = generator.nextFloat()*2;
          CR = generator.nextFloat();
          val subpopParameters = new JHashMap[String, Double]();
          subpopParameters.put("F", F)
          subpopParameters.put("CR", CR)
          configDouble.add(i,subpopParameters)
        case 2=>
          var alg =new GBCS
          configAlg.put(i,alg)
          F = generator.nextFloat()*2;
          CR = generator.nextFloat();
          val subpopParameters = new JHashMap[String, Double]();
          subpopParameters.put("F", F)
          subpopParameters.put("CR", CR)
          configDouble.add(i,subpopParameters)
        case 3=>
          var alg =new GBCS
          configAlg.put(i,alg)
          F = generator.nextFloat()*2;
          CR = generator.nextFloat();
          val subpopParameters = new JHashMap[String, Double]();
          subpopParameters.put("F", F)
          subpopParameters.put("CR", CR)
          configDouble.add(i,subpopParameters)
        case 4=>
          var alg =new GBCS
          configAlg.put(i,alg)
          F = generator.nextFloat()*2;
          CR = generator.nextFloat();
          val subpopParameters = new JHashMap[String, Double]();
          subpopParameters.put("F", F)
          subpopParameters.put("CR", CR)
          configDouble.add(i,subpopParameters)
        case _=> println("error");
      }
      configClass.put(i,defaultPopSize)
    }
  }
 
  def setRandomAlgAndParams1(f: Function, D_ : Int, popSize_ : Int,count:Int, nAlgs:Int,generationsPerRound:Int,I:Int,min_rdd:Int) {
    var generator:Random = new Random();
    for (i <- 0 to count) {
      var r:Int = nAlgs//generator.nextInt(nAlgs)
      var names:String = ""
      var F=0.0
      var CR=0.0
      var printArgs:String = "";
      r match {  
        case 0=>
          var alg = new GBCS(f,D_,popSize_,generationsPerRound)  //DECurrentToPBest
          this.algorithm=alg
        case 1=>
          var alg = new GBCS(f,D_,popSize_,generationsPerRound) //CUDE4��DEBest1bin  //CUDE

          this.algorithm=alg
        case 2=>
          var alg = new GBCS(f,D_,popSize_,generationsPerRound)//CUDE6��DECurrentToBest  JADE1
          this.algorithm=alg

      }
      configClass.put(i,defaultPopSize)
    }
  }

  /**
    * Sets algorithms according to their ratings...
    */
  def setRatedAlgorithms {
  }

  /**
    *
    * @param top Topology extending class defining the topology of islands (determines the destination island for migrating population)
    */
  def setTopology(top: Class[_ <: Topology]) {
    topology = top
  }
  def setRANDOM_ALGS_AND_PARAMS(RANDOM_ALGS_AND_PARAMS:Boolean): Unit ={
    this.RANDOM_ALGS_AND_PARAMS=RANDOM_ALGS_AND_PARAMS
  }

  /**
    * Determines how immigrating individuals are handled.
    *
    * @param met One of Population.acceptImmigrantsMethod (REPLACE_WORST, REPLACE_BEST, REPLACE_RANDOM, NO_REPLACE).
    */
  def setImmigrationMethod(met: SiPDEPopulation.acceptImmigrantsMethod) {
    immigrationMethod = met
  }

  /**
    * Determines how emigrating individuals are chosen.
    *
    * @param met One of Population.expelEmigrantsMethod (EXPEL_BEST, EXPEL_RANDOM).
    */
  def setEmigrationMethod(met: SiPDEPopulation.expelEmigrantsMethod) {
    emigrationMethod = met
  }

  /**
    * If verbose setting is set to true, all populations with all their individuals will be written to Logger
    *
    * @param verb true/false
    */
  def setVerbose(verb: Boolean) {
    VERBOSE = verb
  }
  /**
    *@param index is the number of the island
    * @param alg Population specific algorith
    * @param subpopParameters Map collection of parameters for given algorithm
    */
  def addSubpopulationsConfig(index:Int,alg:Class[_ <: Algorithm], subpopParameters:JHashMap[String, Double]) {
    addSubpopulationsConfig(index,alg, defaultPopSize, subpopParameters);
  }
  //addSubpopulationsConfig :Class[_ <: Algorithm]
  def addSubpopulationsConfig(index:Int,alg: Class[_ <: Algorithm], popSize:Int, subpopParameters:JHashMap[String, Double]){
    //Store the data.
    //Store parameters F and CR in the corresponding island
    configDouble.add(index,subpopParameters)
    //Store optimizer
    configAlg.put(index,alg.newInstance().asInstanceOf[Algorithm])
    //population size
    configClass.put(index,popSize)

  }
}
