package com.island.SparkStrategies

import java.{lang, util}

import cer2003.Common
import com.island.SparkStrategies.Topologies.Ring
import com.util.{IteblogPartitioner, SiPDEPartitioner, newInstanceObject}
import org.apache.spark.rdd.RDD
import org.apache.spark._
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.{SparkConf, SparkContext}
import java.lang.reflect.Constructor

import com.island.SparkTest.SiPDECCTest.path

import scala.IndexedSeq
//Rename 
import java.util.{HashMap => JHashMap}
import scala.collection.mutable.{ArrayBuffer, HashMap}
import cec2010.{Randomizer, Function}
import java.util._
/**
 * Created by txj on 2017-06-22.
 */
class txjDEDeaf extends java.io.Serializable {
    private var nMapTasks: Int = 3
    private[SparkStrategies] var VERBOSE: Boolean = false
    private[SparkStrategies] var WRITEHISTORY: Boolean = false
    private var defaultPopSize: Int = 0
    private[SparkStrategies] var islands: Int = 0
    private[SparkStrategies] var migrationRounds: Int = 0
    private[SparkStrategies] var round: Integer = 0
    var dimensions: Int = 0
    var migratingPopSize: Int = 1
    private[SparkStrategies] var generations: Int = 0
    private[SparkStrategies] var subPopulationSizes: util.ArrayList[Int] = new util.ArrayList[Int] {}
    private[SparkStrategies] var defaultPopulationAlgorithm: Class[_] = null
    private[SparkStrategies] var subPopulationAlgorithms: util.ArrayList[Class[_]] = new util.ArrayList[Class[_]]
    private var function: Class[_] = null
    private var algorithm: Algorithm = null;
    private var fInstance: Function = null
    private var configuredSubpopulations: Int = 0
    private var topology: Class[_] = classOf[Topology]
    private var immigrationMethod: SiPDEPopulation.acceptImmigrantsMethod = null
    private var emigrationMethod: SiPDEPopulation.expelEmigrantsMethod = null
    private[SparkStrategies] var DELETE_HISTORY: Boolean = true

    private[SparkStrategies] var RANDOM_ALGS_AND_PARAMS: Boolean = false

    //New data
    private[SparkStrategies] var arr_islandCount = 3

    //There are five optimizers
    private[SparkStrategies] var NO_OF_ALGORITHMS: Int = 6
    //Start-stop time
    var StartTime: Long = 0
    var EndTime: Long = 0
    var path = ""
    //Config stores basic data, such as F, CR,
    //private var configDouble:HashMap[String,Double]=null
    private var configDouble: util.ArrayList[JHashMap[String, Double]] = new util.ArrayList[JHashMap[String, Double]]()
    //The algorithm for storing the i-th island    private var configAlg: JHashMap[Int, Algorithm] = new JHashMap[Int, Algorithm]()
    //The population size of the ith island
    private val configClass: JHashMap[Int, Int] = new JHashMap[Int, Int]()
    //private val genValue:util.ArrayList[Int,Double]=new util.ArrayList[Int,Double]()
    private val genValue: JHashMap[Int, Double] = new JHashMap[Int, Double]()
    var strArrayVar = ArrayBuffer((0, 0.0))

    private var subscript: JHashMap[Integer, List[Integer]] = new JHashMap[Integer, List[Integer]]
    //private val NO_OF_ALGORITHMS:Int = 5
    /**
      *
      * @param fitFunction          FitnessFunction class implementation with optimalized fitness function.
      * @param D                    Number of dimensions of defined fitness function.
      * @param algorithm            Algorithm class implementation with computational algorithm for optimalization of fitness function
      * @param generationsPerRound  Number of generations (cycles of algorithm)
      * @param islandCount          Number of islands for populations. Equals number of Hadoop Map Tasks if not set with setMapTasks().
      * @param populationSize       Default size of populations if not set specifically.
      * @param migratingIndividuals Default number of migrating individuals if not set specifically.
      *                             fitFunction: Class[_ <: FitnessFunction]
      *                             algorithm: Class[_ <: Algorithm]
      */
    def this(temppath: String, fitFunction: Function, D: Int, algorithm: Algorithm, generationsPerRound: Int, islandCount: Int, populationSize: Int, migratingIndividuals: Int) {
        this()
        this.path = temppath
        generations = generationsPerRound
        islands = islandCount
        defaultPopSize = populationSize
        nMapTasks = islandCount
        migratingPopSize = migratingIndividuals
        //immigrationMethod = SiPDEPopulation.acceptImmigrantsMethod.REPLACE_WORST
        //emigrationMethod = SiPDEPopulation.expelEmigrantsMethod.EXPEL_BEST
        //defaultPopulationAlgorithm = algorithm
        //val args:List[Int] = List{fitFunction;dimensions;defaultPopSize};
        //args = new Any{function dimensions popSize};
        /*The following call is made to the private constructor with arguments*/
        //this.algorithm= algorithm.newInstance().asInstanceOf[Algorithm]
        //this.algorithm=algorithm.getDeclaredConstructor(AnyRef.getClass).newInstance(args).asInstanceOf[Algorithm]
        //this.algorithm=newInstanceObject.get(fitFunction,dimensions,defaultPopSize)
        this.algorithm = algorithm
        dimensions = D
        //function = fitFunction
        fInstance = fitFunction
        //Group fitness functions
        subscript = Randomizer.randIndexperm(fInstance)
        round = 0
    }

    //RDD data set, configure data for each island, pass into RDD, RDD {function F1, population individual}
    private def configureInitialization(sc: SparkContext): RDD[(Int, SiPDEPopulation)] = {
        //Initial population        //System.out.println("Initial population"+nMapTasks+" "+islands+" "+defaultPopSize+" "+dimensions)
        //val rdd = sc.parallelize(0 to arr_islandCount - 1, arr_islandCount).map(i => {
        //for(r<-0 to arr_islandCount-1){
        //val arr_islandPopulation = new arr_islandPopulation(arr_islandCount);
        val rdd = sc.parallelize(0 to islands - 1, islands).map(i => {
            //val rdd = sc.parallelize(0 to arr_islandCount - 1, arr_islandCount).map(i => {
            //val arr_islandPopulation: arr_islandPopulation = new arr_islandPopulation()
            //for(r<-0 to 4) {
            val popSize: Int = defaultPopSize //The number of subpopulations per island
            //System.out.println("popSize="+popSize+";fInstance="+fInstance)
            val population: SiPDEPopulation = new SiPDEPopulation
            population.clear
            //population.setFitnessFunction(fInstance) //Set the function��
            population.addRandomIndividuals(popSize, dimensions) //Generate specific individual values, generate 20 1000 - dimensional individuals, cycle 5 times
            population.resetIndividualsPopulation //If the generated individual subscripts are out of order, reorder them
            population.setKey(i) //Set the number of the island
            (i, population)
            //}
            //(i,arr_islandPopulation)
        }).cache()

        rdd

    }

    val arr_island1 = Array(1,2,3)
    val arr_island2 = Array(1,2,3,4,5)
    def arr1_rdd(fitFunction: Function, D: Int,generationsPerRound: Int)={
        var arr2_rdd = arr_island1.map(i =>{
            var arr3_rdd = arr_island2.map(r =>{
                val popSize: Int = 20//defaultPopSize //The number of subpopulations per island
                this.fInstance = fitFunction
                this.dimensions = D
                //System.out.println("popSize="+popSize+";fInstance="+fInstance)
                val population: SiPDEPopulation = new SiPDEPopulation
                population.clear
                //population.setFitnessFunction(fInstance) //Set the function��
                population.addRandomIndividuals(popSize, dimensions) //Generate specific individual values, generate 20 1000-dimensional individuals, cycle 5 times
                population.resetIndividualsPopulation //If the generated individual subscripts are out of order, reorder them
                population.setKey(r) //Set the number of the island                (r, population)
            })
            (i,arr3_rdd)
        })
         arr2_rdd

    }


    //val island:Unit = (1,2,3,4,5)
    //val arr_island = Array(1,2,3,4,5)
    private def arr_configureInitialization(sc: SparkContext): RDD[(Int, Array[(Int,SiPDEPopulation)])] = {  //Array[(Int,SiPDEPopulation)
        val arr6_rdd = arr1_rdd(fInstance, dimensions, generations)
       /* val fj_rdd = arr6_rdd
        val fj2_rdd = test_rdd1(fj_rdd)*/
        val rdd = sc.parallelize(arr6_rdd).cache()
        rdd
    }

   /* def  arr_main(int: Int): Unit = {
        val island = Array(1, 2, 3, 4, 5)
        //val arr = for (r <- 0 to 4) {
        var arr = island.map(r => {
            val popSize: Int = defaultPopSize //The number of subpopulations per island

            val population: SiPDEPopulation = new SiPDEPopulation
            population.clear
            population.addRandomIndividuals(2, 3) //Generate specific individual values, generate 20 1000-dimensional individuals, cycle 5 times
            population.resetIndividualsPopulation //If the generated individual subscripts are out of order, reorder them            population.setKey(r) //Set the number of the island
            (r, population)
        })
        arr
    }*/

    //Look for the best individuals from all groups
    private def findBestIndividual(rdd:RDD[(Int, Array[(Int,SiPDEPopulation)])]) = {
        //private def findBestIndividual(rdd:RDD[(Int,SiPDEPopulation)]): (Int, SiPDEPopulation) = {
       //The RDD grouping
        val arr_rdd4 = rdd.map(r => {
            (r._1,r._2)
        })
        arr_rdd4
        //X and y represent each group in the grouping RDD
        val minrdd= arr_rdd4.reduce((x,y)=>{
            //X._2.map, find the optimal value of each group island, and save it into an array variable            val rbf_x:Array[Double]=x._2.map(population=>{
                var bf_x:Double = 0
                val rep_x=population._2.getBestIndividual.getFitness  //RBF :replace_bestFitness represents what needs to be replaced
                if(bf_x<rep_x){
                    bf_x = rep_x
                }
                bf_x
            })
            //Find the optimal fitness values for all islands and assign them to bf_x            val bf_x:Double=rbf_x.min
            val rbf_y:Array[Double]=y._2.map(population=>{
                var bf_y:Double = 0
                val rep_y=population._2.getBestIndividual.getFitness  //RBF :replace_bestFitness represents what needs to be replaced
                if(bf_y<rep_y){
                    bf_y = rep_y
                }
                bf_y
            })
            //Find the optimal fitness values for all islands and assign them to bf_y
            val bf_y=rbf_y.min
            //The optimal fitness value of each group was compared to find the optimal group
            if(bf_x < bf_y){
                (x._1,x._2)
            }else{
                (y._1,y._2)
            }
        })
        //Print the optimal fitness value of the optimal group
        var rep_fitness:Array[Double]=minrdd._2.map(fitness=>{
            var rep_fitness=fitness._2.getBestIndividual.getFitness
            rep_fitness
        })
        val besfFitness = rep_fitness.min
        //System.out.println(minrdd._1+"The optimal value of= "+minrdd._2.getBestIndividual.getFitness)
        System.out.println("minrdd._1 is"+minrdd._1+"The optimal value of= "+besfFitness)
        minrdd

    }

    def test_rdd1(arr5_rdd:RDD[(Int,Array[(Int,SiPDEPopulation)])]) ={

       /* /*var oldRdd=arr_rdd2.map(r => {
            (r._1,r._2)
        })
        oldRdd*/
        //var oldRdd=arr_rdd2.map(r=>{
            val arr_rdd3=arr_rdd2.reduce((n,m) => {
                (n._1,n._2)
        })
        val arr_rdd4=arr_rdd2.reduce((n,m) => {
            (m._1,m._2)
        })
        /*val arr_rdd5=arr_rdd2.reduce((n,m) => {
            if(n._1<m._1){
                (m._1,m._2)
            }


        })*/
        val rdd6=arr_rdd3.*/

        /*val rdd1= arr5_rdd.map(r=>{ //This step is to assign a value F, a value CR for each island��
            val hzh:Int=6
            //R._1 is the island number, and r._2 is the number of individuals in each island,20. Put F and CR into the algorithm of each island
            val arr_population=r._2.map(population =>{  //(x=>x.map(x=>x*2))
                val arr_population=population._2
                algorithm.setPopulation(arr_population)
                arr_population.resetIndividualsPopulation()//Reset individual populations, 20
                //Get the F and CR values of each island and assign them to the F and CR values in the algorithm
                algorithm.setParameter("F",configDouble.get(r._1).get("F"))
                algorithm.setParameter("CR",configDouble.get(r._1).get("CR"))
                //generationsPerRound=generations//Evolutionary algebra in each subpopulation
                //islands
                val sipdeindividuals:SiPDEIndividuals= algorithm.generation(); //Call the CUDE. Generation () method, mutate, cross, and iterate 940 times
                val pop=algorithm.getPopulation //Get the population attribute in algorithm, including function, pop, bestind, FS, CRS, etc                (population,pop)//StrArrayVar, pop contains population data            })
            (r,arr_population)
        })
        rdd1
        val m:Int=7*/


        /*val rdd1= arr5_rdd.flatMap(r=>
            r._2.map(population=>{
                //This step is to assign a value F, a value CR for each island
                //R._1 is the island number, and r._2 is the number of individuals in each island,20. Put F and CR into the algorithm of each island
                val arr_population=population._2
                algorithm.setPopulation(arr_population)
                arr_population.resetIndividualsPopulation()//Reset individual populations, 20
                //Get the F and CR values of each island and assign them to the F and CR values in the algorithm
                algorithm.setParameter("F",configDouble.get(r._1).get("F"))
                algorithm.setParameter("CR",configDouble.get(r._1).get("CR"))
                //generationsPerRound=generations//Evolutionary algebra in each subpopulation
                //islands
                val sipdeindividuals:SiPDEIndividuals= algorithm.generation(); //Call the CUDE. Generation () method, mutate, cross, and iterate 940 times
                val pop=algorithm.getPopulation //Get the population attribute in algorithm, including function, pop, bestind, FS, CRS, etc
                (population,pop)//,StrArrayVar, pop contains population data            })
        )*/
        /*val rdd2=arr5_rdd.take(1)
        val rdd3=rdd2.take(1)*/
       /* val rdd1= arr5_rdd.map(r=>{ //This step is to assign a value F, a value CR for each island��
            val hzh:Int=6
            r
            //R._1 is the island number, and r._2 is the number of individuals in each island,20. Put F and CR into the algorithm of each isl
                       // val arr_population:Array[(Int,SiPDEPopulation)]=r
               val arr_population = r._2
                arr_population.reverseMap(population=>{

                    algorithm.setPopulation(population._2)
                    population._2.resetIndividualsPopulation()//Reset individual populations, 20                    //Get the F and CR values of each island and assign them to the F and CR values in the algorithm                    algorithm.setParameter("F",configDouble.get(r._1).get("F"))
                    algorithm.setParameter("CR",configDouble.get(r._1).get("CR"))
                    //generationsPerRound=generations//Evolutionary algebra in each subpopulation
                    //islands
                    val sipdeindividuals:SiPDEIndividuals= algorithm.generation(); //Call the CUDE. Generation () method, mutate, cross, and iterate 940 times
                    val pop=algorithm.getPopulation //Get the population attribute in algorithm, including function, pop, bestind, FS, CRS, etc
                    (population,pop)//,StrArrayVar, pop contains population data                })
            (r,arr_population)
        })
        rdd1
        val m:Int=7
    }*/

        arr5_rdd.map(r=>{ //This step is to assign a value F, a value CR for each island��
            //R._1 is the island number, and r._2 is the number of individuals in each island,20. Put F and CR into the algorithm of each isl
            // val arr_population:Array[(Int,SiPDEPopulation)]=r
            val arr_population = r._2
            //r._2.collect[(Int,SiPDEPopulation),SiPDEPopulation]
            arr_population.map(population=>{
                algorithm.setPopulation(population._2)
                population._2.resetIndividualsPopulation()//Reset individual populations, 20                //Get the F and CR values of each island and assign them to the F and CR values in the algorithm
                algorithm.setParameter("F",configDouble.get(r._1).get("F"))
                algorithm.setParameter("CR",configDouble.get(r._1).get("CR"))
                //generationsPerRound=generations//Evolutionary algebra in each subpopulation
                //islands
                val sipdeindividuals:SiPDEIndividuals= algorithm.generation(); //Call the CUDE. Generation () method, mutate, cross, and iterate 940 times
                val pop=algorithm.getPopulation //Get the population attribute in algorithm, including function, pop, bestind, FS, CRS, etc
                (population,pop)//,StrArrayVar, pop contains population data            })
            val fin_rdd =(r._1,arr_population)
            System.out.println(fin_rdd._1)
        })
       // arr5_rdd.takeSample(false,1,)
        val x=arr5_rdd.count()

        val m:Int=7
    }


    private def printBestIndividual(winner: (Int, SiPDEPopulation)) {
        if (winner == null) {
            System.out.println("---- Unable to print best individual !")
        }
        else {
            System.out.println("---- Best so far : \n" + winner._2.getBestIndividual.getFitness)
        }
    }

    def createRandomPopulation(sc: SparkContext): RDD[(Int,Array[(Int,SiPDEPopulation)])] = {  //Array[(Int,SiPDEPopulation)]
        //val rdd=configureInitialization(sc)//Initial population allocation
        val arr_rdd = arr_configureInitialization(sc)
        /*rdd.foreach{x=>{
            println("The serial number of the island��"+x._1+";x="+x._2.getBestIndividual.getFitness)
        }}*/
        //val bestInd: (Int, arr_islandPopulation) = findBestIndividual(rdd)//Looking for the best individual
        val bestInd: (Int,Array[(Int,SiPDEPopulation)]) = findBestIndividual(arr_rdd)

        //val test_rdd: (Unit)= test_rdd1(arr_rdd)
        //printBestIndividual(bestInd)
        arr_rdd
    }
    /*def run(arr_rdd:RDD[(Int,Array[(Int,SiPDEPopulation)])],round:Int,arr_islandCount:Int):((Int,Array[(Int,SiPDEPopulation)]))= {
        val test_rdd: RDD[((Int,Array[(Int,SiPDEPopulation)]))] = test_rdd1(arr_rdd)
    }*/
    def run(arr_rdd:RDD[(Int,Array[(Int,SiPDEPopulation)])],round:Int,arr_islandCount:Int)= {
        var oldRdd=arr_rdd.map(r=>{  //:RDD[(Int,Array[(Int,SiPDEPopulation)])]
            val population=r._2
            (r._1,population)
        })
        //val arr6_rdd = arr1_rdd(fInstance, dimensions, generations)
       val test_rdd = test_rdd1(oldRdd)//.cache() //RDD[((Int,Array[(Int,SiPDEPopulation)]))]
        val x:Int=6
    }
    //
    var bestInd: (Int, SiPDEPopulation) = null
    //round=30 generationsPerRound=100
   /* def run(arr_rdd:RDD[(Int,Array[(Int,SiPDEPopulation)])],round:Int,arr_islandCount:Int):((Int,Array[(Int,SiPDEPopulation)]))={
        //The best individual
        //val bestInd: SiPDEPopulation =null
        var generationsPerRound: Int = 0
        var oldRdd=arr_rdd
        //var bestInd: (Int, SiPDEPopulation)=null
        //System.out.println("Round number is"+round)
        //The topology of the migration
        var  topology:Topology =new Ring(islands);         //val path =  //"/home/hadoop/sparkCUDEResult/resultCUDEisland20161122"
        var tempvalue=""
        val tempvalue1 = " F " + (fInstance.getClass.getName) +"  run " +  "  " + " Slices " + "\n"
        Common.appendMethodB(path, tempvalue1)//Store the data        //var genValue=null
        for (i <-0 to round-1) {//round=30
            //Migrating species            //var immigrants: RDD[(Int, SiPDEPopulation)] = oldRdd
            //immigrants=oldRdd
            //Evolving population
            //val array=ArrayBuffer()
            //Split the oldRdd
            System.out.println("The"+i+"round")
            val rdd1= oldRdd.map(r=>{ //This step is to assign a value F, a value CR for each island��
                if(RANDOM_ALGS_AND_PARAMS){
                    //f: Function, D_ : Int, popSize_ : Int,count:Int, nAlgs:Int
                    setRandomAlgAndParams1(algorithm.function,algorithm.dimensions,algorithm.popSize,islands, NO_OF_ALGORITHMS,generationsPerRound);
                }
                //R._1 is the island number, and r._2 is the number of individuals in each island,20. Put F and CR into the algorithm of each isl
                val arr_population=r._2.map(population =>{
                    val arr_population=population._2
                algorithm.setPopulation(arr_population)
                arr_population.resetIndividualsPopulation()//Reset individual populations, 20
                //Get the F and CR values of each island and assign them to the F and CR values in the algorithm
                algorithm.setParameter("F",configDouble.get(r._1).get("F"))
                algorithm.setParameter("CR",configDouble.get(r._1).get("CR"))
                //generationsPerRound=generations//Evolutionary algebra in each subpopulation
                //islands
                val sipdeindividuals:SiPDEIndividuals= algorithm.generation(); //Call the CUDE. Generation () method, mutate, cross, and iterate 940 times

                val pop=algorithm.getPopulation //Get the population attribute in algorithm, including function, pop, bestind, FS, CRS, etc
                    (r._1,(population._1,pop))//,StrArrayVar, pop contains population data                })
            })
            //Where to wait for modification
            /*System.out.println("map֮��strArrayVar==")
            strArrayVar.foreach(print)
            System.out.println("map֮��strArrayVarx.3==")

            //Find the smallest value of genValue in rdd1
            System.out.println("map֮�е�genValueΪx.3==")
            System.out.println("strArrayVar=="+strArrayVar.size)

            var tempRdd=rdd1.map(x=>{
                var res = List[(Int, Double)]()
                for (item <- x._3){
                    res.::=(item._1,item._2)
                }
                (res)
            }).collect()//.foreach(print)*/
            //The outgoing population proposes the optimal individual
            val emigrants:RDD[(Int,Array[(Int,SiPDEPopulation)])]=rdd1.map(r=>{
                val emig=r.getEmigrants(migratingPopSize,emigrationMethod)
                emig.resetIndividualsPopulation();//Emig contains 15 individuals to migrate, and the 15 individuals are re-subscript,0-14
                (r._1,emig)//R._1: island number, emig: 15 migratory individuals
            })//val emigrants---�ˣ�
            //Replacing the worst individuals, the emigrants contain the island number and the 15 individuals to be replaced, the topology, which replaces the 15 worst individuals on other islands with 15 good ones
            val partitioner=new SiPDEPartitioner(emigrants,topology,islands,immigrationMethod)
            val rdd2=rdd1.map(r=>{
                (r._2,r._1)
            }).partitionBy(partitioner).cache()
            //The outgoing population is passed to the partition function
            oldRdd=rdd2.map(r=>{
                (r._2,r._1)
            })
            //System.out.print("rdd2.partitioner:"+rdd2.partitioner)
            StartTime=System.currentTimeMillis()
            var tempbestInd = findBestIndividual(oldRdd)
            tempvalue += (i+1)+" "+tempbestInd._2.getBestIndividual.getFitness
            EndTime=System.currentTimeMillis()
            tempvalue+= " "+(EndTime - StartTime)+" \n"

            System.out.println(tempvalue);


        }
        //Output the optimal value
        //bestInd = findBestIndividual(oldRdd)
        //tempvalue+=bestInd._2.getBestIndividual.getFitness
        Common.appendMethodB(path, tempvalue)
        printBestIndividual(bestInd)
        bestInd
    }*/

    def getRound: Int = {
        round
    }

    def setRound(nr: Int) {
        round = nr
    }

    def getGenValue(): JHashMap[Int, Double] ={
        genValue
    }

    /***
    count is the number of islands
    nAlgs is the type of algorithm
      **/
    def setRandomAlgAndParams(count:Int, nAlgs:Int) {
        var generator:Random = new Random();
        for (i <- 0 to count) {
            var r:Int = generator.nextInt(nAlgs)
            var names:String = ""
            //var alg  //Class[_ <:Algorithm]
            var F=0.0
            var CR=0.0
            var printArgs:String = "";
            r match {
                case 0=>
                    var alg = new GBCS
                    configAlg.put(i,alg)
                    F = generator.nextFloat()*2;
                    CR = generator.nextFloat();
                    val subpopParameters = new JHashMap[String, Double]();
                    subpopParameters.put("F", F)
                    subpopParameters.put("CR", CR)
                    configDouble.add(i,subpopParameters)
                case 1=>
                    var alg =new GBCS
                    configAlg.put(i,alg)
                    F = generator.nextFloat()*2;
                    CR = generator.nextFloat();
                    val subpopParameters = new JHashMap[String, Double]();
                    subpopParameters.put("F", F)
                    subpopParameters.put("CR", CR)
                    configDouble.add(i,subpopParameters)
                case 2=>
                    var alg =new GBCS
                    configAlg.put(i,alg)
                    F = generator.nextFloat()*2;
                    CR = generator.nextFloat();
                    val subpopParameters = new JHashMap[String, Double]();
                    subpopParameters.put("F", F)
                    subpopParameters.put("CR", CR)
                    configDouble.add(i,subpopParameters)
                case 3=>
                    var alg =new GBCS
                    configAlg.put(i,alg)
                    F = generator.nextFloat()*2;
                    CR = generator.nextFloat();
                    val subpopParameters = new JHashMap[String, Double]();
                    subpopParameters.put("F", F)
                    subpopParameters.put("CR", CR)
                    configDouble.add(i,subpopParameters)
                case 4=>
                    var alg =new GBCS
                    configAlg.put(i,alg)
                    F = generator.nextFloat()*2;
                    CR = generator.nextFloat();
                    val subpopParameters = new JHashMap[String, Double]();
                    subpopParameters.put("F", F)
                    subpopParameters.put("CR", CR)
                    configDouble.add(i,subpopParameters)
                case _=> println("error");
            }
            //System.out.println("---- " + "Algorithm " + i + ": " + alg);
            //System.out.println(printArgs);
            //  Set algorithm specific for this subpopulations
            //configAlg.put(i,alg)
            //  Set size of subpopulation
            configClass.put(i,defaultPopSize)
            //conf.setInt("popSize_" + i, defaultPopSize); //------?
        }
    }
    /***
    count is the number of islands
    nAlgs is the type of algorithm
      **/
    def setRandomAlgAndParams1(f: Function, D_ : Int, popSize_ : Int,count:Int, nAlgs:Int,generationsPerRound:Int) {
        var generator:Random = new Random();
        for (i <- 0 to count) {
            var r:Int = generator.nextInt(nAlgs)
            var names:String = ""
            var F=0.0
            var CR=0.0
            var printArgs:String = "";
            /*r match {
                case 0=>
                    var alg = new GBCS(f,D_,popSize_,generationsPerRound)
                    this.algorithm=alg
                case 1=>
                    var alg = new GBCS(f,D_,popSize_,generationsPerRound)
                    this.algorithm=alg
                case 2=>
                    var alg = new GBCS(f,D_,popSize_,generationsPerRound)
                    this.algorithm=alg
                case 3=>
                    var alg = new CUDE4(f,D_,popSize_,generationsPerRound)
                    this.algorithm=alg
                case 4=>
                    var alg = new CUDE5(f,D_,popSize_,generationsPerRound)
                    this.algorithm=alg
                case 5=>
                    var alg = new CUDE6(f,D_,popSize_,generationsPerRound)
                    this.algorithm=alg
            }*/
            //this.algorithm=alg
            //System.out.println("---- " + "Algorithm " + i + ": " + alg);
            //System.out.println(printArgs);
            //  Set algorithm specific for this subpopulations
            //configAlg.put(i,alg)
            //  Set size of subpopulation
            configClass.put(i,defaultPopSize)
            //conf.setInt("popSize_" + i, defaultPopSize); //------?
        }
    }

    /**
     * Sets algorithms according to their ratings...
     */
    def setRatedAlgorithms {
    }

    /**
     *
     * @param top Topology extending class defining the topology of islands (determines the destination island for migrating population)
     */
    def setTopology(top: Class[_ <: Topology]) {
        topology = top
    }
    def setRANDOM_ALGS_AND_PARAMS(RANDOM_ALGS_AND_PARAMS:Boolean): Unit ={
        this.RANDOM_ALGS_AND_PARAMS=RANDOM_ALGS_AND_PARAMS
    }

    /**
     * Determines how immigrating individuals are handled.
     *
     * @param met One of Population.acceptImmigrantsMethod (REPLACE_WORST, REPLACE_BEST, REPLACE_RANDOM, NO_REPLACE).
     */
    def setImmigrationMethod(met: SiPDEPopulation.acceptImmigrantsMethod) {
        immigrationMethod = met
    }

    /**
     * Determines how emigrating individuals are chosen.
     *
     * @param met One of Population.expelEmigrantsMethod (EXPEL_BEST, EXPEL_RANDOM).
     */
    def setEmigrationMethod(met: SiPDEPopulation.expelEmigrantsMethod) {
        emigrationMethod = met
    }

    /**
     * If verbose setting is set to true, all populations with all their individuals will be written to Logger
     *
     * @param verb true/false
     */
    def setVerbose(verb: Boolean) {
        VERBOSE = verb
    }
    /**
     *@param is the number of the island
     * @param alg Population specific algorith
     * @param subpopParameters Map collection of parameters for given algorithm
     */
    def addSubpopulationsConfig(index:Int,alg:Class[_ <: Algorithm], subpopParameters:JHashMap[String, Double]) {
        addSubpopulationsConfig(index,alg, defaultPopSize, subpopParameters);
    }
    //addSubpopulationsConfig :Class[_ <: Algorithm]
    def addSubpopulationsConfig(index:Int,alg: Class[_ <: Algorithm], popSize:Int, subpopParameters:JHashMap[String, Double]){
        //Store the data
        //Store parameters F and CR in the corresponding island
        configDouble.add(index,subpopParameters)
        //System.out.println("configDouble.get(0).apply(\"F\")"+configDouble.get(0).get("F"))
        //alg.newInstance().asInstanceOf[Algorithm]
        //Store optimizer
        //configClass.put("algorithm_"+index,alg.toString)
        //System.out.println("====="+alg)
        //index=0,alg.newInstance().asInstanceOf[Algorithm]=CUDE
        configAlg.put(index,alg.newInstance().asInstanceOf[Algorithm])
        //The population size
        configClass.put(index,popSize)

    }
}
/*
class MakeFoo[A](implicit manifest: Manifest[A]) {
    def make: A = manifest.erasure.newInstance.asInstanceOf[A]
}*/

