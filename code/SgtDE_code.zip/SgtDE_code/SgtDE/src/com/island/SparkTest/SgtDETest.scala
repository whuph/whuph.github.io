package com.island.SparkTest

import java.util
import javax.naming.ConfigurationException

import CEC2013._//cec2010._
import cer2003.{Common, FitnessFunctions}
import com.island.SparkStrategies
import com.island.SparkStrategies._
import org.apache.spark.{SparkContext, SparkConf}
import org.apache.spark.SparkContext._

import java.util.logging.Level;
import java.util.logging.Logger;
//rename
import java.util.{HashMap => JHashMap}
import scala.collection.mutable.HashMap
import scala.collection.immutable.HashMap
/**
 * Created by hadoop on 16-11-12.
 */
object SgtDETest {
  //var path: Unit = ???
  //var path = "/home/hadoop/sparkCUDEResult/resultCUDEisland2cec20100161201" //100 individuals
  //var path = "/home/hadoop/sparkCUDEResult/resultCUDEisland2cec20100161224"  //200 individuals 1-9
  //var path = "/home/spark/arr_hellospark/sparkCUDEResult/resultCUDEisland20171106_4"  //200 individuals 10-20
  var path = "/home/spark/island_result/GBCS_16_0.5pa"  //arr_part2_CUDE
  def main(args: Array[String]){
      //SparkDE.sc
      //The definition of the variable goes outside
      //Test the loop of the function
      //-------------variables-------------
      val nRepeatTest:Int = 1;//Number of runs 25
      val dimension:Int = 30;//dimension 1000
      val rounds:Int = 30;//Number of rounds 30
      val islandCount:Int = 15;//Number of island
      val generationsPerRound:Int = 1000;//Number of iterations per round 1000

      val arr_islandCount:Int = 3;//Number of groups.
    //defaulPopulationSize=20
      val defaultPopulationSize:Int = 300/islandCount;//Default individual for each island within each subgroup group
      val migratingIndividuals:Int = 15;//Individuals migrating between islands within each group
      var fun_num:Int = 0;//The objective function

      //Save the optimal value for each independent execution
      val win = new Array[Double](nRepeatTest)//new Double[nRepeatTest];

      //Start-stop time
      var StartTime: Long = 0
      var EndTime: Long = 0
      val T = new Array[Long](nRepeatTest);

      //Control switch
      val deleteHistory = true;
      val verbose = false;
      val writeHistory = true;
      val runFirstTest = true;
      //-------------variables-------------
      var deaf2: hzhDEDeaf=null
      //The population was rearranged according to the serial number of the column.But it doesn't change the population (grouping)
      val subscript =null
      //The function set
      /*var problemSet=Array(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20)
      var problem=Array(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19)*/
      var problemSet=Array(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28)
    var problem=Array(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27)
      //0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19
      for(x<-0 to problem.length-1){
        fun_num=fun_num+1;
        var f=problemSet(problem(x))
        //for(f<-1 to 20){//20
        //------------CER2003--- Test_APP-------------
        for(r <- 0 to nRepeatTest-1){
          f match {

            case 1=>
              val fitFunction=new Function(dimension,defaultPopulationSize,fun_num) //new FitnessFunctions.CER2003_F1(dimension)
            //val derand1bin=new DERand1bin(fitFunction10,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 2=>
              //val fitFunction= new FitnessFunctions.CER2003_F2(dimension)
              val fitFunction=new Function(dimension,defaultPopulationSize,fun_num)
              //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
              val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 3=>
              val fitFunction= new Function(dimension,defaultPopulationSize,fun_num)//new FitnessFunctions.CER2003_F3(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 4=>
              val fitFunction= new Function(dimension,defaultPopulationSize,fun_num)//new FitnessFunctions.CER2003_F4(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 5=>
              val fitFunction= new Function(dimension,defaultPopulationSize,fun_num)//new FitnessFunctions.CER2003_F5(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 6=>
              val fitFunction= new Function(dimension,defaultPopulationSize,fun_num)//new FitnessFunctions.CER2003_F6(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 7=>
              val fitFunction= new Function(dimension,defaultPopulationSize,fun_num)//new FitnessFunctions.CER2003_F7(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 8=>
              val fitFunction= new Function(dimension,defaultPopulationSize,fun_num)//new FitnessFunctions.CER2003_F8(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 9=>
              val fitFunction= new Function(dimension,defaultPopulationSize,fun_num)//new FitnessFunctions.CER2003_F9(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 10=>
              val fitFunction= new Function(dimension,defaultPopulationSize,fun_num)//new FitnessFunctions.CER2003_F10(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 11=>
              val fitFunction= new Function(dimension,defaultPopulationSize,fun_num)//new FitnessFunctions.CER2003_F11(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 12=>
              val fitFunction= new Function(dimension,defaultPopulationSize,fun_num)//new FitnessFunctions.CER2003_F12(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 13=>
              val fitFunction=new Function(dimension,defaultPopulationSize,fun_num)// new FitnessFunctions.CER2003_F13(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 14=>
              val fitFunction=new Function(dimension,defaultPopulationSize,fun_num)// new FitnessFunctions.CER2003_F13(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 15=>
              val fitFunction=new Function(dimension,defaultPopulationSize,fun_num)// new FitnessFunctions.CER2003_F13(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 16=>
              val fitFunction=new Function(dimension,defaultPopulationSize,fun_num)// new FitnessFunctions.CER2003_F13(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 17=>
              val fitFunction=new Function(dimension,defaultPopulationSize,fun_num)// new FitnessFunctions.CER2003_F13(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 18=>
              val fitFunction=new Function(dimension,defaultPopulationSize,fun_num)// new FitnessFunctions.CER2003_F13(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 19=>
              val fitFunction=new Function(dimension,defaultPopulationSize,fun_num)// new FitnessFunctions.CER2003_F13(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 20=>
              val fitFunction=new Function(dimension,defaultPopulationSize,fun_num)// new FitnessFunctions.CER2003_F13(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 21=>
              val fitFunction=new Function(dimension,defaultPopulationSize,fun_num)// new FitnessFunctions.CER2003_F13(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 22=>
              val fitFunction=new Function(dimension,defaultPopulationSize,fun_num)// new FitnessFunctions.CER2003_F13(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 23=>
              val fitFunction=new Function(dimension,defaultPopulationSize,fun_num)// new FitnessFunctions.CER2003_F13(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 24=>
              val fitFunction=new Function(dimension,defaultPopulationSize,fun_num)// new FitnessFunctions.CER2003_F13(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 25=>
              val fitFunction=new Function(dimension,defaultPopulationSize,fun_num)// new FitnessFunctions.CER2003_F13(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 26=>
              val fitFunction=new Function(dimension,defaultPopulationSize,fun_num)// new FitnessFunctions.CER2003_F13(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 27=>
              val fitFunction=new Function(dimension,defaultPopulationSize,fun_num)// new FitnessFunctions.CER2003_F13(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)
            case 28=>
              val fitFunction=new Function(dimension,defaultPopulationSize,fun_num)// new FitnessFunctions.CER2003_F13(dimension)
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new GDCS(fitFunction,dimension,defaultPopulationSize)
              deaf2 = new hzhDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals,fun_num)

            case default=>deaf2=null;System.out.println("no fitnessfunctions\n");System.exit(0);

          }
          val Fs=new Array[Double](islandCount)
          val CRs=new Array[Double](islandCount)
          for (t <- 0 to islandCount-1) { //algorithm parameters
            Fs.update(t,0.5)
            CRs.update(t,0.9)
          }
            //Each island is based on different F, CR and optimization operators
          for(j <-0 to arr_islandCount-1){
            for (i <- 0 to islandCount-1) { //set parameters to algorithms
              val subpopParameters = new JHashMap[String, Double]();
              subpopParameters.put("F", Fs.apply(i))
              subpopParameters.put("CR", CRs.apply(i))
              
              if(j==0){
                deaf2.addSubpopulationsConfig(i,classOf[GBCS], subpopParameters); //classOf[
              }else if(j==1){
                deaf2.addSubpopulationsConfig(i,classOf[GBCS], subpopParameters); //classOf[
              }else if(j==2){
                deaf2.addSubpopulationsConfig(i,classOf[GBCS], subpopParameters); //classOf[
              }
            }
          }

          //Sets whether to use a different optimizer
          deaf2.setRANDOM_ALGS_AND_PARAMS(false) //false

          deaf2.setVerbose(verbose);
          //deaf.setDeleteHistory(deleteHistory);
          //Sets its topology result
          deaf2.setTopology(classOf[Topologies.Ring_1_2]);
          //Set the replacement policy.
          deaf2.setImmigrationMethod(SiPDEPopulation.acceptImmigrantsMethod.REPLACE_WORST);
          deaf2.setEmigrationMethod(SiPDEPopulation.expelEmigrantsMethod.EXPEL_BEST);
          //deaf.useRandomAlgsAndParams(true);//Whether to use all existing algorithms randomly
          try {
            System.out.println("********************* Test " + r + " *********************")
            StartTime=System.currentTimeMillis()
            //Population evolution
            var winner = deaf2.run(rdd,rounds,arr_islandCount);
            //rdd.collect()
            //deaf.setRound(3)
            EndTime=System.currentTimeMillis()
            //T[r] = EndTime - StartTime; //ms
            T.update(r,EndTime - StartTime)
            //Gets the values for each generation
            //val genValue: JHashMap[Int, Double]= winner._2//deaf.getGenValue()


            System.out.println("Runtime=="+T.apply(r))
            System.out.println("And the winner is : \n" +winner._2)
            System.out.println("And the winner is : \n" +winner._1(2)._2.getBestIndividual.getFitness)
            val tempvalue="Runtime=="+T.apply(r)+"And the winner is : " +winner._1+"And the winner is : " +winner._1(2)._2.getBestIndividual.getFitness+"\n"
            Common.appendMethodB(path, tempvalue)
            //win[r] = winner.getFitness();
            //System.out.println("And the winner is : \n" + winner);
            //System.out.println("And the winner is : \n" + winner.getFitness());

          } catch {
            case ex:ConfigurationException =>{
              Logger.getLogger(SiPDETest.getClass.getName()).log(Level.SEVERE, null, ex);
            }
            //Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
          }
        }
      }
    }
    def getPath(): String ={
      return this.path

    }
}
object SparkDECC {
  val sparkConf = new SparkConf()
    .setAppName("SparkDECCTest")
    .setMaster("local")
    //.setMaster("spark://cloud-hadoop-004:7077")
    //.set("spark.executor.memory","2g")
    //sparkConf.setExecutorEnv("spark.akka.frameSize","1000000")
    val sc = new SparkContext(sparkConf)
    //val conf = new SparkConf().setMaster("local").setAppName("TaskNotSerializationTest")
    //val ctx = new SparkContext(conf)
}
