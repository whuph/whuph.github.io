﻿package com.island.SparkTest

import java.util
import javax.naming.ConfigurationException
import java.lang.String
import cec2010._
import cer2003.{Common, FitnessFunctions}
import com.island.SparkStrategies
import com.island.SparkStrategies._
import org.apache.spark.{SparkContext, SparkConf}
import org.apache.spark.SparkContext._

import java.util.logging.Level;
import java.util.logging.Logger;
//rename
import java.util.{HashMap => JHashMap}
import scala.collection.mutable.HashMap
import scala.collection.immutable.HashMap
/**
  * Created by hadoop on 16-11-12.
  */
object SiPDETest {
  //var path: Unit = ???
  //var path = "/home/hadoop/sparkCUDEResult/resultCUDEisland2cec20100161201" //100 individuals
  //var path = "/home/hadoop/sparkCUDEResult/resultCUDEisland2cec20100161224"  //200个体1-9
  var path = "/home/spark/hellospark/sparkCUDEResult/resultCUDEisland20171106_1"  //200 individuals  def main(args: Array[String]) {

    //Command execution parameter
    //  /home/hadoop/spark/spark-2.1.0-bin-hadoop2.7/bin/spark-submit
    //  --master spark://cloud-hadoop-008:7077
    //  --executor-memory 2g
    //  --class com.island.SparkTest.SiPDETest
    //  /home/hadoop/workspace/hellospark/out/artifacts/hellospark.jar
    //  np=100 dim=1000 f=0.5 cr=0.9 rep=1 fx=1
    var Np:Int=100; //Population number
    var Dim:Int=1000; //dimension
    var F:Double=0.5;  //F
    var CR:Double=0.9; //CR
    var Rep:Int=5; //Number of repeated runs
    var Fx:Int=1;
    var args_str:String="";

    for(i<-0 to args.length-1){
      //println(args(i));
      args_str=args(i);
      args_str.substring(0,args_str.indexOf("=")) match {
        case "np"=>
          Np=args_str.substring(args_str.indexOf("=")+1).toInt
        //println(Np)
        case "dim" =>
          Dim=args_str.substring(args_str.indexOf("=")+1).toInt
        //println(Dim)
        case "f"=>
          F=args_str.substring(args_str.indexOf("=")+1).toFloat
        //println(F)
        case "cr" =>
          CR=args_str.substring(args_str.indexOf("=")+1).toFloat
        //println(CR)
        case "rep"=>
          Rep=args_str.substring(args_str.indexOf("=")+1).toInt
        //println(Rep)
        case "fx"=>
          Fx=args_str.substring(args_str.indexOf("=")+1).toInt
        case default =>
          ;
      }
    }

    //SparkDE.sc
    //The definition of the variable goes outside
    //Test the loop of the function
    //-------------variables-------------
    //val nRepeatTest:Int = 1;//The number of runs is 25    val nRepeatTest:Int = Rep;//The number of runs is 25    //val dimension:Int = 1000;//dimension 1000
    val dimension:Int=Dim;

    val rounds:Int = 2;//Round number 30
    val islandCount:Int = 5;//Number of island
    val generationsPerRound:Int = 990;//The number of iterations per round 940 970
    /*
    FES=3000*D
    D=1000   On November 26
    gen=940 rounds=30
    D=100   11月29日
    gen=94 rounds=30
    D=5000 On December 1
    gen=4716 rounds=30
     */

    //val defaultPopulationSize:Int = 100/islandCount;//Default individual 100 200 500
    val defaultPopulationSize:Int = Np/islandCount;
    val migratingIndividuals:Int = 15;//Migrating individual 100*15%;200*15%;500*15%

    //Saves the optimal value for each individual execution
    val win = new Array[Double](nRepeatTest)//new Double[nRepeatTest];

    //起止时间
    var StartTime: Long = 0
    var EndTime: Long = 0
    val T = new Array[Long](nRepeatTest);

    //Control switch
    val deleteHistory = true;
    val verbose = false;
    val writeHistory = true;
    val runFirstTest = true;
    //-------------variables-------------
    //SiPDEDeaf deaf
    var deaf: txjDEDeaf=null;

    //The function set

        var problemSet=Array(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20)
    var problem=Array(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19)
    /*-------*/


        //val problemSet=Array(Fx);
    //val problem=Array(0);
    /*---------------*/


    for(x<-0 to problem.length-1){
      val f=problemSet(problem(x))
      //for(f<-1 to 20){//20
      //------------CER2003--- Test_APP-------------
      //val fitFunction=null
      //val derand1bin=null
      //val fitFunction=null


      for(r <- 0 to nRepeatTest){
        //val fitFunction=null
        f match {
          /*case 1=>
            //println(f)
            val fitFunction=new F1() //new FitnessFunctions.CER2003_F1(dimension)
          //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            //
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            //
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 2=>
            //val fitFunction= new FitnessFunctions.CER2003_F2(dimension)
            val fitFunction=new F2()
            //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
            val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 3=>
            val fitFunction= new F3()//new FitnessFunctions.CER2003_F3(dimension)
          //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 4=>
            val fitFunction= new F4()//new FitnessFunctions.CER2003_F4(dimension)
          //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 5=>
            val fitFunction= new F5()//new FitnessFunctions.CER2003_F5(dimension)
          //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 6=>
            val fitFunction= new F6()//new FitnessFunctions.CER2003_F6(dimension)
          //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 7=>
            val fitFunction= new F7()//new FitnessFunctions.CER2003_F7(dimension)
          //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 8=>
            val fitFunction= new F8()//new FitnessFunctions.CER2003_F8(dimension)
          //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 9=>
            val fitFunction= new F9()//new FitnessFunctions.CER2003_F9(dimension)
          // val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 10=>
            val fitFunction= new F10()//new FitnessFunctions.CER2003_F10(dimension)
          //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 11=>
            val fitFunction= new F11()//new FitnessFunctions.CER2003_F11(dimension)
          //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 12=>
            val fitFunction= new F12()//new FitnessFunctions.CER2003_F12(dimension)
          //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 13=>
            val fitFunction=new F13()// new FitnessFunctions.CER2003_F13(dimension)
          //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 14=>
            val fitFunction=new F14()// new FitnessFunctions.CER2003_F13(dimension)
          //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 15=>
            val fitFunction=new F15()// new FitnessFunctions.CER2003_F13(dimension)
          //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 16=>
            val fitFunction=new F16()// new FitnessFunctions.CER2003_F13(dimension)
          //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 17=>
            val fitFunction=new F17()// new FitnessFunctions.CER2003_F13(dimension)
          //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 18=>
            val fitFunction=new F18()// new FitnessFunctions.CER2003_F13(dimension,generationsPerRound)
          //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 19=>
            val fitFunction=new F19()// new FitnessFunctions.CER2003_F13(dimension)
          //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 20=>
            val fitFunction=new F20()// new FitnessFunctions.CER2003_F13(dimension)
          //val derand1bin=new DERand1bin(fitFunction,dimension,defaultPopulationSize)
          val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize,generationsPerRound)
            deaf = new txjDEDeaf(path,fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)*/

          /*
          case 1=>deaf = new txjDEDeaf(new FitnessFunctions.CER2003_F1(dimension), dimension, classOf[DERand1bin], generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)
          case 2=>deaf = new txjDEDeaf(new FitnessFunctions.CER2003_F2(dimension), dimension, classOf[DERand1bin], generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals);
          case 3=>deaf = new txjDEDeaf(new FitnessFunctions.CER2003_F3(dimension), dimension, classOf[DERand1bin], generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals);
          case 4=>deaf = new txjDEDeaf(new FitnessFunctions.CER2003_F4(dimension), dimension, classOf[DERand1bin], generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals);
          case 5=>deaf = new txjDEDeaf(new FitnessFunctions.CER2003_F5(dimension), dimension, classOf[DERand1bin], generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals);
          case 6=>deaf = new txjDEDeaf(new FitnessFunctions.CER2003_F6(dimension), dimension, classOf[DERand1bin], generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals);
          case 7=>deaf = new txjDEDeaf(new FitnessFunctions.CER2003_F7(dimension), dimension, classOf[DERand1bin], generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals);
          case 8=>deaf = new txjDEDeaf(new FitnessFunctions.CER2003_F8(dimension), dimension, classOf[DERand1bin], generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals);
          case 9=>deaf = new txjDEDeaf(new FitnessFunctions.CER2003_F9(dimension), dimension, classOf[DERand1bin], generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals);
          case 10=>deaf = new txjDEDeaf(new FitnessFunctions.CER2003_F10(dimension), dimension, classOf[DERand1bin], generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals);
          case 11=>deaf = new txjDEDeaf(new FitnessFunctions.CER2003_F11(dimension), dimension, classOf[DERand1bin], generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals);
          case 12=>deaf = new txjDEDeaf(new FitnessFunctions.CER2003_F12(dimension), dimension, classOf[DERand1bin], generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals);
          case 13=>deaf = new txjDEDeaf(new FitnessFunctions.CER2003_F13(dimension), dimension, classOf[DERand1bin], generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals);
          */
          case default=>deaf=null;System.out.println("no fitnessfunctions\n");System.exit(0);
        }
        // val derand1bin= new CUDE(fitFunction,dimension,defaultPopulationSize)
        //deaf = new txjDEDeaf(fitFunction, dimension,derand1bin , generationsPerRound, islandCount, defaultPopulationSize, migratingIndividuals)

        //double Fs[] = new double[islandCount];
        //double CRs[] = new double[islandCount];
        val Fs=new Array[Double](islandCount)
        val CRs=new Array[Double](islandCount)

        for (t <- 0 to islandCount-1) { //algorithm parameters
          //Fs.update(t,0.5)
          //CRs.update(t,0.9)
          Fs.update(t,F)
          CRs.update(t,CR)
        }
        //Each island is optimized according to a different F, CR, and operator
        for (i <- 0 to islandCount-1) { //set parameters to algorithms
          //Map<String, Double> subpopParameters = new HashMap<String, Double>();
          //new HashMap[String, Int]
          val subpopParameters = new JHashMap[String, Double]();
          //subpopParameters.
          subpopParameters.put("F", Fs.apply(i))
          subpopParameters.put("CR", CRs.apply(i))
          //System.out.println("subpopParameters=="+subpopParameters.get("F"))
          //subpopParameters.apply("F")
          //deaf.addSubpopulationsConfig(i,classOf[DERand1bin], subpopParameters);
        }
        //Sets whether to use a different optimizer
        deaf.setRANDOM_ALGS_AND_PARAMS(false);

        deaf.setVerbose(verbose);
        //deaf.setDeleteHistory(deleteHistory);
        //Sets its topology results
        deaf.setTopology(classOf[Topologies.Ring_1_2]);
        //Set the replacement policy
        deaf.setImmigrationMethod(SiPDEPopulation.acceptImmigrantsMethod.REPLACE_WORST);

        deaf.setEmigrationMethod(SiPDEPopulation.expelEmigrantsMethod.EXPEL_BEST);

        //deaf.useRandomAlgsAndParams(true);//Whether to randomly use all existing algorithms

        try {
          System.out.println("********************* Test " + r + " *********************")
          StartTime=System.currentTimeMillis()
          //Initial population
          var rdd= deaf.createRandomPopulation(SparkDE.sc)
          //Population evolution
          //var winner:(Int, SiPDEPopulation) = deaf.run(rdd,rounds);

          //deaf.setRound(3)
          EndTime=System.currentTimeMillis()
          //T[r] = EndTime - StartTime; //ms
          T.update(0,EndTime - StartTime)//r-->0
          //Gets the values for each generation
          //val genValue: JHashMap[Int, Double]= winner._2//deaf.getGenValue()


//          System.out.println("Running time=="+T.apply(0))//r-->0
//          System.out.println("And the winner is : \n" +winner._1)
//          System.out.println("And the winner is : \n" +winner._2.getBestIndividual.getFitness)
//          val tempvalue="Running time=="+T.apply(0)+"And the winner is : " +winner._1+"And the winner is : " +winner._2.getBestIndividual.getFitness+"\n"//r-->0
//          Common.appendMethodB(path, tempvalue)
          //win[r] = winner.getFitness();
          //System.out.println("And the winner is : \n" + winner);
          //System.out.println("And the winner is : \n" + winner.getFitness());

        } catch {
          case ex:ConfigurationException =>{
            Logger.getLogger(SiPDETest.getClass.getName()).log(Level.SEVERE, null, ex);
          }
          //Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
      }

      //------------Record file------------
      /*JobConf conf = new JobConf(new Configuration(), Main.class);
      FileSystem fs = FileSystem.get(conf);
      Path p = new Path("/user/deaf/history/CER2003_F"+f+"_DERand1bin.txt");
      FSDataOutputStream out = fs.create(p);
      */
      //------------Record file------------

      //***********Take the average, the minimum, the maximum, the variance*************//
      /*double ave=0;
      double sum=0;
      double min=0;
      double max=0;
      double va=0;
      long tn =0;
      max=win[0];min=win[0];


      for (int j=0;j<nRepeatTest;j++){
        System.out.println("nRepeatTest_"+j+" best:"+win[j]+"\r");
        System.out.println("nRepeatTest_"+j+" Time:"+T[j]+"\r");
        out.writeUTF("\nnRepeatTest_"+j+" best:"+win[j]);
        out.writeUTF("\nnRepeatTest_" + j + " Time: " + T[j] + "\r");
        sum+=win[j];
        tn+=T[j];
        if(Math.abs(win[j])>max)max=win[j];
        if(Math.abs(win[j])<min)min=win[j];
      }
      ave=sum/nRepeatTest;
      sum=0;
      for (int j=0;j<nRepeatTest;j++){
        sum=sum+(win[j]-ave)*(win[j]-ave);
      }
      va=Math.sqrt(sum/nRepeatTest);
      out.writeUTF("\nBest:"+min);
      out.writeUTF("\nWrost:"+max);
      out.writeUTF("\nMean:"+ave);
      out.writeUTF("\nStd:"+va);
      out.writeUTF("\ntnAve:" + tn/nRepeatTest);
      out.close();
      //System.out.println("Average="+ave+"\nMax="+max+"\nMin="+min+"\nVariance="+va);
      System.out.println("-------------end-----------");
      */
    }
  }
  def getPath(): String ={
    return this.path

  }
}
object SparkDE {
  val sparkConf = new SparkConf()
    .setAppName("SparkDECC")
    //.setMaster("local")
    .set("spark.executor.memory","2g")
  //sparkConf.setExecutorEnv("spark.akka.frameSize","1000000")
  val sc = new SparkContext(sparkConf)
  //val conf = new SparkConf().setMaster("local").setAppName("TaskNotSerializationTest")
  //val ctx = new SparkContext(conf)
}