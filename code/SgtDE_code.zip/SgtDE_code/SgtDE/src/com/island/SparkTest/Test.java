﻿package com.island.SparkTest;

import cec2010.F1;
import cec2010.Function;
import com.island.SparkStrategies.SiPDEIndividuals;
import com.island.SparkStrategies.SiPDEPopulation;
import com.island.strategies.JADEPopulation;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by hadoop on 17-7-23.
 */
public class Test {
    public static void main(String[] args)throws Exception{
        int popSize=5;
        int dimensions=1000;
        SiPDEPopulation population  = new SiPDEPopulation();
        population.clear();
        Function fInstance=new F1();
        //population.setFitnessFunction(fInstance);//Set the function；
        population.addRandomIndividuals(popSize, dimensions);
        System.out.println("population");
        for(int i=0;i<population.size();i++){
            for(int j=0;j<10;j++){
                System.out.print(population.get(i).getGene(j)+" ");
            }
            System.out.println();
        }
        ArrayList<Integer> list= new ArrayList<Integer>();
        list.add(1);
        list.add(3);
        list.add(5);
        list.add(7);
        list.add(9);

        System.out.println("sub population");
        HashMap<Integer, RealVector> sub= population.getPopulation(list);

        for(int i=0;i<sub.size();i++){
            for(int j=0;j<sub.get(i).getDimension();j++){
                System.out.print(sub.get(i).getEntry(j)+" ");
                //population.get(list.get(i)).setGene(j,0);
                sub.get(i).setEntry(j,0);
            }
            System.out.println();

        }

        population.setPopulation(sub,list);
        System.out.println("Population after replacement");
        for(int i=0;i<population.size();i++){
            for(int j=0;j<10;j++){
                System.out.print(population.get(i).getGene(j)+" ");
            }
            System.out.println();
        }

        System.out.println("sub");
        //RealVector tracerst=new ArrayRealVector(2);
        ArrayList tracerst=new ArrayList();
        tracerst.add(12);
        tracerst.add(23);
        tracerst.add(12);
        for(int i=0;i<tracerst.size();i++){
            System.out.println(tracerst.get(i));
        }
    }
}
