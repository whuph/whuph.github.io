package com.island;
import java.util.*;
/**
 * Created by hadoop on 15-7-4.
 */
public class sort {
   
    public static void sortIntArray(int[][] arObjects,final int[] arOrders)
    {
        Arrays.sort(arObjects, new Comparator<Object>()
        {
            public int compare(Object oObjectA, Object oObjectB)
            {
                int[] arTempOne = (int[])oObjectA;
                int[] arTempTwo = (int[])oObjectB;
                for (int i = 0; i < arOrders.length; i++)
                {
                    int k = arOrders[i];
                    if (arTempOne[k] > arTempTwo[k])
                    {
                        return 1;
                    }
                    else if (arTempOne[k] < arTempTwo[k])
                    {
                        return -1;
                    }
                    else
                    {
                        continue;
                    }
                }
                return 0;
            }
        });
    }
    public static void sortDoubleArray(double[][] arObjects,final int arOrders)
    {
        Arrays.sort(arObjects, new Comparator<Object>()
        {
            public int compare(Object oObjectA, Object oObjectB)
            {
                double[] arTempOne = (double[])oObjectA;
                double[] arTempTwo = (double[])oObjectB;
                //for (int i = 0; i < arOrders.length; i++)
                {
                    int k = arOrders;
                    if (arTempOne[k] > arTempTwo[k])
                    {
                        return 1;
                    }
                    else if (arTempOne[k] < arTempTwo[k])
                    {
                        return -1;
                    }
                    else
                    {
                       // continue;
                    }
                }
                return 0;
            }
        });
    }
}
