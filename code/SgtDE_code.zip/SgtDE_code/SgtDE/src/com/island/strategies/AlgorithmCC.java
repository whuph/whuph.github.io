﻿package com.island.strategies;

import cec2010.Function;

import org.apache.commons.math3.linear.RealVector;
import scala.Serializable;

import java.io.IOException;
import java.util.List;

/**
 * @author txj
 */
public abstract class AlgorithmCC implements Serializable {
    protected int generationsPerRound;//Each round of evolutionary algebra
    /**
     * Minimal population size for algorithm to work
     
    protected int minPopulationSize;
    /**
     * Number of dimensions of given fitness function
     * 
     */
    protected int dimensions;
    /**
     * Population size
     * 
     */
    protected int popSize;
    /**
     * Optimized function


    ///cec2010
    protected Function function;
    public int functiondimension;
    /**
     * Inidivual with the best fitness, returned by generation()
    protected RealVector bestIndividual;
    /**
     * Population of Individuals for use in algorithm
     * 
     */

    protected populationCC population;
    /**
     * Fitness of bestIndividual
    protected double bestFitness = Double.MAX_VALUE;

    /**
     * Constructor
    public AlgorithmCC() {
        population = new populationCC();
    }

    /**
     * Runs one generation/cycle of algorithm
     * @return Best Individual from the population
     * @throws IOException
     */
    abstract public RealVector generation() throws IOException;

    abstract public RealVector generation(int ind) throws IOException;
    //,RealVector trialFit
    abstract public RealVector generationCC(RealVector bestind,int l,int u,int[] subscript) throws IOException;
    abstract public RealVector generationCC(RealVector bestind,  List<Integer> subscript) throws IOException;
    /**
     * 
     * @return population used in algorithm
     */
    abstract public populationCC getPopulation();

    /**
     * 
     * Sets main population to given Population
     * @param population_
     */
    public void setPopulation(populationCC population_,int generationsPerRound) {
        population = population_;
        popSize = population.size();
        this.generationsPerRound=generationsPerRound;
    }

    /**
          * newRound() is called at the end of each round (after emigration)
     * and can be used to alter algorithm configuration or left blank
     * if no alteration is not needed.
     */
    abstract public void newRound();

    /**
     ** Sets externally defined algorithm specific parameters.
     * @param configName Name of the parameter to set
     * @param value Value of parameter
     */
    abstract public void setParameter(String configName, float value);
}