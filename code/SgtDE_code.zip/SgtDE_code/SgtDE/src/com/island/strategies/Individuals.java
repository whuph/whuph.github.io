﻿package com.island.strategies;

import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;

import java.io.IOException;

/**
 * Created by hadoop on 15-7-8.
 * vector */
public class Individuals {

    //protected double[] genotype;

    protected RealVector geno;//individual    protected double fitness = Double.POSITIVE_INFINITY;
    protected boolean evaluated = false;
    protected static Population population;
    protected int index = Integer.MAX_VALUE;
    protected int dimensions;

    //Individual vectorget and set public RealVector getGeno() {
        return geno;
    }

    public void setGeno(RealVector geno) {
        this.geno = geno;
    }

    /**
     *
     * @param pop Population in which Individual will be inserted into
     * @param d Number of dimensions
     */
    public Individuals(Population pop, int d) {
        double min = 0, max = 0;
        dimensions = d;
        //genotype = new double[dimensions];//
        //Initialization vector
        geno = new ArrayRealVector(dimensions);
        population = pop;
        evaluated = false;
    }

    /**
     *
     * @param pop Population in which Individual will be inserted into
     * @param vals Array of values used as genes
     */
    /*public Individuals(Population pop, double[] vals) {
        population = pop;
        genotype = vals;
        dimensions = vals.length;
        evaluated = false;
    }*/
    /**
     *
     * @param pop Population in which Individual will be inserted into
     * @param vals Array of values used as genes
     */
    public Individuals(Population pop, RealVector vals) {
        population = pop;
        geno = vals;
        dimensions = vals.getDimension();
        evaluated = false;
    }

    /**
     *
     * @param pop Population in which Individual will be inserted into
     * @throws IOException
     */
    public Individuals(Population pop) throws IOException {
        population = pop;
    }


    /**
     * Sets genes to random values within restrictions
     */
    public void randomize() {
        double min, max;
        for (int i = 0; i < dimensions; i++) {
            min = population.getMinRestriction(i);
            max = population.getMaxRestriction(i);
            //  Get random double within range.
            //genotype[i] = min + (Math.random() * ((max - min) + 1));
            /////
            geno.setEntry(i,min + (Math.random() * (max - min)));
        }
        evaluated = false;
    }

    /**
     *
     * @return genotype array
     */
    /*public double[] getGenotype() {
        return genotype;
    }*/

    /**
     *
     * @return genotype array
     */
    public RealVector getGenoVect() {
        return geno;
    }

    /**
     * Modify
     * @param i index of requested gene
     * @return gene with given index
     */
    public double getGene(int i) {
        return geno.getEntry(i);
    }
    /**
     *
     * @param i index of requested gene
     * @return gene with given index
     */
    public double getGeneVect(int i) {
        return geno.getEntry(i);
    }

    /**
     * Sets one gene to defined value val
     * @param ind Index of gene to set
     * @param val Value to set to the gene
     */
    public void setGene(int ind, double val) {
        geno.setEntry(ind,val);
        evaluated = false;
    }



    /**
     * Sets Individuals fitness to given value f
     * @param f Value to set
     */
    public void setFitness(double f) {
        fitness = f;
        evaluated = true;
    }

    /**
     *
     * @return fitness of Individual
     */
    public double getFitness() {
        return fitness;
    }

    /**
     *
     * @return population index
     */
    public int getIndex() {
        return index;
    }

    /**
     * Sets population index to value i
     * @param i Index to set
     */
    public void setIndex(int i) {
        index = i;
    }

    @Override
    public String toString() {
        String str = "";

        str += fitness + "\t";

        for (int i = 0; i < dimensions; i++) {
            //str += String.format("%.6f", genotype[i]);
            str += String.format("%.6f", geno.getEntry(i));
            if (i != dimensions - 1) {
                str += '\t';
            }
        }

        return str;
    }

    /**
     * Sets whole genotype?
     * @param values
     */
    /*public void setValues(double[] values) {
        genotype = values;
        evaluated = false;
    }*/

    /**
     * Sets whole genotype
     * @param values
     */
    public void setValues(RealVector values) {
        geno = values;
        evaluated = false;
    }

    /**
     * Sets value of one gene
     * @param i Index of gene to set
     * @param value Value to set
     */
    public void setValue(int i, double value) {
        //genotype[i] =  value;
        geno.setEntry(i,value);
        evaluated = false;
    }


    /**
     * Sets population pointer to pop
     * @param pop Population to set
     */
    public void setPopulation(Population pop) {
        population = pop;
    }


    public int compareTo(Individual o) {
        double cost1 = fitness;
        double cost2 = o.getFitness();

        return (cost1 < cost2 ? -1 : (cost1 == cost2 ? 0 : 1));
    }
}
