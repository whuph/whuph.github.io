package com.island.strategies;

import cec2010.Function;
import cer2003.FitnessFunction;
import com.island.sort;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;


import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealMatrix;

import org.apache.commons.math3.linear.RealVector;
import scala.Int;
import scala.Serializable;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Random;

/**
 * Created by hadoop on 15-7-8.
 * Population * matrix
 */
public class populationRM   implements Serializable {
    //Transient indicates that FitnessFunction does not need or cannot be serialized
    protected FitnessFunction function;//Fitness function
    protected int dimensions;//The dimension
    protected int number;//Population number
    protected RealMatrix pop=new Array2DRowRealMatrix();//population
    protected boolean sorted = false;//Whether the sorting    protected boolean migrationFlag;//Whether the migration
    protected  Algorithm algorithm;//Evolutionary algorithm
    protected int key; //The serial number of the island
    Random rng;
    protected Individuals bestIndividual = null;
    protected ArrayRealVector trialFit;//Fitness value of the individual

    protected Function fun;//cec2010

    //The optimal value and index of fitness
    /*protected int index = Integer.MAX_VALUE;
    protected double fitness = Double.POSITIVE_INFINITY;
    protected boolean evaluated = false;*/

    //methods
    protected double[] Fs; //F for every individual
    protected double[] CRs; //CR for every individual

    double p; //percento najlepsich pre krizenie
    int numP; //pocet najlepsich pre krizenie, vychadza z hodnoty p
    double uF, uCR, c;
    /**
     * Constructs Population with given Individuals
     *
     * @param population ArrayList of Individuals who will become the new Population
     */
    public populationRM(RealMatrix population) {
        pop = population;
        migrationFlag = false;
        dimensions=population.getColumnDimension();
        number=population.getRowDimension();
        initializeConstants();
    }
    /**
     *  Parameterless constructor
     */
    public populationRM() {
        migrationFlag = false;
        initializeConstants();//

    }
    //Dimensions, number of individuals
    public populationRM(int num,int dim) {
        migrationFlag = false;
        dimensions=dim;
        number=num;
        initializeConstants();//
        pop=new Array2DRowRealMatrix(num,dim+1);
        trialFit=new ArrayRealVector(num);//Initialize variables;The number is num;Fitness value of the individual
        //System.out.println("The initial fitness value"+trialFit.getDimension());
    }

    void initializeConstants() {
        uCR = 0.5;
        uF = 0.6;
        c = 0.1;
        p = 0.2; //20%
        numP = (int) Math.round(((double)pop.getRowDimension()) * p);
        rng = new Random(System.currentTimeMillis());
    }

    public int getDimensions() {
        return dimensions;
    }

    public void setDimensions(int dimensions) {
        this.dimensions = dimensions;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public ArrayRealVector getTrialFit() {
        return trialFit;
    }

    public void setTrialFit(ArrayRealVector trialFit) {
        this.trialFit = trialFit;
    }

    /**
     *
     * @param i Dimension from which the restriction is returned
     * @return lower restriction of given dimension
     */
    public double getMinRestriction(int i) {
        return function.getMinRestriction(i);
    }

    /**
     *
     * @param i Dimension from which the restriction is returned
     * @return upper restriction of given dimension
     */
    public double getMaxRestriction(int i) {
        return function.getMaxRestriction(i);
    }

    /**
     *
     * @return ArrayList of Individuals from Population
     */
    public RealMatrix getPop() {
        return pop;
    }

    public void setPop(RealMatrix pop) {
        this.pop = pop;
    }

    public Algorithm getAlgorithm() {
        return algorithm;
    }

    public void setAlgorithm(Algorithm algorithm) {
        this.algorithm = algorithm;
    }

    /**
     * Sets fitness function of this Population which is later used to create Individuals and determine their fitness
     * @param ff FitnessFunction extending class
     */
    public void setFitnessFunction(FitnessFunction ff) {
        function = ff;
    }

    public FitnessFunction getFitnessFunction() {
        return function;
    }

    public Function getFun() {
        return fun;
    }

    public void setFun(Function fun) {
        this.fun = fun;
    }

    /**
     * Migrating flag marks if the population is used for evolution or for migration
     */
    public void setMigratingFlag() {
        migrationFlag = true;
    }

    /**
     *
     * @return whether the population is used for migration
     */
    public boolean getMigratingFlag() {
        return migrationFlag;
    }

    /**
     * Each population has its unique key given by the framework at initialization by this function.
     *
     * @param k integer to set the key to.
     */
    public void setKey(int k) {
        key = k;
    }

    /**
     * @return the key (id) of the population
     */
    public int getKey() {
        return key;
    }

    /**
     * @return population size
     */
    public int size() {
        return pop.getRowDimension();
    }

    /**
     *
     * @param j Index of Individual to return
     * @return Individual with index j
     */
    public RealVector get(int j) {
        return pop.getRowVector(j);
    }

    /**
     * Sets one Individual with index j, rewriting the old one
     *
     * @param j Index of new Individual
     * @param ind Individual to be added
     */
    public void set(int j, RealVector ind) {
        pop.setRowVector(j, ind);
        sorted = false;
    }


    /**
     * ?
     * Sets all Individuals to random values
     */
    public void randomize() {
        /*for (Individuals ind : individualsList) {
            ind.randomize();
            evaluateIndividual(ind);
        }*/
        for (int i=0;i<pop.getRowDimension();i++){

        }
    }
    /**
     * The fitness value of the ith individual was calculated
     * @param i Individual to be evalueated
     * @return fitness of the Individual
     */
    public double evaluateIndividual(int i,RealVector Ind) {
        double fit = function.evaluate(Ind.toArray());
        //i.setFitness(fit);
        pop.setEntry(i,Ind.getDimension()+1,fit);
        return fit;
    }
    /**
     * The fitness value of the ith individual was calculated
     * @param i Individual to be evalueated
     * @return fitness of the Individual
     */
    public double evaluate(int i,RealVector Ind) {
        double fit = function.evaluate(Ind.getSubVector(0, Ind.getDimension() - 1).toArray());
        //i.setFitness(fit);
        pop.setEntry(i,Ind.getDimension()-1,fit);
        return fit;
    }
    /**
     * Ads a number of random Individuals to population
     *
     * N is the number of individuals in the population;D for the dimension
     * @param n number of Individuals to add
     */
    public void addRandomIndividuals(int n, int d) {
        //System.out.println("==d=="+d+"==n=="+n);
        if(function != null) {
            for (int i = 0; i < n; i++) {
                double min, max;
                RealVector values = new ArrayRealVector(d + 1);
                //RealVector
                for (int k = 0; k < d; k++) {
                    min = function.getMinRestriction(k);
                    max = function.getMaxRestriction(k);
                    //  Get random double within range.
                    values.setEntry(k, min + (Math.random() * (max - min)));
                }
                double fit = function.evaluate(values.toArray());
                values.setEntry(d, fit);
                pop.setRowVector(i,values);
                sorted = false;
            }
        }
    }

    //n is row
    public RealVector addCCRandomIndividuals(int row, int d) {
        //System.out.println("==d=="+d+"==n=="+n);
        RealVector values = new ArrayRealVector(d + 1);
        if(function != null) {
            double min, max;
            //RealVector
            for (int k = 0; k < d; k++) {
                min = function.getMinRestriction(k);
                max = function.getMaxRestriction(k);
                //  Get random double within range.
                values.setEntry(k, min + (Math.random() * (max - min)));
            }
            double fit = function.evaluate(values.toArray());
            values.setEntry(d, fit);
        }
        return values;
    }

    /**
     * Individual fitness value comparison;Compare by the value of the last column;Compare from small to big
     *  Sorts the population by fitness
     */
    public void sort() {
        double[][] temp = pop.getData();
        //1��Ranking temporarypop;The fitness values of the population were arranged in ascending order
        sort.sortDoubleArray(temp, pop.getColumnDimension() - 1);
        pop=new Array2DRowRealMatrix(temp);
        sorted = true;
    }
    /**
     * 
     * Get population index of the best Individual from ArrayList of Individuals.)
     * @param pops ArrayList of Individuals to search in.
     * @return best Individual from given ArrayList
     */
    public int getBestIndex(RealMatrix pops) {
        int i = 0, min_n = 0;
        double min = Double.POSITIVE_INFINITY;
        for (int j = 0; j < pops.getRowDimension(); j++, i++) {
            if (pops.getEntry(j,pops.getColumnDimension()-1) < min) {
                min = pops.getEntry(j, pops.getColumnDimension() - 1);
                min_n = i;
            }
        }
        return min_n;
    }
    /**
     * 
     * Get population index of the best Individual from ArrayList of Individuals.)
     * @return best Individual from given ArrayList
     */
    public int getBestIndex() {
        int i = 0, min_n = 0;
        double min = Double.POSITIVE_INFINITY;
        for (int j = 0; j < pop.getRowDimension(); j++, i++) {
            if (pop.getEntry(j,pop.getColumnDimension()-1) < min) {
                min = pop.getEntry(j, pop.getColumnDimension() - 1);
                min_n = i;
            }
        }
        return min_n;
    }

    /**
     *
     * @return best individual of existing population.
     */
    public RealVector getBestIndividual() {
        System.out.println("==sorted=="+sorted+"==bestIndividual=="+bestIndividual);
        if (sorted && bestIndividual != null) {
            return pop.getRowVector(0);
        } else {
            return pop.getRowVector(getBestIndex());
        }
    }

    /**
     * Get Individual by his population index
     * @param i Order of the Individual by fitness
     * @return Index of Individual
     */
    public int getIndexFromFitnessOrder(int i) {
        if(!sorted) {
            sort();
        }
        int n = 0;
        /*
         * 
         *
         * i=3
         */
        /*for (Individual ind : individualsList) {
            if (ind.getIndex() == i) {
                return n;
            }
            n++;
        }*/
        for(int j=0;j<pop.getRowDimension();j++){
            //Gets the row number of the matrix
            //if(pop)
        }
        return -1;
    }
    /**
     * Accepts immigrants into existing population.
     * Ǩ��Ĳ���
     * @see acceptImmigrantsMethod
     * @param immigrants Immigrating Population
     * @param method One of Population.acceptImmigrantsMethod (REPLACE_WORST, REPLACE_BEST, REPLACE_RANDOM, NO_REPLACE).
     */
    public void acceptImmigrants(populationRM immigrants, acceptImmigrantsMethod method) {
        switch (method) {
        	/*
        	 * Substitution strategy:
        	 * 1��Substitution worst
        	 * 2��Substitution best
        	 * 3��Random replacement
        	 * 4��Don't replace
        	 */
            case REPLACE_WORST:
                if (!sorted) {
                    sort();//After sorting;The order of pop has changed
                }//All individuals were ranked by fitness value
                //
                /*
                J is population number of pop (current population)
                I is the number of migrating species
                Replace the last immigrants. Size () individuals
                 */
                for (int i = 0, j = pop.getRowDimension() - 1, n = -1;
                     i < immigrants.size(); i++, j--) {
                    //n = getIndexFromFitnessOrder(j);
                    //if (n != -1) {
                        pop.setRowVector(j, immigrants.get(i));
                    //}
                }
                break;
            case REPLACE_BEST:

                if (!sorted) {
                    sort();
                }
                for (int i = 0, n = -1; i < immigrants.size() && i < pop.getRowDimension(); i++) {
                    //n = getIndexFromFitnessOrder(i);
                    pop.setRowVector(i, immigrants.get(i));
                }
                break;
            case REPLACE_RANDOM:
                Double r = 0.0;
                for (int i = 0; i < immigrants.size(); i++) {
                    r = Math.random() * pop.getRowDimension();
                    pop.setRowVector(r.intValue(), immigrants.get(i));
                }
                break;
            case NO_REPLACE:
                for (int i = 0; i < immigrants.size(); i++) {
                    //individualsList.add(immigrants.get(i));
                    //pop.add(immigrants.getPop());
                    pop.setRowVector(i,immigrants.getPop().getRowVector(i));
                }
                break;
        }

        sorted = false;
    }

    /**
     * Expels immigrants from evolved population.
     * Out of the population
     * @see expelEmigrantsMethod
     * @param nMigratingIndividuals Number of emigrants
     * @param method One of Population.expelEmigrantsMethod (EXPEL_BEST, EXPEL_RANDOM).
     */
    public populationRM getEmigrants(int nMigratingIndividuals, expelEmigrantsMethod method) {
        populationRM temp = new populationRM(nMigratingIndividuals,pop.getColumnDimension()-1);
        int index;
        if(!sorted) {
            sort();
        }
        switch (method) {
            case EXPEL_BEST: {
                for (int i = 0; i < nMigratingIndividuals; i++) {
                    temp.pop.setRowVector(i,pop.getRowVector(i));
                }
                break;
            }
            case EXPEL_RANDOM: {
                Double r = 0.0;
                for (int i = 0; i < nMigratingIndividuals; i++) {
                    r = Math.random() * pop.getRowDimension();
                    temp.pop.setRowVector(i,pop.getRowVector(r.intValue()));
                }
                break;
            }
            case EXPEL_BEST_AND_RANDOM: {
                //add best
                temp.pop.setRowVector(0,pop.getRowVector(0));
                Double r = 0.0;
                for (int i = 1; i < nMigratingIndividuals; i++) {
                    //add random
                    r = Math.random() * pop.getRowDimension();
                    temp.pop.setRowVector(i,pop.getRowVector(r.intValue()));
                }
                break;
            }
        }

        return temp;
    }
    /**
     * Determines how immigrating individuals are handled.
     */
    public static enum acceptImmigrantsMethod {

        /**
         * Replace individuals with worst value
         */
        REPLACE_WORST,
        /**
         * Replace individuals with best value
         */
        REPLACE_BEST,
        /**
         * Replace random individuals
         */
        REPLACE_RANDOM,
        /**
         * Adds immigrants to population by increasing its size
         */
        NO_REPLACE
    }

    /**
     * Determines how emigrating individuals are chosen.
     */
    public static enum expelEmigrantsMethod {

        /**
         * Migrate best individuals
         */
        EXPEL_BEST,
        /**
         * Migrate random individuals
         */
        EXPEL_RANDOM,
        /**
         * Migrate 1 best individual and some random individuals
         */
        EXPEL_BEST_AND_RANDOM,
    }



}
