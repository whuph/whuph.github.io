﻿package com.txj.Commons;
import java.math.*;

public class CFunction {
	// public double params[];//Number of parameters
	public double parmin;// Parameters of the lower limit
	public double parmax;// Parameters of the ceiling
	public boolean flag;

	public CFunction(double parmin, double parmax, boolean flag) {
		this.parmin = parmin;//-2
		this.parmax = parmax;//3
		this.flag = flag;
	}

	public double Compute(int i, double pars[]) {
		return Function.Func(i, pars);
	}

}