package com.txj.DE;

/**
 * Created by hadoop on 15-5-21.
 */
import cer2003.Common;
import com.txj.bean.Individual;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;

import java.util.ArrayList;
import java.util.List;
public class DETest {

    //Initializes a random point of N D dimensions
    public static void main(String[] args) throws Exception {
        SparkConf sparkConf = new SparkConf().setAppName("JavaSparkDE");
        JavaSparkContext jsc = new JavaSparkContext(sparkConf);
        //
        int n = 1000; 
        int D = 1000; 
        int slices = (args.length == 1) ? Integer.parseInt(args[0]) : 2;
        ArrayList<ArrayList<Double>> population = new ArrayList<ArrayList<Double>>();
       
        Individual individual=new Individual();
        
        population= individual.generalPopulation(n, D);
        
        JavaRDD<ArrayList<Double>> dataSet = jsc.parallelize(population, slices);
        final Common common=new Common();
        //
        dataSet.map(new Function<ArrayList<Double>, ArrayList<Double>>() {
            @Override
            public ArrayList<Double> call(ArrayList<Double> doubles) throws Exception {
                //All elements of the input data are evaluated
                ArrayList<Double> Fitness = new ArrayList<Double>();
                double fit = 0.0;
                for (int i = 0; i < doubles.size(); i++) {
                    fit += common.squares(doubles.get(i));
                }
                Fitness.add(fit);//Calculate the value of fitness
                return Fitness;
            }
        }).cache();

        jsc.stop();
    }
}
