﻿package com.txj.bean;

import java.util.ArrayList;

/**
 * Created by hadoop on 15-5-21.
 */
public class Individual {
    //Generate a d-dimensional individual
    public ArrayList<Double> addRandomIndividual(int d) {
        double min=-100, max=100;
        ArrayList<Double> values = new ArrayList<Double>();
        for (int k = 0; k < d; k++) {
            values.add(min + (Math.random() * ((max - min) + 1)));
        }
        return values;
    }
    //Produce n d-dimensional individuals
    public ArrayList<ArrayList<Double>> generalPopulation(int n,int d){
        ArrayList<ArrayList<Double>> population=new ArrayList<ArrayList<Double>>();
        for (int k=0;k<n;k++) {
            population.add(addRandomIndividual(d));
        }
        return population;
    }
}
