﻿package com.txj.dg;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class HelloWorld {
    
    public static List<Integer> initData(){
        List<Integer> datas = new ArrayList<Integer>();
        Integer data = null;
        for(int i=11;i<=20;i++){
            data = new Integer(i);
            datas.add(data);
        }
        return datas;
    }

    public static void main(String[] args) {
        int[] indexArr = new int[]{1,9,2,5};
        
        Arrays.sort(indexArr);

        for(Integer index : indexArr){
            System.out.println(index);
        }

        List<Integer> datas = initData(); 

        System.out.println("before the delete:  "+datas);

        for(int i=indexArr.length-1;i>=0;i--){ //Reverse order
            if(i<=datas.size()){
                System.out.println("delete  "+(indexArr[i]+1)+" element");
                datas.remove(indexArr[i]);
            }
        }

        System.out.println("After deleting:  "+datas);
    }
}