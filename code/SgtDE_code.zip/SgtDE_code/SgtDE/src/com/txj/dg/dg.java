﻿package com.txj.dg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import cec2010.*;
import cec2010.Function;

/**
 * @author Administrator
 *
 */
public class dg {
	private  Function f;
	private  double ubound;
	private  double lbound;
	private  int dim;
	private  float epsilon;
	private double[] individual;
	private double[] newindividual;
	private List seps;
	private int FEs;
	private HashMap<Integer, List> noseps;
	private List<Integer> dims;
	public dg(){

	}
	public dg(Function f){
		this.f=f;
		this.dim=f.getDimension();
		this.ubound=f.getMax();
		this.lbound=f.getMin();
		noseps=new HashMap<>();
		seps=new ArrayList<>();
		this.dims=new ArrayList<Integer>();
		for (int i = 0; i < dim; i++) {
			dims.add(i);
		}
	}
	public dg(Function f,double ub){
		this(f);
		this.ubound=ub;
	}
	public Function getF() {
		return f;
	}
	public void setF(Function f) {
		this.f = f;
	}
	public double getUbound() {
		return ubound;
	}
	public void setUbound(double ubound) {
		this.ubound = ubound;
	}
	public double getLbound() {
		return lbound;
	}
	public void setLbound(double lbound) {
		this.lbound = lbound;
	}
	public int getDim() {
		return dim;
	}
	public void setDim(int dim) {
		this.dim = dim;
	}
	public float getEpsilon() {
		return epsilon;
	}
	public void setEpsilon(float epsilon) {
		this.epsilon = epsilon;
	}

	public List getSeps() {
		return seps;
	}
	public void setNoseps(List seps) {
		this.seps = seps;
	}
	public HashMap<Integer, List> getNoseps() {
		return noseps;
	}
	public void setSeps(HashMap<Integer, List> noseps) {
		this.noseps = noseps;
	}
	public int getFEs() {
		return FEs;
	}
	public void setFEs(int fEs) {
		FEs = fEs;
	}
	public double[] getIndividual() {
		return individual;
	}
	public void setIndividual(double[] individual) {
		this.individual = individual;
	}
	public double[] getNewindividual() {
		return newindividual;
	}
	public void setNewindividual(double[] newindividual) {
		this.newindividual = newindividual;
	}

	public List getDims() {
		return dims;
	}
	public void setDims(List dims) {
		this.dims = dims;
	}
	
	public double feval(double[] x) {
		double d;
		d = f.compute(x);
		return d;
	}

	
	public double[] Initializeindividual(){
		individual = new double[this.dim];
		newindividual=new double[this.dim];
		for(int i=0;i<this.dim;i++){
			individual[i]=1.0*this.lbound;
			newindividual[i]=individual[i];
		}
		return individual;
	}
	public void changeIndividualByIndex(int index,double value){
		newindividual[index]=value;
	}

	/**
	 * Decomposition methods
	 */
	public void diff_grouping(){
		/*
		 * length(dims)>1
		 */
		int key=0;

		while(this.dims.size()>=1){
			List<Integer> group = new ArrayList<>();
			List<Integer> group_ind = new ArrayList<>();
			group.add((int)dims.get(0));
			group_ind.add(0);
			int n=dims.size();
			double[] p1=new double[dim];
			System.arraycopy(this.individual, 0, p1, 0, p1.length);
			double[] p2=new double[dim];
			System.arraycopy(p1, 0, p2, 0, p2.length);
			p2[(int)dims.get(0)]=this.ubound;
			//changeIndividualByIndex((int)dims.get(0), this.ubound);
			double delta1=feval(p1)-feval(p2);
			FEs=FEs+2;

			for(int i=1;i<n;i++){
				double[] p3 = new double[dim];
				System.arraycopy(p1, 0, p3, 0, p3.length);
				double[] p4 = new double[dim];
				System.arraycopy(p2, 0, p4, 0, p4.length);
				int temp=0;
				p3[(int)dims.get(i)]=temp;
				p4[(int)dims.get(i)]=temp;
				double delta2=feval(p3)-feval(p4);
				FEs=FEs+2;
				if(Math.abs(delta1-delta2)>0.001){
					group.add((int)dims.get(i));
					group_ind.add(i);
				}
			}
			if(group.size()==1){
				//seps.put(key, value)
				seps.add(group.get(0));
			}else{
				noseps.put(key, group);
				key++;
			}
			if(dims.size()>0){
				//System.out.println("Grouping period dims.size is"+dims.size());
				for(int i=group_ind.size()-1;i>=0;i--)	{
					//System.out.println("group_ind.get(i)="+group_ind.get(i));
					//System.out.println("Grouping period dims is "+dims+"group_ind.get("+i+")"+group_ind.get(i));
					//dims.remove(group_ind.get(i));
					int index=group_ind.get(i);
					dims.remove(index);
					//System.out.println("Grouping period dims is "+dims);
					//dims.remove(dims.get(group_ind.get(i)));
				}

			}

		}

	}






	public static void main(String[] args){
		HashMap<Integer, List<Integer>> map=new HashMap<>();
		for(int i=0;i<2;i++){
			List<Integer> list=new ArrayList<>();
			list.add(1);
			list.add(2);
			map.put(i, list);
		}
		//输出list中的值
		//System.out.println(list.size());
		//输出map中的值
		for(int i=0;i<2;i++)
			System.out.println("map中的值"+i+"=="+map.get(i));
		/*double[] best;
		double[] cur;	
		dim=f.getDimension();
		ubound=100;
		lbound=-100;
		best = new double[dim];
		cur = new double[dim];
		for (int i = (dim - 1); i >= 0; i--) {
		      cur[i] = lbound;
		}
		f=new F1(cur);
		
		System.out.println("计算得到的解为"+f.compute(cur));*/
	}
}