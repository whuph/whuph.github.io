﻿package com.txj.dg;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import cec2010.*;
import cec2010.Function;
import com.DCGroup.diff_grouping;
import scala.Int;

//import static sun.org.mozilla.javascript.internal.ScriptRuntime.typeof;

public class dgtest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(Math.ceil(12/5));
		Function f=new F13();
		System.out.println("=F="+f.getFullName());
		/*
		dg d=new dg(f);
		d.Initializeindividual();
		d.diff_grouping();

		System.out.println("Separable variables."+d.getSeps());
		System.out.println("the number of Separable variables."+d.getSeps().size());
		for(int i=0;i<d.getNoseps().size();i++){
			System.out.println("Indivisible variables."+d.getNoseps().get(i));
			System.out.println("Group of indivisible variables"+d.getNoseps().get(i).size());
		}
		*/
		diff_grouping d=new diff_grouping(f);
		HashMap<Integer, List<Integer>> group= d.getGroup();
		for(int i=0;i<group.size();i++){
			System.out.println("the"+i+"group");
			System.out.println(group.get(i));
		}

		HashMap<Integer, List<Integer>> list= Randomizer.randIndexperm(f);
		/*Iterator it1=list.iterator();
		while (it1.hasNext()){
			System.out.println(it1.next());
		}*/
		System.out.println("list.size=="+list.size());
		Int[] objects = new Int[list.size()];
		//list.

		for(int i=0;i<list.size();i++){
			System.out.println(list.get(i));
		}


		//System.out.println(di[0]+"==="+d.getIndividual()[0]);
		//d.changeIndividualByIndex(0, 100);
		//System.out.println(d.getIndividual()[0]+"Before and after"+d.getNewindividual()[0]);
		//double delta1= d.feval(d.getIndividual())-d.feval(d.getNewindividual());
		//System.out.println("delta1="+delta1);
		
		
		/*float p1=d.feval(d.getIndividual());
		d.changeIndividualByIndex(0, d.getUbound());
		float p2=d.feval(d.getIndividual());
		System.out.println("f4==p1"+p1+" p2= "+p2+" p1-p2="+(p1-p2));
		*/
		
		/*List<Integer> group_ind = new ArrayList<>();
		group_ind.add(0);
		List<Integer> dims=d.getDims();
		dims.remove(group_ind.get(0));
		System.out.println("dims"+d.getDims());*/




		//System.out.println("Group of Separable variables"+d.getNoseps().size());
		
		/*BigDecimal bg1 = new BigDecimal(1);
	    bg1.setScale(0);
	     
	    BigDecimal bg2 = new BigDecimal(new BigInteger("3"),0);
	     
	    System.out.println(bg1.add(bg2));//+
	    System.out.println(bg1.subtract(bg2));//-
	    System.out.println(bg1.multiply(bg2));//*
	    System.out.println(bg1.divide(bg2,30,BigDecimal.ROUND_HALF_UP));
	    System.out.println(bg1.divide(bg2,RoundingMode.HALF_UP));
	    
	    java.math.BigDecimal big=new java.math.BigDecimal("123456789012345678901");
        System.out.println(big);
        double b=Double.parseDouble("12345678901234567");
        System.out.println(b);*/
	}

}