﻿package com.txj.dg;

import cec2010.F9;
import cec2010.Function;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		F9 f=new F9();
		// Obtain the shift vector of the benchmark function
		double[] l= f.getShiftVector();
		for (int i = 0; i < l.length; i++) {
			System.out.println("the "+i+" th=="+l[i]);
		}
		//Obtain the optimum vector of the benchmark function
		double[] opt= f.getOptimum();
		for (int i = 0; i < l.length; i++) {
			System.out.println("the "+i+"th=="+opt[i]);
		}
		//Obtain the permutation vector of the benchmark function
		int[] p= f.getPermutationVector();

		dg d=new dg(f);
		System.out.println("random variable");
		//double[] di= d.Initializeindividual();
		//1.03450712E12
		System.out.println(d.feval(d.Initializeindividual()));
		d.changeIndividualByIndex(0, f.getMax());
		System.out.println(d.feval(d.getNewindividual()));
		System.out.println(d.feval(d.getIndividual()));
	}

}