package com.util
import org.apache.spark.Partitioner
class IteblogPartitioner(numParts: Int) extends Partitioner{
    override def numPartitions: Int = numParts
    override def getPartition(key: Any): Int = {
    	    val domain = new java.net.URL(key.toString).getHost()
    	    val code = (domain.hashCode % numPartitions)
     	    if (code < 0) {
       	      code + numPartitions
       	  } else {
       	      code
         	}
    }

  	override def equals(other: Any): Boolean = other match {
   	    case iteblog: IteblogPartitioner =>
       	      iteblog.numPartitions == numPartitions
   	    case _ =>
       	      false
      	  }

  	override def hashCode: Int = numPartitions
}
