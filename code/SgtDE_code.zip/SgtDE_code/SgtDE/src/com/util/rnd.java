﻿package com.util;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;

public class rnd {
	
	public static int[] randomCommon(int min, int max, int n) {
		if (n > (max - min + 1) || max < min) {
			return null;
		}
		int[] result = new int[n];
		int count = 0;
		while (count < n) {
			int num = (int) (Math.random() * (max - min)) + min;
			boolean flag = true;
			for (int j = 0; j < n; j++) {
				if (num == result[j]) {
					flag = false;
					break;
				}
			}
			if (flag) {
				result[count] = num;
				count++;
			}
		}
		return result;
	}

	public static void randomSet(int min, int max, int n, HashSet<Integer> set) {
		if (n > (max - min + 1) || max < min) {
			return;
		}
		for (int i = 0; i < n; i++) {
			
			int num = (int) (Math.random() * (max - min)) + min;
			set.add(num);
		}
		int setSize = set.size();
		
		if (setSize < n) {
			randomSet(min, max, n - setSize, set);
		}
	}

	public static int[] randomArray(int min, int max, int n) {
		int len = max - min + 1;

		if (max < min || n > len) {
			return null;
		}

		
		int[] source = new int[len];
		for (int i = min; i < min + len; i++) {
			source[i - min] = i;
		}

		int[] result = new int[n];
		Random rd = new Random();
		int index = 0;
		for (int i = 0; i < result.length; i++) {
			
			index = Math.abs(rd.nextInt() % len--);
			
			result[i] = source[index];
			
			source[index] = source[len];
		}
		return result;
	}

	public static int[] randomArray(int min, int max, int n, int key) {
		int len = max - min +1;
		if(key>min && key<max){
			len=len-1;
		}
		if (max < min || n > len) {
			return null;
		}
		
		int[] source = new int[len];
		int k=0;
		for (int i = min; i < min + len; i++) {
			if((i - min)!=key){
				source[i - min + k] = i;
			}else{
				k=k-1;
				len=len+1;
			}
		}
		if(k<0){
			len=len-1;
		}
		int[] result = new int[n];
		Random rd = new Random();
		int index = 0;

		for (int i = 0; i < result.length; i++) {
			
			index = Math.abs(rd.nextInt() % len--);
			
			result[i] = source[index];
			
			source[index] = source[len];
		}

		return result;
	}

	public static void main(String[] args) {
		
		for(int j=0;j<10;j++){
			System.out.println("the"+j+"th random number is");
			int[] reult2 = randomArray(0, 5, 3,0);
			for (int i : reult2) {
				System.out.print(i+" ");
			}
			System.out.println();
		}

	}
}