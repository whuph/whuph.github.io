package test.scala

class test {
  def main(args: Array[String]): Unit = {
    val arr=for(r<-0 to 4) {

    }
  }
}
