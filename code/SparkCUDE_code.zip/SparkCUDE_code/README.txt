# SparkCUDE
The source code of the SparkCUDE is available.
The details about the SparkCUDE can be found in 'Peng, H., Tan, X., Deng, C. and Peng, S. (2017) SparkCUDE: a Spark-based differential evolution for large-scale global optimization’, Int. J. of
High Performance Systems Architecture.

%--------------------------------------------------------------------------------------------------------
% More information can visit H Peng's homepage: https://whuph.github.io/index.html
%--------------------------------------------------------------------------------------------------------