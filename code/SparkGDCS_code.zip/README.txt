Two test sets you can choose: CEC2010 and CEC2013.

If you want to choose CEC2010, you must "import cec2010.Function" and annotation "CEC2013.Function" in algorithm GDCS, and modify the relevant places, vice versa.

If you want to run the project, run the SiPDECCTest.scala file under the SPARKGDCS project, which path is SparkGDCS\src\com\island\SparkTest\SiPDECCTest.scala.

If you want to understand about this model and algorithm, you can start with files SiPDECCTest.scala, hzhDEDeaf.scala, and GDCS.java.
The paths of the three files in turn are:
1)SparkGDCS\src\com\island\SparkTest\SiPDECCTest.scala.
2)SPARKGDCS\SparkGDCS\src\com\island\SparkStrategies\hzhDEDeaf.scala
3)SPARKGDCS\SparkGDCS\src\com\island\SparkStrategies\GDCS.java

If you find this code useful in your work, please cite the 
following paper by the author of the code "He Z, Peng H, Deng C, et al. A Spark-based Gaussian Bare-bones Cuckoo Search with dynamic parameter selection[C]//2019 IEEE Congress on Evolutionary Computation (CEC). IEEE, 2019: 1220-1227".