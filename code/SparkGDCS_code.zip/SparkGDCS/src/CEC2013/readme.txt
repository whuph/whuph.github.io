testfunc.java is the test function
Example:
testfunc tf = new testfunc();

tf.test_func(x, f, dimension,population_size,func_num);

testmain.java is an example function about how to use testfunc.java
