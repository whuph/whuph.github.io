package com.island
import java.util.Random
import cer2003.FitnessFunctions._
import com.island.strategies.Topologies.{Ring, RandomT}
import com.island.strategies._

import org.apache.commons.math3.linear.{ArrayRealVector, RealVector, Array2DRowRealMatrix, RealMatrix}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer
import scala.math.exp
import breeze.linalg.{max, min, Vector, DenseVector}
import org.apache.spark._
import org.apache.spark.SparkContext

import org.apache.spark.SparkContext._
import org.apache.spark.{SparkConf,SparkContext}
import cer2003._
import com.txj.Commons._

/**
 * Created by hadoop on 15-7-16.
 */
/**
 * Created by hadoop on 2015-7-6.
 * 岛之间是并行处理的、但岛中实现并行进化
 * 岛内怎么实现并行进化？
 * 岛模型的基本思想：
 * N*D的种群；islands岛；
 * 1、在每一个岛上初始化N/islands个种群（每一个个体的适应度；最优值和最优个体）
 * 初始化之后要不要回收？
 *
 * 2、根据迁移规则，在每一个岛上进行迁移
 * 3、迁移完成之后，每一个岛独立进行进化generationsPerRound代
 * 4、进化完成之后，进行下一轮的进化（跳到第2步）
 *
 * ===============================
 * 获取其他分区中的数据
 * 实现步骤：
 * 1、将具体用到的类写好
 * 2、按照基本思想一步一步写
 */
object DE2 {
  //岛的编号、适应度函数,D:Int,N:Int
  def Initialize(island: Int,function: FitnessFunction,pop:populationRM): (Int,populationRM) ={
    //var pop:populationRM=new populationRM(N,D)//行、列（维度）
    //val function: FitnessFunction =new cer2003.FitnessFunctions.CER2003_F1(D)
    pop.setFitnessFunction(function)
    pop.setKey(island)
    var N= pop.getNumber//
    var D=pop.getDimensions
    pop.addRandomIndividuals(N,D)
    //进化的策略
    val alg:Algorithm=new DERand1binParal(pop.getFitnessFunction,D,N)
    pop.setAlgorithm(alg)
    (island,pop)
  }
  //island为岛的编号,pops为个体，pop为种群
  /*
  一个岛，一个种群中的某一个个体
   */
  def parallelEvolution(island: Int,pops:Int,pop:Array[(Int,populationRM)],generationsPerRound:Int):(Int,RealVector) ={
      //println("===="+island+"====")//岛的编号
      //println("===="+pops+"====")//个体的数
      var newpop:populationRM=pop.apply(island)._2
      newpop.getPop
      println(newpop.getPop.getRowVector(pops))
      ///////////////////////进化算法/////////////////
      val alg=newpop.getAlgorithm() //new DERand1bin(newpop.getFitnessFunction,D,N)
      //println("alg=="+alg.newRound())
      for(iter<-0 to generationsPerRound){
        println("第"+iter+"轮开始")
        alg.setPopulation(newpop,generationsPerRound)//5

        //每个岛中的第pops个个体
        val gen= alg.generation(pops)//进化
        println(newpop.getPop.getRowVector(pops))
        println("第"+iter+"轮结束最优值"+gen.getEntry(gen.getDimension-1))
      }
      //岛，个体，适应度值
      (island,newpop.get(pops))
  }

  def evolution(island: Int,pop:Array[(Int,populationRM)],generationsPerRound:Int):(Int,populationRM,RealVector) ={
    //获取第island个岛上的种群
    //函数要进行 传递
    //val function: FitnessFunction =new cer2003.FitnessFunctions.CER2003_F1(D)
    var newpop:populationRM=pop.apply(island)._2
    ///////////////////////进化算法/////////////////
    val alg=newpop.getAlgorithm() //new DERand1bin(newpop.getFitnessFunction,D,N)
    //println("alg=="+alg.newRound())
    alg.setPopulation(newpop,generationsPerRound)//5
    val gen= alg.generation()//进化
    (island,newpop,gen)
  }

  def Emigrants(island:Int,pop:Array[(Int,populationRM,RealVector)],T:Topology,ImmigrationPopSize:Int): (Int,populationRM) ={
    var newpop:populationRM=pop.apply(island)._2
    //拓扑结构

    /*
    编号为0的岛 其迁入的岛为2
    0<----2
    1<----0
    2<----1
     */
    //根据当前的岛编号；获取待迁入的岛编号
    var key= T.getImmigration(island)//？
    //获取迁出岛的种群
    for (k<-0 to key.length-1){
      //迁出20个个体
      var immigrants=pop.apply(key(k))._2
        .getEmigrants(ImmigrationPopSize,populationRM.expelEmigrantsMethod.EXPEL_BEST)
      newpop.acceptImmigrants(immigrants,populationRM.acceptImmigrantsMethod.REPLACE_WORST)
    }
    //将当前岛的种群返回
    (island,newpop)
  }


  def main(args: Array[String]): Unit ={
    val minFit = ArrayBuffer[String]() //Set[Double]()//存放每一代的最优值
    System.setProperty("spark.akka.frameSize","1000000")//单位是MB
    System.setProperty("spark.scheduler.mode", "FAIR")
    val sparkConf = new SparkConf()
      .setAppName("IslandDE")
      .setMaster("local")
    //.set("spark.executor.memory","2g")
    //sparkConf.setExecutorEnv("spark.akka.frameSize","1000000")
    val sc = new SparkContext(sparkConf)

    //分区的个数
    var numSlices = if (args.length > 0) args(0).toInt else 2
    var D=args(1).toInt//维度 50 50
    var N=5 //*D //500//args(2).toInt//个体的数目10*D// 10*D*
    var islands=0//岛的数目:从0开始；1表示有两个岛
    //迁移的轮数 :从0开始；1表示有迁移两轮
    //org.apache.commons.math.linear.RealVector
    var migrationRounds=0//进化的轮数 从0开始 10
    var generationsPerRound=10//每一轮进化的代数
    ///函数运行的次数 1000*300
    var run=args(2).toInt//函数运行的次数:从0开始
    var startFun=args(3).toInt//开始的函数 最小值：1
    var endFun=args(4).toInt//结束的函数 最大值：7
    var ImmigrationPopSize=20 //迁移的个体数量 应为种群数量的300/5=60 20%
    //分区策略？进程？
    //初始化pop (N / (islands + 1),D) 每一个岛的种群为N/(islands+1)
    val pop: populationRM = new populationRM( N/(islands+1), D) //行、列（维度）
    //运行的次数
    var function: FitnessFunction = null//new cer2003.FitnessFunctions.CER2003_F1(D)
    //运行第几个函数
    for (ifun <- startFun to endFun) {
      //控制函数
      ifun match {
        /*case 1 => function = new CER2003_F1(D) //F1
        case 2 => function = new CER2003_F3(D) //F3
        case 3 => function = new CER2003_F5(D) //F5
        case 4 => function = new CER2003_F9(D) //F9
        case 5 => function = new CER2003_F10(D) //F10
        case 6 => function = new CER2003_F11(D) //F11*/
        case 1 => function = new CER2003_F1(D) //F1
        case 2 => function = new CER2003_F2(D) //F3
        case 3 => function = new CER2003_F3(D) //F5
        case 4 => function = new CER2003_F4(D) //F9
        case 5 => function = new CER2003_F5(D) //F10
        case 6 => function = new CER2003_F6(D) //F11
        case 7 => function = new CER2003_F7(D) //F1
        case 8 => function = new CER2003_F8(D) //F3
        case 9 => function = new CER2003_F9(D) //F5
        case 10 => function = new CER2003_F10(D) //F9
        case 11 => function = new CER2003_F11(D) //F10
        case 12 => function = new CER2003_F12(D) //F11
        case 13 => function = new CER2003_F13(D) //F11
      }
      //分区
      for (slice <- 0 to 0) {
        slice match {
          /*case 0 => numSlices = 1;
          case 1 => numSlices = 2;
          case 2 => numSlices = 4;
          case 3 => numSlices = 8;
          case 4 => numSlices = 12;
          case 5 => numSlices = 16;
          case 6 => numSlices = 20;
          case 7 => numSlices = 24;
          case 8 => numSlices = 5;*/
          case 0 => numSlices = 1;
          case 1 => numSlices = 2;
          case 2 => numSlices = 3;
          case 3 => numSlices = 4;
          case 4 => numSlices = 5;

        }
        var path = ""
        path = "/home/hadoop/sparkDEResult/SparkDE/resultDERand1island201507161001"
        //函数运行的次数
        for (runk <- 0 to run) {
          minFit.clear()
          val startTime = System.currentTimeMillis() //开始时间
          //在islands个岛上分别初始化一个种群
          //每个岛的数量为N/islands  D, N/islands,
          //parallelize(0 to islands)表示有多少个岛
          //种群是否分在分区中？ 初始化种群

          var generationPop = sc.parallelize(0 to islands, numSlices)//, numSlices
              .map(i => Initialize(i, function,pop)).cache()
              //.collect()
          var best = generationPop.collect().apply(0)._2.getBestIndividual.getEntry(D)

          val T: Topology = new Ring(islands + 1) //实例化拓扑结构 三个岛 Ring（2）：2表示有2个岛
          //迁移的轮数
          for (rounds <- 0 to migrationRounds) {
            //将广播变量进行序列化，然后进行并行化处理

            //sc.makeRDD(0 to islands,numSlices).map(i=>)
            /*
              generationPop产生下面三个种群
              generationPop1
              generationPop2
              generationPop3

             */



            /*
            岛的编号       个体的编号
               0          0,1,2,3,4
               1          0,1,2,3,4
            */
            //genPopRC.value 迁移 //SCI EI

          }
          //获取第一个岛的最优值
          best = generationPop.collect().apply(0)._2.getBestIndividual.getEntry(D)

          //println("第一个岛的最优值==" + best)

          for (island <- 0 to islands) {
            //println("第" + island + "个岛")
            var temporaryBest = generationPop.collect().apply(island)._2.getBestIndividual.getEntry(D)
            if(temporaryBest<best){
              best=temporaryBest
            }
            //println("==最优值==" + best)
          }
          val endTime = System.currentTimeMillis() //结束时间
          //存放值为：F：函数、run：运行次数、slices：分区、最优值、运行时间（毫秒）
          minFit += "F" + (ifun) +"  run:" + (runk + 1) + "  " + "-Slices-" +
            numSlices+"  "+ best.toString + "   " + (endTime - startTime) + "\n"
          //将运行结果存放在本地
          //Common.appendMethodB(path, minFit.toString)
        }
      }

      val a = sc.parallelize(List("dogs", "cat", "owls", "gnu", "ant"), 2)
      val b = a.map(x => (x.length, x))
      val c = b.reduceByKey(_ + _).collect
      //b.mapValues(p=>)
      b.persist(StorageLevel.OFF_HEAP)

      c.foreach(println)

      val x = sc.parallelize(List(1,2,3,4,5,6,7,8,9,10), 3)



    }



    ///////////////////////进化算法/////////////////
    /*val alg:Algorithm=new DERand1bin(function,D,N)
    alg.setPopulation(generationPop.apply(1)._2,generationsPerRound)//5
    //进化演化
    val gen= alg.generation()


    println("最优的值为=="+ gen.getEntry(gen.getDimension-1))*/

    sc.stop()

  }
}
