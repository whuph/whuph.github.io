package com.java.tools;

import com.txj.Commons.Randomizer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*for (int k=0;k<100;k++) {
			System.out.println("循环"+k);
			int[] rand = RandSet.randomArray1(1, 10, 5, 6);
			System.out.println("随机生成的数为：");
			for (int i = 0; i < rand.length; i++) {
				System.out.print(rand[i] + " ");
			}
			System.out.println();
		}*/
		//Randomizer
		Random rnd=new Random();
		for (int k=0;k<100;k++) {
			System.out.println(rnd.nextDouble());
		}

		
	}
}
