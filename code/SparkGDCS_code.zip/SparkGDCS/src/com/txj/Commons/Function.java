package com.txj.Commons;
import java.util.ArrayList;

import org.apache.hadoop.io.LongWritable;




//import testFunction.*;
import cer2003.*;
public class Function {

	
	public static double Func(int i, double pars[])
	{
		 //Randomizer rnd=new Randomizer(10);
		 double v=0.0;
		 switch(i){
		 	case 1:
		 		F1 f1= new F1();
		 		v=f1.compute(pars);
		 		break;
		 	case 2:
		 		F2 f2= new F2();
		 		v=f2.compute(pars);
		 		break;
		 	case 3:
				F3 f3=new F3();
				v=f3.compute(pars);
				break;
			case 4:
				F4 f4=new F4();
				v=f4.compute(pars);
				break;
			case 5:
				F5 f5=new F5();
				v=f5.compute(pars);
				break;
			case 6:
				F6 f6=new F6();
				v=f6.compute(pars);
				break;
			case 7:
				F7 f7=new F7();
				v=f7.compute(pars);
				break;
			case 8:
				F8 f8=new F8();
				v=f8.compute(pars);
				break;
			case 9:
				F9 f9=new F9();
				v=f9.compute(pars);
				break;
			case 10:
				F10 f10=new F10();
				v=f10.compute(pars);
				break;
			case 11:
				F11 f11=new F11();
				v=f11.compute(pars);
				break;
			case 12:
				F12 f12=new F12();
				v=f12.compute(pars);
				break;
			case 13:
				F13 f13=new F13();
				v=f13.compute(pars);
				break;
		 }
		 return v; //f3.compute(pars);
	}
	
	public static double Func1(double pars[])
	{
		System.out.println("pars[0]="+pars[0]+"pars[1]="+pars[1]);
		return (pars[0]*6+2*pars[1]);
	}
	
	
}
