/*This is a simple demo of GDCS
 * --------------------------------------------------------------------------------------------------------
 * If you find this code useful in your work, please cite the 
 * following paper by the author of the code "He Z, Peng H, Deng C, et al.
 * Spark-based Gaussian Bare-bones Cuckoo Search with dynamic parameter 
 * selection[C]//2019 IEEE Congress on Evolutionary Computation (CEC). IEEE, 2019: 1220-1227".
 * --------------------------------------------------------------------------------------------------------
 * This function is implmented by ZhiHui He
 * 
 * */

package com.island.SparkStrategies;

//import cec2010.Function;
import CEC2013.Function;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GDCS extends Algorithm{

    //Number of dimension
    static protected double ndimensions;
    static protected double nfevalmax; 
    
    static protected double pa; //Discovery rate of alien eggs/solutions

    static protected Random rand;  // Random number

    static protected double beta,pi,sigma;  //Mathematical function
    static protected double betap2;
    
    static protected double temp_u,temp_v, a;
    static protected double step,stepsize; 

    static protected double pa_pool;  // Candidate pool of pa values, which ranges in [0.01,0.5]
    
    int generations;       //The number of iterations
    
    protected int num_nest;      //Number of nests,
    

    public GDCS(){

    }
    /**
     * Parameter setting for algorithm
     *
     * @param f
     *            Current test function
     * @param D_
     *            Individual dimension
     * @param popSize_
     *            The population size
     * 
     */
    public GDCS(Function f, int D_, int popSize_) {
        //super(f, D_, popSize_);
        dimensions = D_;
        popSize = popSize_;
        function = f;
        population.setFitnessFunction(f);
        minPopulationSize = 5;

        beta = 1.5;
        pa=0.25;
        num_nest = popSize;
        ndimensions = 30;
        nfevalmax=10000*ndimensions;
        rand = new Random();
        pi = Math.PI;
        betap2 = Math.pow(2,(beta-1)/2);
        sigma = Math.pow((gamma(1+beta)*Math.sin(pi*beta/2)/(gamma((1+beta)/2)*beta*betap2)),(1/beta));
        do{
            pa_pool = Math.random();
        } while (pa_pool<0.01 || pa_pool>0.5 );

    }
    public GDCS(Function f, int D_, int popSize_, int generationsPerRound) {
        this(f,D_,popSize_);
        this.generations=generationsPerRound;
    }

    /** The variation strategy of GDCS is as follows
     * 
     * @param trial
     * 			Train individuals
     * @param noisy
     * 			The mutated individual
     * @param pom
     * 			Function fitness value
     * @param scheme
     * 			Selected variation strategies
     * 			case 1: Gauss-cuckoo variation
     * 			case 2: Primitive cs variation, which �� is from "Peng, H., Deng, C., Wang, H., 
     * 					Wang, W., Zhou, X., Wu, Z.: Gaussian bare-bones cuckoo search algorithm. 
     * 					In: Proceedings of the Genetic and Evolutionary Computation Conference Companion,pp. 93�C94. ACM (2018)".
     * */
    public SiPDEIndividuals generation() throws Exception{
        try {
            if (popSize < minPopulationSize) {
                throw new Exception("popSize can't be smaller than " + minPopulationSize + ".");
            }
        } catch (Exception ex) {
            //Logger.getLogger(DERand1bin.class.getName()).log(Level.SEVERE, null, ex);
        }

        RealVector noisy,noisy2;// =null; //new double[dimensions];
        RealVector trial,trial2;// =null;// new double[dimensions];

        double[] active,active_ran1,active_ran2;          //System.out.println("popSize="+popSize);
        double trialFitness, activeFitness,activeFitness_ran1,trialFitness_ran1,activeFitness_ran2,trialFitness_ran2;

        int biIndex1,biIndex2 = 0;
        double rand1,pa_temp;
        pa_temp = pa_pool;

        int iter=0;
        while (iter<100 ) {
            iter = iter + 1;
            for (int ind = 0; ind < popSize; ind++) {

                trial = new ArrayRealVector(dimensions); //new double[dimensions];
                noisy = new ArrayRealVector(dimensions);//new double[dimensions];

                pa = pa_temp;
                active = population.get(ind).getGeno().toArray();
                activeFitness = population.get(ind).getFitness();
                
                int scheme = get_cuckoos_scheme();

                SiPDEIndividuals best = null;

                switch (scheme) {
                    //Gauss-cuckoo variation
                    case 1:
                        best = population.getBestIndividual();  //Get the current best
                        for (int j = 0; j < dimensions; j++) {
                            double pom = ((best.getGene(j)+active[j])/2)+(Math.abs(best.getGene(j)-active[j]))*(Math.sqrt(1)*rand.nextGaussian());

                            if (pom < function.getMin()) { //
                                pom = function.getMin();
                            }else if (pom > function.getMax()){
                                pom = function.getMax();
                            }

                            noisy.addToEntry(j, pom);
                            trial.addToEntry(j,noisy.getEntry(j));
                        }
                        break;

                    
                    case 2:
                        best = population.getBestIndividual();
                        a = 0.2+0.05*( Math.sqrt(1)*rand.nextGaussian());
                        for (int j = 0; j < dimensions; j++) {
                            temp_u = (Math.sqrt(1)*rand.nextGaussian())*sigma;
                            temp_v = Math.sqrt(1)*rand.nextGaussian();
                            step = temp_u/Math.pow(Math.abs(temp_v),(1/beta));
                            stepsize = a*step*(active[j]-best.getGene(j));
                            double pom = active[j]+stepsize*(Math.sqrt(1)*rand.nextGaussian());

                            if (pom < function.getMin()) { //
                                pom = function.getMin();
                            }else if (pom > function.getMax()){
                                pom = function.getMax();
                            }

                            noisy.addToEntry(j, pom);
                            trial.addToEntry(j,noisy.getEntry(j));
                        }
                        break;
                }
                trialFitness = function.compute(trial.toArray());
                // Replace if trial is better
                if (trialFitness < activeFitness) {
                    SiPDEIndividuals indiv = new SiPDEIndividuals(population, trial);
                    indiv.setFitness(trialFitness);
                    population.set(ind, indiv);
                }
                if (population.get(ind).getFitness() < bestFitness) {
                    bestIndividual = population.get(ind);
                    bestFitness = bestIndividual.getFitness();
                }

            }

            //New nest and old nest preservation creation.
            int[] ran_ind1 = this.random(popSize,popSize);
            int[] ran_ind2 = this.random(popSize,popSize);
            for(int ind=0;ind<popSize;ind++){

                int ind1 = ran_ind1[ind];
                int ind2 = ran_ind2[ind];
                trial2 = new ArrayRealVector(dimensions); //new double[dimensions];
                noisy2 = new ArrayRealVector(dimensions);//new double[dimensions];

                active = population.get(ind).getGeno().toArray();
                activeFitness = population.get(ind).getFitness();

                active_ran1 = population.get(ind1).getGeno().toArray();

                active_ran2 = population.get(ind2).getGeno().toArray();


                rand1 = Math.random();
                for (int d=0; d<dimensions;d++){
                    int k = ((Math.random()>pa) ? 1 : 0);
                    double pom2 = active[d]+(rand1*(active_ran1[d]-active_ran2[d]))*k;

                    if (pom2 < function.getMin()) { //
                        pom2 = function.getMin();
                    }else if (pom2 > function.getMax()){
                        pom2 = function.getMax();
                    }

                    noisy2.addToEntry(d, pom2);
                    trial2.addToEntry(d,noisy2.getEntry(d));

                }
                
                //Calculate individual fitness values
                trialFitness = function.compute(trial2.toArray());
                
                /**
                 * If the trial is better, 
                 * the current pa value is retained, 
                 * otherwise the pa value is dynamically replaced through the candidate pool pa_pool.
                 * 
                 */
                if (trialFitness < activeFitness) {
                    SiPDEIndividuals indiv = new SiPDEIndividuals(population, trial2);
                    indiv.setFitness(trialFitness);
                    population.set(ind, indiv);
                    pa_temp = pa;;  //pa = pa_temp;
                }else {
                    do{
                        pa_pool = Math.random();
                    } while (pa_pool<0.01 || pa_pool>0.5 );
                    pa_temp = pa_pool;
                }
                if (population.get(ind).getFitness() < bestFitness) {
                    bestIndividual = population.get(ind);
                    bestFitness = bestIndividual.getFitness();
                }
            }
        }

        bestFitness=population.getBestIndividual().getFitness();
        bestIndividual = population.getBestIndividual();
        //bestIndividual.geno;
        return bestIndividual;

    }

    public int get_cuckoos_scheme(){
        int scheme;
        if (Math.random()<0.5){
            scheme = 1;
        } else {
            scheme = 2;
        }
        return scheme;
    }



    //Solve the value of gamma
    static double logGamma(double x) {
        double tmp = (x - 0.5) * Math.log(x + 4.5) - (x + 4.5);
        double ser = 1.0 + 76.18009173    / (x + 0)   - 86.50532033    / (x + 1)
                + 24.01409822    / (x + 2)   -  1.231739516   / (x + 3)
                +  0.00120858003 / (x + 4)   -  0.00000536382 / (x + 5);
        return tmp + Math.log(ser * Math.sqrt(2 * Math.PI));
    }
    static double gamma(double x) {
        return Math.exp(logGamma(x));
    }

    /**
     * Randomly generate n different Numbers
     *
     * @param amount
     *            Required quantity
     * @param max
     *            Maximum value (not included). For example, if Max is 100, then 100 cannot be taken, and the range is 0~99.
     * @return array
     */
    public static int[] random(int amount, int max) { if (amount > max) {
        // The total number of Numbers must be less than the maximum number to avoid an endless loop!
        throw new ArrayStoreException( "The amount of array element must smallar than the maximum value !");
    } int[] array = new int[amount]; for (int i = 0; i < array.length; i++) {
        array[i] = -1; // Initialize array
    }
        Random random = new Random();
        int num; amount -= 1; // Array index is 1 less than array length.
        while (amount >= 0) {
            num = random.nextInt(max);
            if (exist(num, array, amount - 1)) {
                continue;
            }
            array[amount] = num;
            amount--;
        }
        return array;
    }
    /**
     * Determines whether a random number exists in an array
     *
     * @param num
     *            Randomly generated Numbers
     * @param array
     *            Array of judgments
     * @param need
     *            The number of need
     * @return Existence is true, nonexistence is false
     */
    private static boolean exist(int num, int[] array, int need) { for (int i = array.length - 1; i > need; i--) {
        // Greater than need is used to reduce the number of cycles and increase efficiency.
        if (num == array[i]) {
            return true;
        }
    }
        return false;
    }
    /**
     * Randomly generate a number
     *
     * @param max
     *            Maximum value (excluding)
     * @return integer
     */
    public static int random(int max) {
        return random(1, max)[0];
    }



    public SubPopulation generationCC(HashMap<Integer, RealVector> pop, RealVector bestind, double bestvalue, List<Integer> subscript, int itermax, ArrayList tracerst) throws IOException {
        return null;
    }

    @Override
    public SiPDEPopulation getPopulation() {
        // TODO Auto-generated method stub
        return population;
    }

    @Override
    public void newRound() {
        // TODO Auto-generated method stub

    }

    public void setParameter(String configName, double value) {
        /*// TODO Auto-generated method stub
        if (configName.equals("F")) {
            F = value;
        } else if (configName.equals("CR")) {
            CR = value;
        }*/
    }
}
