package com.DCGroup;

import cec2010.Function;
import com.txj.dg.dg;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by hadoop on 17-7-7.
 */
public class diff_grouping {
    public Function f;//测试函数
    public diff_grouping(Function f){
        this.f=f;
    }
    public HashMap<Integer, List<Integer>> getGroup(){
        HashMap<Integer, List<Integer>> group=new HashMap<>();
        //RealVector group=new ArrayRealVector();
        int index=0;
        dg d=new dg(f);
        d.Initializeindividual();
        d.diff_grouping();
        group.put(index,d.getSeps());
        for(int i=0;i<d.getNoseps().size();i++){
            //System.out.println("不可分变量"+d.getNoseps().get(i));
            index++;
            group.put(index,d.getNoseps().get(i));
        }
        return group;
    }
    //error
    public HashMap<Integer, List<Integer>> getGroup(int fid){
        HashMap<Integer, List<Integer>> group=new HashMap<>();
        List<Integer> index = new ArrayList<>();
        for(int i=0;i<f.getDimension();i++){
            index.add(i,i);
        }
        //RealVector group=new ArrayRealVector();

        switch (fid){
            case 1:
            case 2:
            case 3:
                group.put(0,new ArrayList<Integer>(index));
                break;
            case 4:
                break;
            case 5:
                break;
            case 6:
                break;
            case 7:
                break;
            case 8:
                break;
            case 9:
                break;
            case 10:
                break;
            case 11:
                break;
            case 12:
                break;
            case 13:
                break;
            case 14:
                break;
            case 15:
                break;
            case 16:
                break;
            case 17:
                break;
            case 18:
                break;
            case 19:
                break;
            case 20:
                break;
        }
        return group;
    }

}
