package com.island


import java.util.Random
import org.apache.commons.math3.linear.{ArrayRealVector, RealVector, Array2DRowRealMatrix, RealMatrix}

import scala.collection.mutable.ArrayBuffer
import scala.math.exp
import breeze.linalg.{Vector, DenseVector}
import org.apache.spark._
import org.apache.spark.SparkContext

import org.apache.spark.SparkContext._
import org.apache.spark.{SparkConf,SparkContext}
import cer2003._
import com.txj.Commons._
import cer2003.Function

/**
 * Created by hadoop on 2015-7-5.
 * 岛模型的基本思想：
 * 1、将一个N*D的种群分发到islands个岛上分别进化generationsPerRound代
 * 2、每一个岛进化完成后，将所有岛上的种群进行回收，然后从每个岛上选取前N/islands个适应度值最优的个体组成一个新的种群
 * 3、再进行下一轮的进化
 * 注意：N是islands的陪数
 */
object DE {
  var min = -100.0
  var max = 100.0

  var D = 100   // 维度
  var N = 10*D  // 个体的数量*D
  val F = 0.5  // 缩放因子
  val CR= 0.9  //交叉概率
  var run=0//函数运行的次数
  var startFun=0//开始的函数
  var endFun=0//结束的函数
  var generationsPerRound=100;//每一轮进化的代数
  var islands=4;//岛的数目是islands+1；20个岛
  //运行的时间与岛的数目有关
  //岛的数目与节点的数量有关
  //交叉概率
  var migrationRounds = 1000//进化的轮数
  val rand = new Random()
  //产生一个rows行和cols列的矩阵
  private def randomMatrix(rows: Int, cols: Int): RealMatrix =
    new Array2DRowRealMatrix(Array.fill(rows, cols)(min+(rand.nextDouble()*(max-min))))

  def generateR(): RealMatrix = {
    randomMatrix(N, D)//产生一个N*D的种群;
  }
  //计算P的适应度值
  //i为行号，ifun为函数，pop为种群 ;求个体的适应度值
  def getPopFitness(i: Int,ifun: Int, pop: RealVector): Double = {
    var popf: RealVector = new ArrayRealVector(N)
    var fitness=0.0
    //调用Java中的函数2
    var f=new Function()
    ifun match {
      case 1 => f = new F1();
      case 2 => f = new F2();
      case 3 => f = new F3();
      case 4 => f = new F4();
      case 5 => f = new F5();
      case 6 => f = new F6();
      case 7 => f = new F7();
      case 8 => f = new F8();
      case 9 => f = new F9();
      case 10 => f = new F10();
      case 11 => f = new F11();
      case 12 => f = new F12();
      case 13 => f = new F13();
    }
    //计算适应度的值
    fitness=f.compute(pop.toArray)
    fitness
  }
  //计算个体的适应度值，并将适应度值存放在个体的最后一列，组成一个新的个体
  def generalFitPop(i: Int,ifun: Int, pop: RealMatrix):Array[Double]={
    //定义一个RealMatrix的变量
    var row=pop.getRowDimension
    var column=pop.getColumnDimension
    //var r = new Array2DRowRealMatrix(row, column)
    var newpop=new Array[Double](column+1)
    //println(newpop.length)
    var fitness=0.0
    //调用Java中的函数2
    var f=new Function()
    ifun match {
      case 1 => f = new F1();
      case 2 => f = new F2();
      case 3 => f = new F3();
      case 4 => f = new F4();
      case 5 => f = new F5();
      case 6 => f = new F6();
      case 7 => f = new F7();
      case 8 => f = new F8();
      case 9 => f = new F9();
      case 10 => f = new F10();
      case 11 => f = new F11();
      case 12 => f = new F12();
      case 13 => f = new F13();
    }
    fitness=f.compute(pop.getRow(i))
    for(j<-0 to pop.getColumnDimension-1){
      newpop(j)=pop.getEntry(i,j)
    }
    newpop(column)=fitness
    newpop
  }

  //将维数存放在变长数组中
  var coordinates = ArrayBuffer[Int]()
  for (i <- 0 to N - 1) {
    coordinates += i
  }
  //临时存放的数组
  val tempcoordinates = ArrayBuffer[Int]()
  coordinates.copyToBuffer(tempcoordinates)

  //进化计算；pop为种群;pop为只读的，不能写
  //返回的类型为（岛的编号、种群）
  def evaluate(island: Int,ifun: Int,pop:RealMatrix,best:Double,generationsPerRound:Int):(Int,RealMatrix,Double) ={
      /*
      动态差分
      1、变异、交叉
      2、选择
       */
    //行数
    var x1 = 0 //随机3个变量，并且互不相等
    var x2 = 0
    var x3 = 0
    val row=pop.getRowDimension()
    val column=pop.getColumnDimension()//最后一列为适应度值

    /*println("==island=="+island+"==start==")
    println("======pop start======")
    for (i<-0 to pop.getRowDimension-1){
      println("==="+i+"===")
      pop.getRow(i).foreach(println)
    }
    println("======pop end======")
    //println("==row=="+row+"==column=="+column)
    println("==island=="+island+"==end==")*/
    var coordinates = ArrayBuffer[Int]()
    for (i <- 0 to row - 1) {
      coordinates += i
    }
    //临时存放的数组
    val tempcoordinates = ArrayBuffer[Int]()
    coordinates.copyToBuffer(tempcoordinates)
    //pop.getRowVector(0)

    var popu=new Array2DRowRealMatrix(row, column)
    for (i<-0 to row-1){
      for (j<-0 to column-1){
        popu.setEntry(i,j,pop.getEntry(i,j))
      }
      //popu.setRow(i,pop.getRow(i))
    }
    var bestFit = popu.getEntry(0, column - 1) //获取第row行column列的值
    var newbest=best

    /*println("===coordinates===")
    coord.foreach(println)
    println("===coordinates end===")*/
    for (iter<-0 to generationsPerRound){//迭代的次数
      for (i <- 0 to row - 1) {
        //新的个体；最后一列为适应度的值
        var newpop = new Array[Double](column)

        coordinates.remove(i)
        var rnd = rand.nextInt(row - 2)
        x1 = coordinates.apply(rnd)

        coordinates.remove(rnd)
        rnd = rand.nextInt(row - 3)
        x2 = coordinates.apply(rnd)

        coordinates.remove(rnd)
        rnd = rand.nextInt(row - 4)
        x3 = coordinates.apply(rnd)

        var k = 0
        k = ((Math.random() * (column-1)) % (column-1)).toInt //随机生成一个数
        //变异、交叉
        for (j <- 0 to column - 2) {
          //
          if ((Math.random() < CR) || (j == k)) {
            newpop(j) = popu.getRow(x1).apply(j) + F * (popu.getRow(x2).apply(j) - popu.getRow(x3).apply(j))
            //判断是否越界
            if (newpop(j) < min || newpop(j) > max) {
              newpop(j) = min + (rand.nextDouble() * (max - min)) //+1
            }
          } else {
            newpop(j) = popu.getRow(i).apply(j)
          }
        }
        //选择；计算newpop的适应度值
        var fitness = 0.0
        //调用Java中的函数2
        var f = new Function()
        ifun match {
          /*case 1 => f = new F1();
          case 2 => f = new F3();
          case 3 => f = new F5();
          case 4 => f = new F9();
          case 5 => f = new F10();
          case 6 => f = new F11();*/
          case 1 => f = new F1();
          case 2 => f = new F2();
          case 3 => f = new F3();
          case 4 => f = new F4();
          case 5 => f = new F5();
          case 6 => f = new F6();
          case 7 => f = new F7();
          case 8 => f = new F8();
          case 9 => f = new F9();
          case 10 => f = new F10();
          case 11 => f = new F11();
          case 12 => f = new F12();
          case 13 => f = new F13();
        }

        fitness = f.compute(newpop.take(column-1))//最后一列为适应度值；所以计算适应度值时，应将最后一列去掉
        newpop(column-1) = fitness
        /*println("======newpop======"+i)
        newpop.foreach(println)
        println("======newpop======"+i)
        println("===fitness==="+fitness)*/
        //println("popu.getRow(i).apply(column - 1)"+popu.getRow(i).apply(column - 1))

        if (fitness < popu.getRow(i).apply(column - 1)) {
          popu.setRow(i, newpop)
          bestFit=fitness
        }
        //将生成三个不同数的数组还原到最初的值
        coordinates.clear()
        tempcoordinates.copyToBuffer(coordinates)
      }
      if(bestFit<newbest){
        newbest=bestFit
      }
      /*
      println("===evaluate start==="+iter+"======")
      for (i<-0 to popu.getRowDimension-1){
        println("==="+i+"===")
        popu.getRow(i).foreach(println)
      }
      println("===evaluate end==="+iter+"======")*/
      //println("======第"+iter+"代的最优值======")
      //println(newbest)
      /*println(pop.getRow(row-1).apply(column-1))*/
    }
    (island,popu,newbest)
  }

  def main(args: Array[String]){
    val minFit = ArrayBuffer[String]() //Set[Double]()//存放每一代的最优值
    System.setProperty("spark.akka.frameSize","1000000")//单位是MB
    System.setProperty("spark.scheduler.mode", "FAIR")
    val sparkConf = new SparkConf()
      .setAppName("BroadcastDE")
      //.setMaster("local")
    //.set("spark.executor.memory","2g")
    //sparkConf.setExecutorEnv("spark.akka.frameSize","1000000")
    val sc = new SparkContext(sparkConf)
    //分区的个数
    var numSlices = if (args.length > 0) args(0).toInt else 2
    D=args(1).toInt//维度 50 50
    N=10*D//500//args(2).toInt//个体的数目10*D// 500*D
    islands=4//岛的数目:从0开始；1表示有两个岛
    //迁移的轮数 :从0开始；1表示有迁移两轮
    migrationRounds=10//进化的轮数//10000//args(3).toInt//
    generationsPerRound=100//每一轮进化的代数
    ///函数运行的次数
    run=args(2).toInt//函数运行的次数:从0开始
    startFun=args(3).toInt//开始的函数 最小值：1
    endFun=args(4).toInt//结束的函数 最大值：7

      //运行第几个函数
      for (ifun <- startFun to endFun) {
        //控制函数
        ifun match {
          /*case 1 => min = -100; max = 100; //F1
          case 2 => min = -100; max = 100; //F3
          case 3 => min = -30; max = 30; //F5
          case 4 => min = -5.12; max = 5.12; //F9
          case 5 => min = -32; max = 32; //F10
          case 6 => min = -600; max = 600; //F11*/
          case 1 => min = -100; max = 100; //F1
          case 2 => min = -10; max = 10; //F2
          case 3 => min = -100; max = 100; //F3
          case 4 => min = -100; max = 100; //F4
          case 5 => min = -30; max = 30; //F5
          case 6 => min = -100; max = 100; //F6
          case 7 => min = -1.28; max = 1.28; //F7
          case 8 => min = -500; max = 500; //F8
          case 9 => min = -5.12; max = 5.12; //F9
          case 10 => min = -32; max = 32; //F10
          case 11 => min = -600; max = 600; //F11
          case 12 => min = -50; max = 50; //F12
          case 13 => min = -50; max = 50; //F13
        }
        //分区
        for (slice<-0 to 1) {
          slice match {
            case 0 => numSlices = 1;
            case 1 => numSlices = 2;
            case 2 => numSlices = 4;
            case 3 => numSlices = 8;
            case 4 => numSlices = 12;
            case 5 => numSlices = 16;
            case 6 => numSlices = 20;
            case 7 => numSlices = 24;
          }
        var path = ""
        //path = "/home/hadoop/sparkDEResult/SparkDE/resultisland20150709"
         //path = "/home/hadoop/sparkDEResult/SparkDE/resultisland20151005"
         // path = "/home/hadoop/sparkDEResult/SparkDE/resultisland20151210"
          //path = "/home/hadoop/sparkDEResult/SparkDE/resultisland20151211" //30
          //path = "/home/hadoop/sparkDEResult/SparkDE/resultisland20151222" //50
          path = "/home/hadoop/sparkDEResult/SparkDE/resultisland20151224" //100
        //函数运行的次数
        for (runk <- 1 to run) {
          minFit.clear()
          //个体的下标
          //var popSub: RealMatrix = new Array2DRowRealMatrix(N, 4)
          ////////////
          //var bestfit = Double.MaxValue

          //矩阵（N*D）N个D维的种群
          val startTime = System.currentTimeMillis() //开始时间
          //对pop进行进化
          val pop1 = generateR()
          /*
          println("===pop1 start===")
          for (i<-0 to pop1.getRowDimension-1){
            println("==="+i+"===")
            pop1.getRow(i).foreach(println)
          }
          println("===pop1 end===")*/
          var pop1RC=sc.broadcast(pop1)
          //计算pop1的适应度值
          var pop2=sc.parallelize(0 until N,numSlices)
                     .map(i=>generalFitPop(i,ifun,pop1RC.value))
                     .collect()
          println("===pop3 start===")
          //pop3在pop1的基础上，添加了一列适应度值

          var pop3= new Array2DRowRealMatrix(pop2)
          var pop3RC=sc.broadcast(pop3)
          //求pop3（初始种群）的最优值
          var best=pop3.getEntry(0,pop3.getColumnDimension-1)
          for (i<-0 to pop3.getRowDimension-1){
            if (pop3.getEntry(i,pop3.getColumnDimension-1)<best){
              best=pop3.getEntry(i,pop3.getColumnDimension-1)
            }
          }
          println("==初始化的最优值=="+best)
          /*println("===pop3 start===")
          for (i<-0 to pop3.getRowDimension-1){
            println("==="+i+"===")
            pop3.getRow(i).foreach(println)
          }
          println("===pop3 end===")*/

          //运行的轮数
          /*
          每一轮的最优值
           */
          var BestFit=0.0

          for (rounds<-0 to migrationRounds) {
            /*
              parallelize(0 to 1)表示两个种群（两个岛）、并行操作
              每一轮进化后，collect将每个岛中的数据进行回收
             */
            //将每一轮进化后的种群collect；存放在generationPop变量中
            //将种群分发到islands-1个岛上
            //分区策略：种群、下标
            val generationPop = sc.parallelize(0 to islands, numSlices)
                                  .map(i => evaluate(i, ifun, pop3RC.value, best, generationsPerRound))
                                  .collect()
              /*
                将每个岛中的种群，按适应度值进行排序
                在每一个岛中选择前p个个体（p=N/M）N为个体数目；M为岛数
                如果N不是M的陪数；则可以随机生成一个个体
                islands:从0开始：0表示一个岛：1表示两个岛
             */
            //将第一个岛中的最优值赋值给BestFit
            BestFit=generationPop.apply(0)._3
            val p = N / (islands + 1)

            for (i <- 0 to islands) {//岛的数目
              //获取岛的编号
              //println("岛的编号" + generationPop.apply(i)._1)
              //获取岛的种群

              val temporarypop = generationPop.apply(i)._2

              //temp为一个二维数组
              val temp = temporarypop.getData
              //1、对temporarypop进行排序;对种群的适应度值按升序排列
              sort.sortDoubleArray(temp, temporarypop.getColumnDimension() - 1)
              //2、获取排序后的前p个个体、并将其赋值给pop3
              //println("岛中的数据 start")
              /*
              i=1:
              p=3:
             */
              for (j <- i * p to i * p + p - 1) {
               // println("===" + j + "=== j%p=" + j % p)
                //temp.apply(j % p).foreach(println)
                //获取前p个个体；第一个岛中的个体替换前p个个体；第二个岛中的个体替换后p个个体
                pop3.setRow(j, temp.take(p).apply(j % p))
              }
              //求最优值
              if(generationPop.apply(i)._3<best){
                best=generationPop.apply(i)._3
              }
              /*if(generationPop.apply(i)._3<BestFit){
                BestFit=generationPop.apply(i)._3
              }*/
             // println("岛中的数据 end")
              //println("岛中的前"+p+"个数据 start")
              //(temp.take(p).apply(2).foreach(println))//.apply(i).foreach(println)
              //println("岛中的前p个数据 end")
            }
            pop3RC=sc.broadcast(pop3)
            /*println("===pop3进化之后的值 start===")
            for (i <- 0 to pop3.getRowDimension - 1) {
              println("===" + i + "===")
              pop3.getRow(i).foreach(println)
            }
            println("===pop3进化之后的值 end===")*/
          }
          //最后是否再求pop3的最优值
          for (i<-0 to pop3.getRowDimension-1){
            if (pop3.getEntry(i,pop3.getColumnDimension-1)<best){
              best=pop3.getEntry(i,pop3.getColumnDimension-1)
            }
          }


          /////////////////////////////////////////////////////////////////////
          ////下面的代码需进行修改

          val endTime = System.currentTimeMillis() //结束时间
          //存放值为：F：函数、run：运行次数、slices：分区、最优值、运行时间（毫秒）
          minFit += "F" + (ifun) +"  run:" + (runk) + "  " + "-Slices-" +
            numSlices+"  "+ BestFit.toString + "   " + (endTime - startTime) + "\n"
          //将运行结果存放在本地
          Common.appendMethodB(path, minFit.toString)
        }
      }
    }
    sc.stop()
  }
}
