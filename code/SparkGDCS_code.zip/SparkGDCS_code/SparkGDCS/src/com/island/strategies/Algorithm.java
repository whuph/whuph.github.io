package com.island.strategies;

import java.io.IOException;


import cer2003.FitnessFunction;
import cec2010.Function;

import com.island.SparkStrategies.SiPDEPopulation;
import org.apache.commons.math3.linear.RealVector;
import scala.Serializable;

/**
 * @author txj
 */
public abstract class Algorithm  implements Serializable {
    protected int generationsPerRound;//每一轮进化的代数
    /**
     * Minimal population size for algorithm to work
     * 最小的种群大小？
     */
    protected int minPopulationSize;
    /**
     * Number of dimensions of given fitness function
     * 维度
     */
    protected int dimensions;
    /**
     * Population size
     * 种群的个体数
     */
    protected int popSize;
    /**
     * Optimized function
     * 适应度函数
     */
    protected FitnessFunction function;

    ///cec2010
    protected Function function1;
    /**
     * Inidivual with the best fitness, returned by generation()
     * 最优个体
     */
    protected RealVector bestIndividual;
    /**
     * Population of Individuals for use in algorithm
     * 种群
     */
    protected populationRM population;

    /**
     * Fitness of bestIndividual
     * 最优的适应度值
     */
    protected double bestFitness = Double.MAX_VALUE;

    /**
     * Constructor
     * 构造函数
     */
    public Algorithm() {
        population = new populationRM();
    }

    /**
     * Runs one generation/cycle of algorithm
     * 运行每一轮的进化算法
     * @return Best Individual from the population
     * @throws IOException
     */
    abstract public RealVector generation() throws IOException;

    abstract public RealVector generation(int ind) throws IOException;
    //,RealVector trialFit
    abstract public RealVector generationCC(RealVector bestind,int l,int u,int[] subscript) throws IOException;

    /**
     * 获取种群
     * @return population used in algorithm
     */
    abstract public populationRM getPopulation();

    /**
     * 复制种群
     * Sets main population to given Population
     * @param population_
     */
    public void setPopulation(populationRM population_,int generationsPerRound) {
        population = population_;
        popSize = population.size();
        this.generationsPerRound=generationsPerRound;
    }

    /**
     * 开始新的一轮
     * newRound() is called at the end of each round (after emigration)
     * and can be used to alter algorithm configuration or left blank
     * if no alteration is not needed.
     */
    abstract public void newRound();

    /**
     * 设置进化的参数
     * Sets externally defined algorithm specific parameters.
     * @param configName Name of the parameter to set
     * @param value Value of parameter
     */
    abstract public void setParameter(String configName, float value);
}