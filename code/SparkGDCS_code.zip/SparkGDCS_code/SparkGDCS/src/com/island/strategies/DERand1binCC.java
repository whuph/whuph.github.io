package com.island.strategies;


import cec2010.Function;

import com.java.tools.RandSet;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;

import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Dann
 */
public class DERand1binCC extends AlgorithmCC { //DifEv

    //settings
    static protected double F = 0.5;   //F – mutacní konstanta [0, 2]
    										//不断变异
    static protected double CR = 0.9;  //CR – práh krizení [0, 1]
    										//越限
    //F，CR的值会传进来了，覆盖其数值

//    static public Population population = new Population();



    public DERand1binCC(Function f, int D_, int popSize_) {
        dimensions = D_+1;
        popSize = popSize_;
        function = f;
        population.setFunction(f);
        minPopulationSize = 2;
    }

    //协同下的进化
    /*
    最优个体，bestind
    l：子种群区域的下限
    u：子种群区域的上限
    subscript：为分组后的下标
    indFit：为整个种群的适应度值 RealVector
    ,RealVector indFit
     */
    public  RealVector generationCC(RealVector bestind,int l,int u,int[] subscript){
        try {
            if (popSize < minPopulationSize) {
                throw new Exception("popSize can't be smaller than " + minPopulationSize + "");
            }
        } catch (Exception ex) {
            Logger.getLogger(DERand1binCC.class.getName()).log(Level.SEVERE, null, ex);
        }
        RealVector rand1, rand2, rand3;
        double[] noisy = new double[dimensions];
        double[] trial = new double[dimensions];
        //存放个体的适应度值
        double[] active;
        int rand1Index = 0;
        int rand2Index = 0;
        int rand3Index = 0;
        double trialFitness,activeFitness;
        //最优值best
        double best=bestind.getEntry(bestind.getDimension()-1);
        //临时最优个体
        RealVector IndBest=new ArrayRealVector(dimensions);

        bestIndividual=new ArrayRealVector(bestind.getDimension());
        //System.out.println("==开始l=="+l+"==u==" + u);
        for (int bi=0;bi<bestind.getDimension();bi++){
            bestIndividual.setEntry(bi,bestind.getEntry(bi));
        }

        //bestIndividual=bestind;
        //进化的代数
        for (int iter=0;iter<generationsPerRound;iter++) {
            /*int bestindex=0;
            for (int i=l;i<=u;i++){
                IndBest.setEntry(bestindex,bestind.getEntry(subscript[i]));
                bestindex++;
            }*/
            for (int ind = 0; ind < popSize; ind++) {
                //trial = new double[dimensions];
                //noisy = new double[dimensions];
                //获取第ind个个体；最后一个是适应度的值
                active = population.get(ind).toArray();
                //当前个体的适应度值
                //activeFitness = indFit.getEntry(ind);
                //获取最后一列的值为适应度值
                activeFitness=population.get(ind).getEntry(dimensions-1);
                //System.out.println("==indFit.getEntry("+ind+")=="+indFit.getEntry(ind));
                //System.out.println("activeFitness=="+activeFitness);
                //  Choose random
                /*
                do {
                    rand1Index = (int) (Math.random() * popSize);

                } while (rand1Index == ind);

                do {
                    rand2Index = (int) (Math.random() * popSize);
                } while (rand1Index == ind || rand2Index == rand1Index);
                do {
                    rand3Index = (int) (Math.random() * popSize);
                } while (rand1Index == ind || rand3Index == rand1Index || rand3Index == rand2Index);
                */

                /*rand1 = population.get(rand1Index);
                rand2 = population.get(rand2Index);
                rand3 = population.get(rand3Index);*/
                int[] randindex= RandSet.randomArray1(0,popSize-1,3,ind);//生成3个不同的随机数
                rand1 = population.get(randindex[0]);
                rand2 = population.get(randindex[1]);
                rand3 = population.get(randindex[2]);

                int k=(int)(Math.random()*dimensions);
                //System.out.println("变异、交叉之后的值  开始");
                for (int j = 0; j < dimensions-1; j++) {
                    //随机个体
                    double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + rand3.getEntry(j);
                    //最优个体
                    //double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + IndBest.getEntry(j);
                    //如果pop越界，则重新生成一个个体
                    if (pom < function.getMin() || pom > function.getMax()) {
                        pom = function.getRandomValueInDomains(j);
                    }
                    noisy[j] = pom;
                    //交叉运算
                    trial[j] = (Math.random() < CR || j==k) ? noisy[j] : active[j];
                }
                //System.out.println("变异、交叉之后的值 结束");
                //变异、交叉之后的值
                /*
                将变异、交叉之后的个体与最优个体进行合并
                按照对应的下标进行替换
                 */
                //////////////////修改////////////////////////
                int index=0;
                for (int i=l;i<=u;i++){
                    bestind.setEntry(subscript[i],trial[index]);
                    index++;
                }
                /*int rndIndex=0;//随机数；在0到dimension-1之间
                int Dim=bestind.getDimension();
                for (int m=0;m<bestind.getDimension()-1;m++){
                    do {
                        rndIndex = (int) (Math.random() * Dim);
                    }while (rndIndex<l && rndIndex>u);
                    if(m<l && m>u){
                        bestind.setEntry(m,trial[rndIndex]);
                    }
                }*/
                //将bestind中除l至u之间的值不变，其他值顺序打乱
                //System.out.prRMintln("最优个体的维度为"+ bestind.getDimension());
                //将bestind中其他的下标重排
                /*
                    l u为组
                    subscript   0～D-1
                                2,5,9,10,
                 */
                //计算当前个体的适应度
                trialFitness =function.compute(bestind.getSubVector(0,bestind.getDimension()-1).toArray()); //function.evaluate(trial);
                trial[dimensions-1]=trialFitness;
                //将当前的适应度值赋值给bestind
                //bestind.setEntry(bestind.getDimension()-1,activeFitness);
                bestind.setEntry(bestind.getDimension()-1,trialFitness);
                //将bestind中的值进行替换 ==结束==
                /*
                activeFitness：当前代个体的适应度值
                trialFitness：下一代个体的适应度值
                如果满足下列条件，则
                求局部最优
                 */
                //输出population


                if (trialFitness < activeFitness) {
                    population.set(ind, new ArrayRealVector(trial));//将第ind个个体替换掉
                }


                //求全局最优
                if (population.get(ind).getEntry(dimensions - 1) < best) {
                    for (int popj=0;popj<population.get(ind).getDimension();popj++) {
                        bestIndividual.setEntry(popj, population.get(ind).getEntry(popj));
                    }
                    best = bestIndividual.getEntry(dimensions - 1);
                }
            }
            //System.out.println("待进化的轮数"+iter+"end");
            /*System.out.println("最优个体的适应度值" + best);
            System.out.println("进化后的种群"+iter+"轮");
            for (int ind = 0; ind < popSize; ind++) {
                for (int col=0;col<dimensions;col++) {
                    System.out.print(population.getPop().getEntry(ind, col)+"  ");
                }
                System.out.println();
            }*/
        }

        //System.out.println("==结束l=="+l+"最优个体的适应度值" + best);
        //System.out.println("进化的最优个体的最优值为"+best);
        /*for (int  i=0;i< bestIndividual.getDimension();i++){
            System.out.print(bestIndividual.getEntry(i) + " ");
        }*/
        //System.out.println();
        return bestIndividual;
    }

    @Override
    public RealVector generationCC(RealVector bestind, List<Integer> subscript) throws IOException {
        try {
            if (popSize < minPopulationSize) {
                throw new Exception("popSize can't be smaller than " + minPopulationSize + "");
            }
        } catch (Exception ex) {
            Logger.getLogger(DERand1binCC.class.getName()).log(Level.SEVERE, null, ex);
        }
        RealVector rand1, rand2, rand3;
        double[] noisy = new double[dimensions];
        double[] trial = new double[dimensions];
        //存放个体的适应度值
        double[] active;
        int rand1Index = 0;
        int rand2Index = 0;
        int rand3Index = 0;
        double trialFitness,activeFitness;
        //最优值best
        double best=bestind.getEntry(bestind.getDimension()-1);
        //临时最优个体
        RealVector IndBest=new ArrayRealVector(dimensions);

        bestIndividual=new ArrayRealVector(bestind.getDimension());
        //System.out.println("==开始l=="+l+"==u==" + u);
        for (int bi=0;bi<bestind.getDimension();bi++){
            bestIndividual.setEntry(bi,bestind.getEntry(bi));
        }

        //bestIndividual=bestind;
        //进化的代数
        for (int iter=0;iter<generationsPerRound;iter++) {
            /*int bestindex=0;
            for (int i=l;i<=u;i++){
                IndBest.setEntry(bestindex,bestind.getEntry(subscript[i]));
                bestindex++;
            }*/
            for (int ind = 0; ind < popSize; ind++) {
                //trial = new double[dimensions];
                //noisy = new double[dimensions];
                //获取第ind个个体；最后一个是适应度的值
                active = population.get(ind).toArray();
                //当前个体的适应度值
                //activeFitness = indFit.getEntry(ind);
                //获取最后一列的值为适应度值
                activeFitness=population.get(ind).getEntry(dimensions-1);
                //System.out.println("==indFit.getEntry("+ind+")=="+indFit.getEntry(ind));
                //System.out.println("activeFitness=="+activeFitness);
                //  Choose random
                /*rand1 = population.get(rand1Index);
                rand2 = population.get(rand2Index);
                rand3 = population.get(rand3Index);*/
                int[] randindex= RandSet.randomArray1(0,popSize-1,3,ind);//生成3个不同的随机数
                rand1 = population.get(randindex[0]);
                rand2 = population.get(randindex[1]);
                rand3 = population.get(randindex[2]);

                int k=(int)(Math.random()*dimensions);
                //System.out.println("变异、交叉之后的值  开始");
                for (int j = 0; j < dimensions-1; j++) {
                    //随机个体
                    double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + rand3.getEntry(j);
                    //最优个体
                    //double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + IndBest.getEntry(j);
                    //如果pop越界，则重新生成一个个体
                    if (pom < function.getMin() || pom > function.getMax()) {
                        pom = function.getRandomValueInDomains(j);
                    }
                    noisy[j] = pom;
                    //交叉运算
                    trial[j] = (Math.random() < CR || j==k) ? noisy[j] : active[j];
                }
                //System.out.println("变异、交叉之后的值 结束");
                //变异、交叉之后的值
                /*
                将变异、交叉之后的个体与最优个体进行合并
                按照对应的下标进行替换
                 */
                //////////////////修改////////////////////////
                int index=0;//bestind
                for (int i=0;i<subscript.size();i++){
                    bestIndividual.setEntry(subscript.get(i),trial[index]);
                    index++;
                }
                /*int rndIndex=0;//随机数；在0到dimension-1之间
                int Dim=bestind.getDimension();
                for (int m=0;m<bestind.getDimension()-1;m++){
                    do {
                        rndIndex = (int) (Math.random() * Dim);
                    }while (rndIndex<l && rndIndex>u);
                    if(m<l && m>u){
                        bestind.setEntry(m,trial[rndIndex]);
                    }
                }*/
                //将bestind中除l至u之间的值不变，其他值顺序打乱
                //System.out.prRMintln("最优个体的维度为"+ bestind.getDimension());
                //将bestind中其他的下标重排
                /*
                    l u为组
                    subscript   0～D-1
                                2,5,9,10,
                 */
                //计算当前个体的适应度bestind
                trialFitness =function.compute(bestIndividual.getSubVector(0,bestind.getDimension()-1).toArray()); //function.evaluate(trial);
                //trialFitness =function.compute(trial); //function.evaluate(trial);

                trial[dimensions-1]=trialFitness;
                //将当前的适应度值赋值给bestind
                //bestind.setEntry(bestind.getDimension()-1,activeFitness);
                bestIndividual.setEntry(bestIndividual.getDimension()-1,trialFitness);
                //将bestind中的值进行替换 ==结束==
                /*
                activeFitness：当前代个体的适应度值
                trialFitness：下一代个体的适应度值
                如果满足下列条件，则
                求局部最优
                 */
                //输出population


                if (trialFitness < activeFitness) {
                    population.set(ind, new ArrayRealVector(trial));//将第ind个个体替换掉
                }


                //求全局最优
                if (population.get(ind).getEntry(dimensions - 1) < best) {
                    for (int popj=0;popj<population.get(ind).getDimension();popj++) {
                        bestIndividual.setEntry(popj, population.get(ind).getEntry(popj));
                    }
                    best = bestIndividual.getEntry(dimensions - 1);
                }
            }
            //System.out.println("待进化的轮数"+iter+"end");
            /*System.out.println("最优个体的适应度值" + best);
            System.out.println("进化后的种群"+iter+"轮");
            for (int ind = 0; ind < popSize; ind++) {
                for (int col=0;col<dimensions;col++) {
                    System.out.print(population.getPop().getEntry(ind, col)+"  ");
                }
                System.out.println();
            }*/
        }

        //System.out.println("==结束l=="+l+"最优个体的适应度值" + best);
        //System.out.println("进化的最优个体的最优值为"+best);
        /*for (int  i=0;i< bestIndividual.getDimension();i++){
            System.out.print(bestIndividual.getEntry(i) + " ");
        }*/
        //System.out.println();
        return bestIndividual;
    }


    //island  变异、交叉、选择
    public RealVector generation() {
        try {
            if (popSize < minPopulationSize) {
                throw new Exception("popSize can't be smaller than " + minPopulationSize + "");
            }
        } catch (Exception ex) {
            Logger.getLogger(DERand1binCC.class.getName()).log(Level.SEVERE, null, ex);
        }
        RealVector rand1, rand2, rand3;
        double[] noisy = new double[dimensions];
        double[] trial = new double[dimensions];
        double[] active;
        int rand1Index = 0;
        int rand2Index = 0;
        int rand3Index = 0;
        double trialFitness, activeFitness;
        //进化的代数
        for (int iter=0;iter<generationsPerRound;iter++) {
            //ind为个体的数量
            for (int ind = 0; ind < popSize; ind++) {
                trial = new double[dimensions];
                noisy = new double[dimensions];
                //获取第ind个个体；最后一个是适应度的值
                active = population.get(ind).toArray();
                activeFitness = population.get(ind).getEntry(dimensions - 1);
                //  Choose random
                /*
                do {
                    rand1Index = (int) (Math.random() * popSize);
                    rand1 = population.get(rand1Index);
                } while (rand1Index == ind);

                do {
                    rand2Index = (int) (Math.random() * popSize);
                } while (rand1Index == ind || rand2Index == rand1Index);
                rand2 = population.get(rand2Index);

                do {
                    rand3Index = (int) (Math.random() * popSize);
                } while (rand1Index == ind || rand3Index == rand1Index || rand3Index == rand2Index);
                rand3 = population.get(rand3Index);
                */
                int[] randindex= RandSet.randomArray1(0,popSize-1,3,ind);//生成3个不同的随机数
                rand1 = population.get(randindex[0]);
                rand2 = population.get(randindex[1]);
                rand3 = population.get(randindex[2]);

                int k=(int)(Math.random()*dimensions);
                for (int j = 0; j < dimensions - 1; j++) {
                    double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + rand3.getEntry(j);
                    //System.out.println("function.getMinRestriction(" + j + ")=" + function.getMinRestriction(j));
                    if (pom < function.getMin() || pom > function.getMax()) {
                        pom = function.getRandomValueInDomains(j);
                    }
                    noisy[j] = pom;
                    trial[j] = (Math.random() < CR|| j==k) ? noisy[j] : active[j];
                }
                //在进行适应度值计算的时候，将使用
                trialFitness = function.compute(trial);
                trial[dimensions - 1] = trialFitness;

                // Replace if trial is better
                if (trialFitness < activeFitness) {
                    population.set(ind, new ArrayRealVector(trial));//将第ind个个体替换掉
                }

                if (population.get(ind).getEntry(dimensions - 1) < bestFitness) {
                    bestIndividual = population.get(ind);
                    bestFitness = bestIndividual.getEntry(dimensions - 1);
                }
            }
            //ind为个体的数量
            /*
            System.out.println("第"+iter+"轮");
            for (int ind = 0; ind < popSize; ind++) {
                for (int col=0;col<dimensions;col++) {
                    System.out.print(population.getPop().getEntry(ind, col)+"  ");
                }
                System.out.println();
            }*/
            //System.out.println("最优个体的适应度值" + bestFitness);
        }

        return bestIndividual;
    }
    //no
    public RealVector generation(int ind) {
        return bestIndividual;
    }

    public populationCC getPopulation() {
        return population;
    }

    public void newRound() {
        System.out.println("newRound");
    }

    public void setParameter(String configName, float value) {
        if (configName.equals("F")) {
            F = value;
        } else if (configName.equals("CR")) {
            CR = value;
        }
    }
}
