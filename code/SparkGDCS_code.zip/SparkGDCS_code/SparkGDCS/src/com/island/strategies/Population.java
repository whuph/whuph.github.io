package com.island.strategies;

import cer2003.FitnessFunction;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;

import java.util.*;

/**
 * Created by hadoop on 15-7-8.
 */
public class Population {

    protected FitnessFunction function;
    public int dimensions;
    protected ArrayList<Individuals> individualsList = new ArrayList();

    protected RealMatrix pop=new Array2DRowRealMatrix();//种群

    protected Individuals bestIndividual = null;
    protected boolean sorted = false;
    protected boolean migrationFlag;
    protected int key; //population key
    Random rng;

    /**
     * Constructs Population with given Individuals
     *
     * @param population ArrayList of Individuals who will become the new Population
     */
    public Population(ArrayList<Individuals> population) {
        individualsList = population;
        migrationFlag = false;
        initializeJADEConstants();
    }

    /**
     * Constructs Population with given Individuals
     *
     * @param population ArrayList of Individuals who will become the new Population
     */
    public Population(RealMatrix population) {
        pop = population;
        migrationFlag = false;
        initializeConstants();
    }

    /**
     *  Parameterless constructor
     */
    public Population() {
        migrationFlag = false;
        initializeConstants();//
    }

    /**
     *
     * @param i Dimension from which the restriction is returned
     * @return lower restriction of given dimension
     */
    public double getMinRestriction(int i) {
        return function.getMinRestriction(i);
    }

    /**
     *
     * @param i Dimension from which the restriction is returned
     * @return upper restriction of given dimension
     */
    public double getMaxRestriction(int i) {
        return function.getMaxRestriction(i);
    }

    /**
     * Sets all Individuals to random values
     */
    public void randomize() {
        for (Individuals ind : individualsList) {
            ind.randomize();
            evaluateIndividual(ind);
        }
    }

    /**
     * 计算第i个个体的适应度值
     * @param i Individual to be evalueated
     * @return fitness of the Individual
     */
    public double evaluateIndividual(Individuals i) {
        double fit = function.evaluate(i.getGenoVect().toArray());
        i.setFitness(fit);
        return fit;
    }

    /**
     *
     * @return ArrayList of Individuals from Population
     */
    public ArrayList<Individuals> getPopulation() {
        return individualsList;
    }

    /**
     *
     * @return ArrayList of Individuals from Population
     */
    public RealMatrix getPop() {
        return pop;
    }

    /**
     * Sets fitness function of this Population which is later used to create Individuals and determine their fitness
     * @param ff FitnessFunction extending class
     */
    public void setFitnessFunction(FitnessFunction ff) {
        function = ff;
    }

    /**
     * Set Individuals population to this Population. Needed after adding external Individuals.
     */

    public void resetIndividualsPopulation(){
        for(Individuals ind : individualsList)
            ind.setPopulation(this);
    }

    /**
     * Migrating flag marks if the population is used for evolution or for migration
     */
    public void setMigratingFlag() {
        migrationFlag = true;
    }

    /**
     *
     * @return whether the population is used for migration
     */
    public boolean getMigratingFlag() {
        return migrationFlag;
    }

    /**
     * Each population has its unique key given by the framework at initialization by this function.
     *
     * @param k integer to set the key to.
     */
    public void setKey(int k) {
        key = k;
    }

    /**
     * @return the key (id) of the population
     */
    public int getKey() {
        return key;
    }

    /**
     * Ads one Individual to population
     *
     * @param ind Individual to add
     */
    public void add(Individuals ind) {
        individualsList.add(ind);
        sorted = false;
    }



    /**
     * Ads one random Individual to population
     */
    public void addRandomIndividual(int d) {
        if(function != null) {
            double min, max;
            RealVector values = new ArrayRealVector(d);
            //RealVector
            for (int k = 0; k < d; k++) {
                min = function.getMinRestriction(k);
                max = function.getMaxRestriction(k);
                //  Get random double within range.
                values.setEntry(k,min + (Math.random() * ((max - min) + 1)));
            }

            Individuals ind = new Individuals(this, values);
            ind.setFitness(function.evaluate(values.toArray()));
            add(ind);
            sorted = false;
        }
    }

    /**
     * Ads a number of random Individuals to population
     *生成一个n*d的种群
     * @param n number of Individuals to add
     */
    public void addRandomIndividuals(int n, int d) {
        for(int i = 0; i< n; i++) addRandomIndividual(d);
    }

    /**
     *
     * @param j Index of Individual to return
     * @return Individual with index j
     */
    public Individuals get(int j) {
        return individualsList.get(j);
    }

    /**
     * Sets one Individual with index j, rewriting the old one
     *
     * @param j Index of new Individual
     * @param ind Individual to be added
     */
    public void set(int j, Individuals ind) {
        individualsList.set(j, ind);
        sorted = false;
    }

    /**
     * Makes new Population from Individuals given in the individuals parameter
     *
     * @param individuals ArrayList of new Individuals
     */
    public void setPopulation(ArrayList<Individuals> individuals) {
        individualsList = individuals;
        sorted = false;
        sort();
    }

    /**
     * @return population size
     */
    public int size() {
        return individualsList.size();
    }

    /**
     * Removes one Individual from Population with given index i
     *
     * @param i Index of removed Individual
     */
    public void drop(int i) {
        individualsList.remove(i);
    }

    /**
     * Clears Population by removing all Individuals
     */
    public void clear() {
        individualsList.clear();
        sorted = false;
    }

    protected class IndividualListFitnessComparator implements Comparator {
        public int compare(Object o1, Object o2) {
            double f1 = ((double[])o1)[0];
            double f2 = ((double[])o2)[0];

            if (f1 > f2) {
                return 1;
            } else if (f1 < f2) {
                return -1;
            } else {
                return 0;
            }
        }
    }

    /**
     *  Sorts the population by fitness
     */
    public void sort() {
        double tmp[][] = new double[individualsList.size()][2];

        for (int i = 0; i < individualsList.size(); i++) {
            tmp[i][0] = individualsList.get(i).getFitness();
            tmp[i][1] = i;
        }

        Arrays.sort(tmp, new IndividualListFitnessComparator());
        for (int i = 0; i < tmp.length; i++) {
            int ind = (int)(tmp[i][1]);
            individualsList.get(ind).setIndex(i);
        }

        sorted = true;
    }

    /**
     * Get population index of the best Individual from ArrayList of Individuals.)
     * @param list ArrayList of Individuals to search in.
     * @return best Individual from given ArrayList
     */
    static public int getBestIndex(ArrayList<Individuals> list) {
        int i = 0, min_n = 0;
        double min = Double.POSITIVE_INFINITY;

        for (int j = 0; j < list.size(); j++, i++) {
            if (list.get(j) != null && list.get(j).getFitness() < min) {
                min = list.get(j).getFitness();
                min_n = i;
            }
        }
        return min_n;
    }

    /**
     *
     * @return best individual of existing population.
     */
    public Individuals getBestIndividual() {
        if (sorted && bestIndividual != null) {
            return bestIndividual;
        } else {
            return individualsList.get(getBestIndex());
        }
    }

    /**
     * Accepts immigrants into existing population.
     *
     * @see acceptImmigrantsMethod
     * @param immigrants Immigrating Population
     * @param method One of Population.acceptImmigrantsMethod (REPLACE_WORST, REPLACE_BEST, REPLACE_RANDOM, NO_REPLACE).
     */
    public void acceptImmigrants(Population immigrants, acceptImmigrantsMethod method) {

        switch (method) {

            case REPLACE_WORST:

                if (!sorted) {
                    sort();
                }

                for (int i = 0, j = individualsList.size() - 1, n = -1; i < immigrants.size(); i++, j--) {
                    n = getIndexFromFitnessOrder(j);
                    if (n != -1) {
                        individualsList.set(n, immigrants.get(i));
                    }
                }
                break;
            case REPLACE_BEST:

                if (!sorted) {
                    sort();
                }

                for (int i = 0, n = -1; i < immigrants.size() && i < individualsList.size(); i++) {
                    n = getIndexFromFitnessOrder(i);
                    individualsList.set(n, immigrants.get(i));
                }
                break;
            case REPLACE_RANDOM:
                Double r = 0.0;
                for (int i = 0; i < immigrants.size(); i++) {
                    r = Math.random() * individualsList.size();
                    individualsList.set(r.intValue(), immigrants.get(i));
                }
                break;
            case NO_REPLACE:
                for (int i = 0; i < immigrants.size(); i++) {
                    individualsList.add(immigrants.get(i));
                }
                break;
        }

        sorted = false;
    }

    /**
     * Expels immigrants from evolved population.
     *
     * @see expelEmigrantsMethod
     * @param nMigratingIndividuals Number of emigrants
     * @param method One of Population.expelEmigrantsMethod (EXPEL_BEST, EXPEL_RANDOM).
     */
    public Population getEmigrants(int nMigratingIndividuals, expelEmigrantsMethod method) {
        Population temp = new Population();
        int index;

        switch (method) {
            case EXPEL_BEST: {

                for (int i = 0; i < nMigratingIndividuals; i++) {
                    index = getIndexFromFitnessOrder(i);
                    temp.add(individualsList.get(index));
                }
                break;
            }
            case EXPEL_RANDOM: {
                Double r = 0.0;

                for (int i = 0; i < nMigratingIndividuals; i++) {
                    r = Math.random() * individualsList.size();
                    index = getIndexFromFitnessOrder(r.intValue());
                    temp.add(individualsList.get(index));
                }
                break;
            }
            case EXPEL_BEST_AND_RANDOM: {
                index = getIndexFromFitnessOrder(0);
                temp.add(individualsList.get(index)); //add best

                Double r = 0.0;
                for (int i = 0; i < nMigratingIndividuals; i++) {
                    r = Math.random() * individualsList.size();
                    index = getIndexFromFitnessOrder(r.intValue());
                    temp.add(individualsList.get(index)); //add random
                }
                break;
            }
        }

        return temp;
    }

    /**
     * Get Individual by his population index
     * @param i Order of the Individual by fitness
     * @return Index of Individual
     */
    public int getIndexFromFitnessOrder(int i) {
        if(!sorted) {
            sort();
        }

        int n = 0;
        for (Individuals ind : individualsList) {
            if (ind.getIndex() == i) {
                return n;
            }

            n++;
        }
        return -1;
    }

    @Override
    public Population clone() {
        return new Population(individualsList);
    }

    public Iterator<Individuals> iterator() {
        return individualsList.iterator();
    }

    public int compareTo(JADEPopulation o) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String toString() {
        String str = "";
        str += "Population key: " + key + "\n";
        str += "Size: "+size() + "\n";
        str += "Best fitness: " + getBestIndividual().getFitness() + "\n";

        str += "uF: " + uF + "\n";
        str += "uCR: " + uCR + "\n";

        for (int i = 0; i < individualsList.size(); i++) {
            str += "\n\rIndividual " + i + " : " + individualsList.get(i).toString();
            str += ", F: " + Fs[i];
            str += ", CR: " + CRs[i];
        }

        return str;
    }

    /**
     * Get population index of the best Individual
     * @return
     */
    public int getBestIndex() {
        int min_n = 0;
        double min = Double.POSITIVE_INFINITY;

        for (int j = 0; j < individualsList.size(); j++) {
            if (individualsList.get(j) != null && individualsList.get(j).getFitness() < min) {
                min = individualsList.get(j).getFitness();
                min_n = j;
            }
        }

        return min_n;
    }

    /**
     * Determines how immigrating individuals are handled.
     */
    public static enum acceptImmigrantsMethod {

        /**
         * Replace individuals with worst value
         */
        REPLACE_WORST,
        /**
         * Replace individuals with best value
         */
        REPLACE_BEST,
        /**
         * Replace random individuals
         */
        REPLACE_RANDOM,
        /**
         * Adds immigrants to population by increasing its size
         */
        NO_REPLACE
    }

    /**
     * Determines how emigrating individuals are chosen.
     */
    public static enum expelEmigrantsMethod {

        /**
         * Migrate best individuals
         */
        EXPEL_BEST,
        /**
         * Migrate random individuals
         */
        EXPEL_RANDOM,
        /**
         * Migrate 1 best individual and some random individuals
         */
        EXPEL_BEST_AND_RANDOM,
    }

    //JADE1 methods
    protected double[] Fs; //F for every individual
    protected double[] CRs; //CR for every individual

    double p; //percento najlepsich pre krizenie
    int numP; //pocet najlepsich pre krizenie, vychadza z hodnoty p
    double uF, uCR, c;

    void initializeJADEConstants() {
        uCR = 0.5;
        uF = 0.6;
        c = 0.1;
        p = 0.2; //20%
        numP = (int) Math.round(((double)individualsList.size()) * p);
        rng = new Random(System.currentTimeMillis());
    }

    void initializeConstants() {
        uCR = 0.5;
        uF = 0.6;
        c = 0.1;
        p = 0.2; //20%
        numP = (int) Math.round(((double)pop.getRowDimension()) * p);
        rng = new Random(System.currentTimeMillis());
    }

    public double getuCR() {
        return uCR;
    }

    public double getuF() {
        return uF;
    }

    public void updateuCR(double SCR, double nSCR)
    {
        if(nSCR != 0) {
            uCR = (1 - c)*uCR + c*(SCR / nSCR);
        }
    }

    public void updateuF(double SF, double SF2)
    {
        if(SF != 0) {
            uF = (1 - c)*uF + c*(SF2 / SF);
        }
    }

    protected double nextGaussian(double mean, double variance) {
        return rng.nextGaussian()*Math.sqrt(variance)+mean;
    }

    public void computeFandCR() {
        Fs = new double[individualsList.size()];
        CRs = new double[individualsList.size()];

        for(int i = 0; i < individualsList.size(); i++)
        {
            CRs[i] = nextGaussian(uCR, 0.1); //initiate CRs...
        }

        double rndProb = 0.34;
        for(int i = 0; i < individualsList.size(); i++) //toto bolo inak...
        {
            if(rng.nextDouble() < rndProb)
                Fs[i] = nextGaussian(uF, 0.1);
            else
                Fs[i] = rng.nextDouble() * 1.2;
        }
    }

    public double getF(int index) {
        return Fs[index];
    }

    public double getCR(int index) {
        return CRs[index];
    }
}
