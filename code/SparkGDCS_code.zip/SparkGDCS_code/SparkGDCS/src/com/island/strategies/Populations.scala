package com.island.strategies

import cer2003.FitnessFunction
import org.apache.commons.math3.linear.{ArrayRealVector, RealVector, Array2DRowRealMatrix, RealMatrix}

import scala.util.Random



/**
 * Created by hadoop on 15-7-7.
 * 种群
 */
class Populations {
    var population:RealMatrix=null//种群
    var bestIndividual:RealVector=null//最优个体
    var function:FitnessFunction=null//适应度函数的类
    //var rand=new Random()//随机数
    var N:Int=0//维度
    var D:Int=0//个体数目
    var key:Int=0//岛的编号
    var random = new Random(10)
  //RealMatrix

    private def randomMatrix(rows: Int, cols: Int) ={
      /*var min=0.0
      var max=0.0
      var value=0.0
      if (function!=null){
          var newpop=new Array[Array[Double]](rows)(cols+1)
          for(i<-0 to rows-1){
              min=function.getMinRestriction(i)
              max=function.getMaxRestriction(i)
              for(j<-0 to cols){
                newpop.apply(i).update(j,min+(random.nextDouble()*(max-min)))
              }
              value=function.evaluate(newpop.apply(i))
          }
          this.population=new Array2DRowRealMatrix(Array.fill(rows, cols)(min+(random.nextDouble()*(max-min))))
          population
      }*/
    }


    /*def generateR(): RealMatrix = {
      randomMatrix(N, D)//产生一个N*D的种群;
    }*/
    def setFunction(fitnessFunction: FitnessFunction): Unit ={
      this.function=fitnessFunction
    }
}