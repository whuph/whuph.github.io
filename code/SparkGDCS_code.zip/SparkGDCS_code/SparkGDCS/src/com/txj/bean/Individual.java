package com.txj.bean;

import java.util.ArrayList;

/**
 * Created by hadoop on 15-5-21.
 */
public class Individual {
    //生成一个d维的个体
    public ArrayList<Double> addRandomIndividual(int d) {
        double min=-100, max=100;
        ArrayList<Double> values = new ArrayList<Double>();
        for (int k = 0; k < d; k++) {
            values.add(min + (Math.random() * ((max - min) + 1)));
        }
        return values;
    }
    //产生n个d维的个体
    public ArrayList<ArrayList<Double>> generalPopulation(int n,int d){
        ArrayList<ArrayList<Double>> population=new ArrayList<ArrayList<Double>>();
        for (int k=0;k<n;k++) {
            population.add(addRandomIndividual(d));
        }
        return population;
    }
}
