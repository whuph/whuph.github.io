package com.util;

import cer2003.FitnessFunction;
import com.island.SparkStrategies.Algorithm;


import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 * Created by hadoop on 16-11-15.
 */
public class newInstanceObject{
    public static Algorithm get(FitnessFunction function, int dimensions,int popSize) throws NoSuchMethodException {
        Algorithm algorithm=null;
        Class clsAlg= Algorithm.class;
        Class[] clss = new Class[]{FitnessFunction.class, int.class, int.class};   // Argument types
        //实例化测试函数的参数
        Object[] args = new Object[]{function, dimensions, popSize};   // Arguments for contructor

        Constructor constr = clsAlg.getConstructor(clss);
        try {
            algorithm = (Algorithm) constr.newInstance(args);
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        return algorithm;
    }
}
