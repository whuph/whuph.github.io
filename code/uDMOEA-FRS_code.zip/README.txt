Welcome to Hu Peng's Homepage at https://whuph.github.io/
Our research papers and corresponding codes are publicly available on this website.

If you find this code useful in your work, please cite the following paper "Shi Wu, Hu Peng, Zhuo Liu, Lin Liu, Lianglin Cao, Zhijian Wu. A micro dynamic multi-objective evolutionary algorithm with flexible response strategy. Swarm and Evolutionary Computation, 2026, 100: 102243."

This implementation is based on the PlatEMO platform: Ye Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, "PlatEMO: A MATLAB Platform for Evolutionary Multi‑Objective Optimization", IEEE Computational Intelligence Magazine, 2017, 12(4): 73‑87.
