function [prob, theta, W] = CDC(Global, Population, S2_index, niche, prob, theta, W, Z)
%% Cluster-based Dynamic Controller

    %% Probability Adjustment
    if prob >= 5
        prob = prob - 2;
    elseif prob <= -5
        prob = prob + 2;
    end
    
    %% Identify the largest and smallest niches
    nicheList = {S2_index, niche{1}, niche{2}};
    lenList   = cellfun(@length, nicheList);
    
    [~, maxIdx] = max(lenList);
    [~, minIdx] = min(lenList);
    
    max_var = nicheList{maxIdx};
    min_var = nicheList{minIdx};
    
    %% Average PBI
    meanPBI1 = Fun_meanPBI(Population, max_var, theta, W, Z);
    meanPBI2 = Fun_meanPBI(Population, min_var, theta, W, Z);

    %% Adaptive
    if meanPBI1 > meanPBI2
        theta = 1;
        prob = prob + 1;
        if Global.gen > Global.maxgen * 0.6 && prob <= -3
            W = updateWeight(Global.N, Global.M);
        end
    else
        theta = theta + 0.2;
        prob = prob - 1;
    end

end