function Val = CalPBI(popObj, idx, theta, W, Z)
%% Calculate PBI

    [N, ~] = size(popObj);
    normW   = sqrt(sum(W(idx,:).^2,2));
    normP   = sqrt(sum((popObj-repmat(Z,N,1)).^2,2));
    CosineP = sum((popObj-repmat(Z,N,1)).*repmat(W(idx,:),N,1),2)./normW./normP;
    d1 = normP.*CosineP;
    d2 = normP.*sqrt(1-CosineP.^2);
    Val = d1 + theta*d2;
end