function P3=Diversity_introduction_strategy(Population,N,upper,lower,r)
%% Diversity_introduction_strategy

if r <= 0 || r > 3
    r = 2;       
else
    r = ceil(r);
end

P3_decs=Population.decs;
for i=1:N
    p=randi(2);
    alfa=1/10^randi(r)*randi(9);
    sigma=std(Population(i).dec);
    belta=alfa+1/(sqrt(2*pi)*sigma)*exp(-Population(i).dec(:).^2/(2*sigma^2))/10^randi(r);
    belta=belta';
if p==1
    P3_decs(i,:)=P3_decs(i,:)+belta;    
else
    P3_decs(i,:)=P3_decs(i,:)-belta;
end
end
P3_decs=Boundary_Repair(P3_decs,lower,upper);
P3=INDIVIDUAL(P3_decs);
end
