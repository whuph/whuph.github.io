function Population = EnvironmentalSelection_non_micro_Environment(Population, N)
%% Environmental Selection

    %% Population selection
    nonPop    = Population(NDSort(Population.objs,1)==1);
    nND   = length(nonPop);
    if nND < N
        domPop = Population(NDSort(Population.objs,1) > 1);
        domPop(Truncation(domPop.objs, length(domPop) - N + nND)) = [];
        Population = [nonPop domPop];
    else
        Population = nonPop;
    end
    Population    = Population(randperm(length(Population)));
    PCObj = Population.objs;
    
    %% Population maintenance
    if length(Population) > N
        % Normalization
        fmax  = max(PCObj,[],1);
        fmin  = min(PCObj,[],1);
        PCObj = (PCObj-repmat(fmin,nND,1))./repmat(fmax-fmin,nND,1);
        % Determine the radius of the niche
        d  = pdist2(PCObj,PCObj);
        d(logical(eye(length(d)))) = inf;
        sd = sort(d,2);
        r  = mean(sd(:,min(3,size(sd,2))));
        R  = min(d./r,1);
        % Delete solution one by one
        while length(Population) > N
            [~,worst]  = max(1-prod(R,2));
            Population(worst)  = [];
            R(worst,:) = [];
            R(:,worst) = [];
        end
    end

function Del = Truncation(PopObj,K)
% Select part of the solutions by truncation

    %% Truncation
    Distance = pdist2(PopObj,PopObj);
    Distance(logical(eye(length(Distance)))) = inf;
    Del = false(1,size(PopObj,1));
    while sum(Del) < K
        Remain   = find(~Del);
        Temp     = sort(Distance(Remain,Remain),2);
        [~,Rank] = sortrows(Temp);
        Del(Remain(Rank(1))) = true;
    end
end
    
end