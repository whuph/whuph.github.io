function [Archive] = Flexible_scaling_mechanism(Global,Archive)
%% Flexible scaling mechanism

    predictionX = Archive.decs;

    %% Generation Strategy (Based on Cauchy Mutation)
    for i = 1 : Global.N
        for j = 1 : 5
            Archive(5*(i-1)+j) = INDIVIDUAL(cauchy_mutation(predictionX(i, :), Global.lower, Global.upper));
        end
    end
  
    
    %% Selection Strategy 
   [Archive, ~, ~] = EnvironmentalSelection_AGEMOEA2(Archive, Global.N);

end

