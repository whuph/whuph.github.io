function meanPBI = Fun_meanPBI(Population, idx, theta, W, Z)
%% mean PBI

    len_idx = length(idx);
    sumPBI  = 0;
    for i = idx
        sumPBI = sumPBI + sum(CalPBI(Population.objs, i, theta, W, Z));
    end
    meanPBI = sumPBI / len_idx;
end

