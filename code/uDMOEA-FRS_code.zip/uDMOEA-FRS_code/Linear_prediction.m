function [PopM,D] = Linear_prediction(S1,New_S,New_Size,Population,Global,Last_C,Last_b,Ct,b)
%% PREDICTION STRATEGY BASED ON MOVEMENT VECTOR
% This function predicts the next population by estimating the moving step
% of center points and boundary points between two consecutive environments.

	%% 1. Calculate the moving step of center and boundary points
	% Moving step of the center point
    Dt = Ct - Last_C; 
	
	% Moving step of each boundary point
    D = zeros(Global.M,Global.D);
    for i = 1 : Global.M
        D(i,:) = b(i,:) - Last_b(i,:);
    end
	
	
	%% 2. Predict individuals in the center niche
    S1_decs = S1.decs;
    Next_S1_decs = S1.decs;
    for i = 1 : Global.D
        for j = 1 : size(S1,1)
            Next_S1_decs(j,i) = S1_decs(j,i) + Dt(i);
        end
    end
	
	% Repair boundary to keep variables within the search range
    Next_S1_decs = Boundary_Repair(Next_S1_decs,Global.lower,Global.upper);
    Next_S1 = INDIVIDUAL(Next_S1_decs);
	
	
	%% 3. Predict individuals in the boundary niches
	p = []; % Store predicted boundary individuals
    for i = 1 : Global.M
      pnew_decs = Population(New_S{1,i}).decs;
      for j = 1 : Global.D
        for k = 1 : New_Size(i)
            pnew_decs(k,j) = pnew_decs(k,j) + D(i,j);
        end
      end
	  
      p = [p;pnew_decs];
      p = Boundary_Repair(p,Global.lower,Global.upper);
      
    end 
	
	Next_S = INDIVIDUAL(p);
    PopM = [Next_S1  Next_S];

end

