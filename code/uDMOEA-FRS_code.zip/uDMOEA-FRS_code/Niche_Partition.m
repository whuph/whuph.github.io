function [S1, S, Size, Ct, b, C_index] = Niche_Partition(Global, Population)
% Niche Partition: Construct center and boundary niches
% Function: Partition niches based on population center, boundary points and radius
% input：Global      - Global parameters structure
%        Population  - Population individuals
% output：S1         - Individuals in the center niche
%         S          - Index set of boundary niches
%         Size       - Size of each boundary niche
%         Ct         - Center point in decision space
%         b          - Boundary points in decision space
%         C_index    - Index of individuals in the center niche

%% 1. Calculate center, boundary points and niche radius in objective space
FCt = mean(Population.objs);
[~, boundaryIndices] = max(Population.objs, [], 1);
objBoundary = Population(boundaryIndices).objs;

numObj = Global.M;
squaredDiff = zeros(numObj, numObj);
distance   = zeros(numObj, 1);

for i = 1 : numObj
    squaredDiff(i, :) = (FCt - objBoundary(i, :)).^2;
    distance(i) = sqrt(sum(squaredDiff(i, :)));
end

% Radius of the center niche
centerRadius = max(distance) / 2;

% Radius of boundary niches
boundaryRadius = zeros(numObj, 1);
for i = 1 : numObj
    boundaryRadius(i) = distance(i) / 2;
end

%% 2. Center and boundary points in decision space
Ct = mean(Population.decs, 1);

% Pre-allocate memory for boundary points
b = zeros(numObj, Global.D);
for i = 1 : numObj
    b(i, :) = Population(boundaryIndices(i)).decs;
end

%% 3. Partition the center niche
distCenter = pdist2(Ct, Population.decs);
S1 = Population(distCenter <= centerRadius);
C_index = find(distCenter <= centerRadius);

%% 4. Partition boundary niches
S = cell(1, numObj);            % Index of individuals in each boundary niche
Size = zeros(1, numObj);       % Number of individuals in each boundary niche

for i = 1 : numObj
    distBound = pdist2(b(i, :), Population.decs);
    S{i} = find(distBound <= boundaryRadius(i));
    Size(i) = length(S{i});
end

end