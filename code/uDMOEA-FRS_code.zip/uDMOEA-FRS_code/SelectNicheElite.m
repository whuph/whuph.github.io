function [S2, S2_index, New_S, New_Size] = SelectNicheElite(Global, Population, S1, S, Size, C_index)
% Niche Elite Selection (Center Niche + Boundary Niches)
% Input:
%   Global      - Global parameters structure
%   Population  - Current population
%   S1          - Individuals in the center niche
%   S           - Index set of boundary niches
%   Size        - Size of each boundary niche
%   C_index     - Index of individuals in the center niche
% Output:
%   S2          - Selected elite individuals from center niche
%   S2_index    - Index of elite individuals from center niche
%   New_S       - Selected indices from boundary niches
%   New_Size    - Size of selected boundary niches

%% ============== Elite Selection for Center Niche =================
[FrontNo, ~] = NDSort(S1.objs, Population.cons, Global.N);
[~, Rank] = sort(CrowdingDistance(S1.objs, FrontNo), 'descend');

% Calculate the adaptive selection number k
k = round(Global.N * (length(S1) / (length(S1) + sum(Size))));

% Select elite individuals
S2 = S1(Rank(1:k));       % Selected elite individuals
S2_index = C_index(Rank(1:k)); % Corresponding indices


%% ===================== Elite Selection for Boundary Niches =====================
New_S = cell(1, length(Size));
New_Size = zeros(1, length(Size));

for i = 1 : length(Size)
    [FrontNo,~] = NDSort(Population(S{i}).objs, Population.cons, Global.N);
    [~, RankI] = sort(CrowdingDistance(Population(S{i}).objs, FrontNo), 'descend');
    
    k2 = round(Global.N * (Size(i) / (length(S1) + sum(Size))));
    
    New_S{i} = RankI(1:k2);
    New_Size(i) = length(RankI(1:k2));
end

end