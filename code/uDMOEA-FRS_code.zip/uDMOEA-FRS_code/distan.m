function [ v ] = distan(X2,X1)
%distance solves hadama distance between the set X1 and X2 
[n,~]=size(X2);   
D=pdist2(X2,X1);
[min_D,~]=min(D,[],2);
v=sum(min_D)/n;
v=v*v/n;
end

