function uDMOEA_FRS(Global)
% <algorithm> <V>
% Dynamic multi-objective optimization evolutionary algorithm
% prob --- 0 --- environment indicator
% theta --- 1 --- penalty factor

% This is a simple demo of μDMOEA_FRS
%--------------------------------------------------------------------------------------------------------
% If you find this code useful in your work, please cite the following paper " Shi Wu, Hu Peng, 
% Zhuo Liu, Lin Liu, Lianglin Cao, Zhijian Wu. A micro dynamic multi-objective evolutionary algorithm with 
% flexible response strategy. Swarm and Evolutionary Computation, 2026".
%--------------------------------------------------------------------------------------------------------
% This function is implmented by Shi Wu.
%--------------------------------------------------------------------------------------------------------
%--------------------------------------------------------------------------------------------------------
% More information can visit Hu Peng's homepage: https://whuph.github.io/index.html
%--------------------------------------------------------------------------------------------------------
%------------------------------- DMO --------------------------------------------------------------------

%% Parameter Settings
Memory_Set=[];K=0;t_size=4;M_num=5; 
prob = 0;
theta = 1;
		
%% Generate the weight vectors
[W, Global.N] = UniformPoint(Global.N, Global.M);
		
%% Generate random population
Global.Initialization();

%% Evolutionary optimization
while Global.NotTermination
	% Detecting changes in the environment using re-evaluation methods
    if Global.hasChanged()
        % Memory storage strategy
        [Memory_Set,K] = Memory_store(Global.Population,Memory_Set,t_size,M_num,K);  
        Ct = mean(Global.Population.decs,1);
        if Global.gen-50==Global.problem.tauT  		
            [~, index] = max(Global.Population.objs,[],1);
            % Initialise the boundary point matrix
			b = zeros(length(index),Global.D);
            for i = index
                b(i, :) = Global.Population(i).decs; 
            end
            index = randperm(Global.N);
            Re_Pop_decs=repmat(Global.lower,ceil(Global.N/2),1)+rand(ceil(Global.N/2),Global.D).*repmat((Global.upper-Global.lower),ceil(Global.N/2),1);
            Global.Population(index(1:ceil(Global.N/2))) = INDIVIDUAL(Re_Pop_decs);   %Initialise by selecting half the individuals at random

        elseif Global.gen-50>Global.problem.tauT
            Z = min(Global.Population.objs,[],1);
            [S1, S, Size, Ct, b, C_index] = Niche_Partition(Global, Global.Population);
			[S2, S2_index, New_S, New_Size] = SelectNicheElite(Global, Global.Population, S1, S, Size, C_index); % Elite individual selection based on niches
            [prob, theta, W] = CDC(Global, Global.Population, S2_index, New_S, prob, theta, W, Z);
            [PopM, ~] = Linear_prediction(S2, New_S, New_Size, Global.Population, Global, Last_C, Last_b, Ct, b);
            [PopS,~]=Memory_solution_introduction(Memory_Set,Global.N,Global.D,Global.lower,Global.upper); % Memory solution introduction strategy
            PopQ = Diversity_introduction_strategy(Global.Population, Global.N, Global.upper, Global.lower, prob + theta); 
            P_archive = [PopM PopS PopQ];
            Global.Population = EnvironmentalSelection_AGEMOEA2(P_archive, Global.N);
            Global.Population = Flexible_scaling_mechanism(Global, Global.Population);

        end
        Last_C = Ct;
        Last_b = b;
    end

    %% Static Optimizer
    Offspring  = RMMEDA(Global.Population);
    if prob >= 0
        [Global.Population,~,~] = EnvironmentalSelection_micro_Environment([Global.Population, Offspring], Global.N);
    else
        Global.Population = EnvironmentalSelection_non_micro_Environment([Global.Population, Offspring], Global.N);
    end

end
