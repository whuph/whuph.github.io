function W = updateWeight(N, M)
% Generate a set of diverse distributed points on the unit hyperplane
	
    W = eye(M,M);
	W = [W;ones(1,M)/M];
    
	W2 = rand(500,M);
    % Normalization
	W2 = W2./repmat(sum(W2,2),1,size(W2,2));
	
	while size(W,1) < N
		index = find_index_with_largest_distance (W,W2);
		W(size(W,1)+1,:)=W2(index,:);
		W2(index,:)=[];
	end	
    W = max(W,1e-6);
end

function index = find_index_with_largest_distance (W, W2)
    Distance = pdist2(W2,W);
    Temp     = sort(Distance,2);
    [~,Rank] = sortrows(Temp);
    index=Rank(length(Rank));
end