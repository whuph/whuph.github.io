from ulab import numpy as np
from public.GLOBAL import Global
from public.utils import getWeights, determineNeighbors, calcTche, randperm, repair, gaussianMutation, updateEP, pdist2, \
    updateWeight
from public.operators import DE, GA
from public.extends import ndarray_slice
import heapq
from random import random
from gc import collect

'''
title: Micro Multi-Objective Evolutionary Algorithm with Piecewise Strategy
author: Hu Peng, Kevin Kong, Qingfu Zhang
programmed: Kevin Kong
date: 2023-02-25
running environment: Esp32 single-chips program powered by micro python with ulab
firmware: 
    - filename: micropython-ulab-eps32-generic.bin
    - micropython: v1.18-160-g0a217624e-dirty
    - ulab: 5.0.4-2D-c
comment: 
We are very pleased that you are interested in uMOEA, and you are free to
use the code for research purpose. The code is run on the esp32 micro-controller 
and powered by micro python. Therefore, for this low-power operating environment,
we have optimized the code to improve program efficiency. If you encounter any problems
or better suggestions, you can contact us.
email: hu_peng@whu.edu.cn
'''


def uMOEA(Global: Global, **parameters) -> (np.ndarray, np.ndarray):
    """
    Micro Multi-Objective Evolutionary Algorithm with Piecewise Strategy
    :param Global {Global} Global object
    :param n {int} the size of evolutionary population
    :param T {int} the size of neighbor
    :param tau {int} the size of time slice
    :param cauchy {float} convergence indicator
    :param delta {float} max flag of convergence
    :param gamma {float} tolerance rate
    :param s {float} scaling parameter of penalty function
    :return (archive,Objs) {(ndarray,ndarray)}
    """
    # ======== Initialization ========
    # 1. Initialize weight vectors
    (Global.N, W) = getWeights(Global.N, Global.problem.M)
    # 2. Detect the neighbours of each solution
    B = determineNeighbors(W, parameters["T"])
    # 3. Generate random population to fill the archive
    archive = Global.initialization()
    Objs = Global.problem.calcObjs(archive)
    # 4. Update ideal point
    Z = np.min(Objs, axis=0).reshape((1, Global.problem.M))
    # 5. Evolutionary process division
    queue = list(range(Global.N))
    # ======== Evolution ========
    flag = 0
    EP = np.array([])  # External population
    EPObjs = np.array([])  # External population objective values
    while Global.NotTermination():
        print("not termination:", Global.evaluation, Global.max_evaluations)
        Offsprings = np.array([])
        OffspringsObjs = np.array([])
        # 1. Calculate diversity indicator
        phi = sum(calcTche(Objs, W, Z))
        # 2. Get evolutionary population index
        evol_pop_index = [heapq.heappop(queue) for _ in range(parameters["n"])]
        # 3. Timeslice Evolutionary
        for t in range(parameters["tau"]):
            # 4. Evolve each evolutionary population
            for i in evol_pop_index:
                '''
                DE:
                '''
                if random() < 0.9:
                    # Select 4 parents from its neighbors
                    P = randperm(B[evol_pop_index[i]].tolist(), 4)
                else:
                    # Select 4 parents from archive
                    P = randperm(list(range(Global.N)), 4)
                select = np.zeros((3, Global.problem.D))
                for j in range(3):
                    select[j, :] = archive[P[1 + j], :]
                # Generate offspring
                offspring = DE(archive[P[0], :], select)
                
                
                '''
                GA:
                
                if random() < 0.9:
                    # Select 2 parents from it neighbors
                    P = randperm(B[evol_pop_index[i]].tolist(), 2)
                else:
                    # Select 2 parents from archive
                    P = randperm(list(range(Global.N)), 2)
                # Generate offspring
                
                offspring = GA(ndarray_slice(archive, P, range(Global.problem.D)), Global.problem.lb, Global.problem.ub)
                offspring = offspring[0] # half 
                '''
                del select
                collect()
                
                # Mutation
                offspring = gaussianMutation(offspring, Global.problem.lb, Global.problem.ub)
                # Repair
                offspring = repair(offspring, Global.problem.lb, Global.problem.ub)
                # Calculate objective function value
                Obj = Global.problem.calcObjs(offspring.reshape((1, Global.problem.D)))
                # Update ideal point
                Z = np.min(np.concatenate((Z, Obj), axis=0), axis=0).reshape((1, Global.problem.M))
                # Replace poor performed solutions in parents' neighbors
                # constraint violation degree of parents
                con_old = parameters["s"] * (Global.problem.calcCon(
                    ndarray_slice(archive, P, range(Global.problem.D))
                    ) ** 2)
                # constraint violation degree of offspring
                con_new = parameters["s"] * (Global.problem.calcCon(offspring.reshape((1, Global.problem.D))) ** 2) 
                old = calcTche(ndarray_slice(Objs, P, range(Global.problem.M)),
                               ndarray_slice(W, P, range(Global.problem.M)),
                               Z)
                old += con_old
                new = calcTche(Obj,
                               ndarray_slice(W, P, range(Global.problem.M)),
                               Z)
                new += con_new
 
                compared = new <= old
                for (index, isBetter) in enumerate(compared):
                    if isBetter:
                        archive[P[index], :] = offspring
                        Objs[P[index], :] = Obj
                # Save offspring
                offspring = offspring.reshape((1, Global.problem.D))
                Obj = Obj.reshape((1, Global.problem.M))
                if len(Offsprings) == 0 and len(OffspringsObjs) == 0:
                    Offsprings = offspring
                    OffspringsObjs = Obj
                else:
                    Offsprings = np.concatenate((Offsprings, offspring), axis=0)
                    OffspringsObjs = np.concatenate((OffspringsObjs, Obj), axis=0)
                del new, old, compared, P, offspring, Obj
                collect()

        # ======== Update EP ========
        
        if Global.evaluation / Global.max_evaluations <= 0.9:
            if len(EP) == 0 and len(EPObjs) == 0:
                (EP, EPObjs) = updateEP(archive, Objs, Offsprings, OffspringsObjs, Global.N)
            else:
                (EP, EPObjs) = updateEP(EP, EPObjs, Offsprings, OffspringsObjs, Global.N)
        
        # ======== Update weight ========
        
        curPhi = sum(calcTche(Objs, W, Z))  # Calculate current convergence indicator
        if np.std([phi, curPhi]) <= parameters["cauchy"]:
            flag += 1
            if flag >= (Global.max_evaluations / parameters["n"]) * parameters["delta"]:
                # Have converged
                dis = pdist2(Objs, Objs)
                for i in range(Global.N):
                    dis[i, i] = float("inf")
                nearest = np.min(dis, axis=1)
                
                del dis
                collect()
                
                crowded = 0
                if sum(nearest == 0) != 0:
                    # Must be crowded
                    crowded = 1
                    nus = sum(nearest == 0)
                else:
                    nearestMean = np.mean(nearest)
                    normalVal = nearest / nearestMean
                    nus = sum(normalVal < parameters["gamma"])
                    if sum(normalVal < parameters["gamma"]) >= 1:
                        crowded = 1
                    del nearestMean, normalVal
                    collect()
                if crowded == 1:
                    # The algorithm has converged and population is crowded, it is time to update weights
                    (archive, Objs, W) = updateWeight(archive, Objs, W, Z, EP, EPObjs, nus)
                    B = determineNeighbors(W, parameters["T"])  # Re-detect the neighbours of each solution
                    flag = 0  # Reset the flag
        else:
            phi = curPhi
            
            del curPhi
            collect()
            
            flag = 0
        
        # ======== Push pop ========
        for index in evol_pop_index:
            heapq.heappush(queue, index)

    return (archive, Objs)

