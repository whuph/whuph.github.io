from problems.SAGOP import *
from problems.MicroGrid import *
from public.GLOBAL import Global
from algorithms.uMOEA import uMOEA
from ulab import numpy as np
import utime
from machine import Pin
import os

'''
main program

:date 2022-03-04
:author Kevin Kong
'''
# Experiment settings
N = 20  # archive size
max_evaluations = 100  # maximum number of evaluations
runTimes = 2  # run times
# Algorithm parameters
parameters = {
    "n": 5,
    "T": 5,
    "tau": 4,
    "cauchy": 1e-4,
    "delta": 0.06,
    "gamma": 0.4,
    "s": 10
}

# Import problem
MOP_name = "MG"
MOP = eval(MOP_name + "()")
print("Problem " + MOP_name)
try:
    os.stat("./result/%s-%d"%(MOP_name, max_evaluations))
except:
    os.mkdir("./result/%s-%d"%(MOP_name, max_evaluations))
# Run
cost_time = np.zeros(runTimes)

led2 = Pin(2, Pin.OUT)
led2.value(1)
for i in range(runTimes):
    begin = utime.ticks_ms() # begin to record run time
    # Create experiment object
    g = Global(MOP, uMOEA, N, max_evaluations)
    print("Run %d" % (i + 1))
    (_, Objs) = g.run(**parameters)
    end = utime.ticks_ms() # finish recording run time
    cost_time[i] = (end - begin) # ms, run time
    np.save("result/%s-%d/%s[%d]%d-%d.npy" % (MOP_name, max_evaluations, MOP_name, N, max_evaluations, i + 1), Objs)
led2.value(0)
print("total cost time:%fms" % np.sum(cost_time))
print("average cost time:%fms" % np.mean(cost_time))
print("standard deviation:%f" % np.std(cost_time))