from ulab import numpy as np
from public.PROBLEM import Problem
from gc import collect

class MG(Problem):
    """
    MicroGrid optimization problem
    :date 2022-05-25
    :author Kevin Kong
    """

    def __init__(self) -> None:
        # problem parameters
        self.Global = None
        self.parameters = {
            
        }
        # ------------------
        D = 20
        M = 2
        lb = np.concatenate((np.zeros(8),np.ones(4)*15,np.ones(4)*5, np.ones(4)*-60))  # lower bound
        ub = np.concatenate((np.ones(4)*30,np.ones(4)*50,np.ones(4)*65,np.ones(4)*40,np.ones(4)*60))  # upper bound

        super().__init__(D, M, lb, ub)
        del D, M, lb, ub
        collect()

    def setGlobal(self, Global):
        """
        property setter
        :param Global {Global}
        """
        self.Global = Global

    def calcObjs(self, x) -> np.ndarray:
        """
        Calculate the objective function value
        :param x {ndarray} decision variable
        :return objs {ndarray} objective function value
        """
        (N, _) = x.shape
        objs = np.zeros((N, self.M))
        
        L = 9.7  # natural gas low calorific value
        C_f = 3.88  # unit price of fuel
        # f1
        # Calculate C_MT
        lamda_MT = 0.753 * (x[:, 4*2+1:4*3]/65)**3 - 0.3095 * (x[:,4*2+1:4*3]/65)**2 + \
            0.4174*x[:,4*2+1:4*3]/65 + 0.1068  # power generation efficiency
        C_MT = np.sum(C_f / L * x[:,4*2+1:4*3] / lamda_MT, axis=1)

        # Calculate C_FC
        lamda_FC = 0.4  # power generation efficiency
        C_FC = np.sum(C_f / L * x[:, 4*3+1:4*4] / lamda_FC, axis=1)

        # free memory and garbage collection
        del lamda_MT, lamda_FC, L
        collect() 

        # C_D
        c_k = np.concatenate((np.ones((N, 4))*66500, np.ones((N, 4))*23700, \
            np.ones((N, 4))*13060, np.ones((N, 4))*42750, np.ones((N, 4))*1570\
            ), axis=1)  # Installation cost of distributed power source k
        f_k = np.concatenate((np.ones((N, 4))*5, np.ones((N, 4))*0.3, \
            np.ones((N, 4))*6, np.ones((N, 4))*3, np.ones((N, 4))*1.2\
            ), axis=1)  # Capacity factor of distributed power source k
        r = np.concatenate((np.ones((N, 4))*0.025, np.ones((N, 4))*0.03, \
            np.ones((N, 4))*0.035, np.ones((N, 4))*0.015, np.ones((N, 4))*0.025\
            ), axis=1)
        l = np.concatenate((np.ones((N, 4))*22, np.ones((N, 4))*20, \
            np.ones((N, 4))*20, np.ones((N, 4))*20, np.ones((N, 4))*10\
            ), axis=1)
        k_me = np.concatenate((np.ones(4)*0.0096, np.ones(4)*0.0296, np.ones(4)*0.088, \
            np.ones(4)*0.087, np.ones(4)*0.004
            ))
        C_D = np.sum(c_k / (8760*f_k) * (r*(1+r)**l) / ((1+r)**l-1), axis=1)
        # C_M
        C_M = np.sum(x*k_me, axis=1)
        # free memory and garbage collection
        del c_k, f_k, r, l, k_me, C_f
        collect()

        # C_g
        e_buy = np.array([0.18, 0.38, 0.8, 0.7])  # electricity purchase price
        e_sel = np.array([0.16, 0.2, 0.6, 0.48])  # electricity sell price
        P_load = np.array([80, 200, 320, 201])  # total load demand
        temp = np.zeros((N, 4))
        for i in range(4):
            temp[:, i] = P_load[i] - x[:, i] - x[:, i+4] - x[:, i+4*2] - x[:, i+4*3] - x[:, i+4*4]
        P_buy = (temp>=0) * temp
        P_sel = (temp<0) * temp
        C_buy = e_buy * P_buy
        C_sel = e_sel * P_sel
        C_g = np.sum(C_buy+C_sel, axis=1)
        # obtained f1
        objs[:, 0] = C_MT + C_FC + C_D + C_M + C_g

        del C_MT, C_FC, C_D, C_M, C_g, e_buy, e_sel, P_load, temp, P_sel, C_buy, C_sel
        collect()

        # f2
        A_1 = np.array([0.184, 0.00928, 0.4819]) # DG emission factor matrix MT
        A_2 = np.array([0.635, 0, 0.0023])  # DG emission factor matrix FC
        B = np.array([0.889, 0.000315, 0.0235])  # Matrix of various pollution emission coefficients of large power grids
        Ksi = np.array([0.004125, 0.875, 1.25]) # processing cost
        a = np.sum(A_1*Ksi)
        b = np.sum(A_2*Ksi)
        c = np.sum(B*Ksi)
        objs[:, 1] = np.sum(x[:, 4*2:4*3]*a + x[:, 4*3:4*4]*b + P_buy*c, axis=1)

        del A_1, A_2, B, Ksi, a, b, c
        collect()

        # Increase evaluation number
        self.Global.evaluation += N

        return objs

    def calcCon(self, x) -> np.ndarray:
        """
        Calculate degree of constraint violation
        """
        # Without constraint
        return 0
