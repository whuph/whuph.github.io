import math
from ulab import numpy as np
from public.PROBLEM import Problem


class SAGO1(Problem):
    """
    Semi-autogenous grinding optimization problem 1
    :date 2022-03-04
    :author Kevin Kong
    """

    def __init__(self) -> None:
        # problem parameters
        self.Global = None
        self.parameters = {
            "c1": 0.028,  # system parameter
            "c2": 0.15,  # system parameter
            "D": 9.8,  # mill inner diameter
            "alpha": 30,  # inclination angle of SAG mill
            "v": 0.3,  # the volume percentage of minerals and water in the machine
            "N": 0.7,  # the ratio of the actual speed of the motor to the rated power speed
            "l": 20,  # mineral Grinding Parameters
            "beta": 0.5  # ball wear parameters
        }
        # ------------------
        D = 3
        M = 3
        lb = np.array([0, 0, 0])  # lower bound
        ub = np.array([389.90, 143.15, 166.62])  # upper bound

        super().__init__(D, M, lb, ub)
        del D, M, lb, ub

    def setGlobal(self, Global):
        """
        property setter
        :param Global {Global}
        """
        self.Global = Global

    def calcObjs(self, x) -> np.ndarray:
        """
        Calculate the objective function value
        :param x {ndarray} decision variable
        :return objs {ndarray} objective function value
        """
        (N, _) = x.shape
        objs = np.zeros((N, self.M))

        # SAG mill power consumption
        objs[:, 0] = self.parameters["c1"] * self.parameters["D"] ** 3 * \
                     math.sin(math.radians(self.parameters["alpha"])) * \
                     (x[:, 0] + x[:, 1] + x[:, 2]) * \
                     (3.2 - 3 * self.parameters["v"]) * self.parameters["N"] * \
                     (1 - 0.1 / (9 - 10 * self.parameters["N"]))

        # The reciprocal of the grinding output of the SAG mill
        objs[:, 1] = 1 / (self.parameters["l"] * x[:, 0])

        # The amount of steel balls consumed when the SAG mill is running
        objs[:, 2] = self.parameters["beta"] * (x[:, 0] + x[:, 2])

        # Increase evaluation number
        self.Global.evaluation += N

        return objs

    def calcCon(self, x) -> np.ndarray:
        """
        Calculate degree of constraint violation
        """
        try:
            (_, _) = x.shape
        except:
            x = x.reshape((1, x.shape[0]))
        con = 355.55 - np.sum(x, axis=1)
        return con*(con>0)


class SAGO2(Problem):
    """
    Semi-autogenous grinding optimization problem 2
    :date 2022-05-14
    :author Kevin Kong
    """

    def __init__(self) -> None:
        # problem parameters
        self.Global = None
        self.parameters = {
            "c1": 0.028,  # system parameter
            "c2": 0.15,  # system parameter
            "D": 9.8,  # mill inner diameter
            "alpha": 30,  # inclination angle of SAG mill
            "v": 0.3,  # the volume percentage of minerals and water in the machine
            "N": 0.7,  # the ratio of the actual speed of the motor to the rated power speed
            "l": 20,  # mineral Grinding Parameters
            "beta": 0.5  # ball wear parameters
        }
        # ------------------
        D = 3
        M = 3
        lb = np.array([50, 12.5, 98.45])  # lower bound
        ub = np.array([958.5, 355, 415.35])  # upper bound

        super().__init__(D, M, lb, ub)
        del D, M, lb, ub

    def setGlobal(self, Global):
        """
        property setter
        :param Global {Global}
        """
        self.Global = Global

    def calcObjs(self, x) -> np.ndarray:
        """
        Calculate the objective function value
        :param x {ndarray} decision variable
        :return objs {ndarray} objective function value
        """
        (N, _) = x.shape
        objs = np.zeros((N, self.M))

        # SAG mill power consumption
        objs[:, 0] = self.parameters["c2"] * self.parameters["D"] ** 3 * \
                     math.sin(math.radians(self.parameters["alpha"])) * \
                     (x[:, 0] + x[:, 1] + x[:, 2]) * \
                     (3.2 - 3 * self.parameters["v"]) * self.parameters["N"] * \
                     (1 - 0.1 / (9 - 10 * self.parameters["N"]))

        # The reciprocal of the grinding output of the SAG mill
        objs[:, 1] = -(self.parameters["l"] * x[:, 0])

        # The amount of steel balls consumed when the SAG mill is running
        objs[:, 2] = self.parameters["beta"] * (x[:, 0] + x[:, 2])

        # Increase evaluation number
        self.Global.evaluation += N

        return objs
    
    def calcCon(self, x) -> np.ndarray:
        """
        Calculate degree of constraint violation
        """
        # Without constraint
        return 0
