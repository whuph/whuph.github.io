from ulab import numpy as np
from random import random
from public.PROBLEM import Problem

class Global:
    '''
    This is the class of experimental setting [referring to the architecture in the platEMO platform]. 
    An object of Global class stores the algorithm to be executed,
    the parameter settings like population size, maximum number of evaluations.
    This class also provides some useful methods for algorithm.
    
    :date 2022-03-03
    :author Kevin Kong
    '''

    def __init__(self, problem:Problem, algorithm, N:int=20, max_evaluations:int=10000) -> None:
        '''
        :param problem {Problem} optimization problem
        :param algorithm {function} multi-objective optimization algorithm
        :param N {int} population size
        :param max_evaluations {int} maximum number of evaluations
        '''
        self.problem, self.algorithm, self.N, self.max_evaluations = problem, algorithm, N, max_evaluations
        self.problem.setGlobal(self)

    def initialization(self, N:int=0) -> np.ndarray:
        '''
        Initialize the population
        :param N {int} the population size
        :return {ndarray} population
        '''
        if N <= 0:
            N = self.N
        population = np.zeros((N, self.problem.D))
        for i in range(N):
            for j in range(self.problem.D):
                population[i,j] = self.problem.lb[j] +\
                    (self.problem.ub[j] - self.problem.lb[j]) * random()
        return population
    
    def run(self, **parameters) -> np.ndarray:
        '''
        invoke algorithm with its parameters
        :param parameters {dict} algorithm paramters
        :return {ndarray} archive
        '''
        self.evaluation = 0
        return self.algorithm(self, **parameters)
    
    def NotTermination(self) -> np.ndarray:
        return self.evaluation <= self.max_evaluations