class Problem:
    '''
    This class define the superclass of all optimization problems,
    including the dimension of problem, lower bound of decision variable,
    upper bound of decision variable and number of objectives

    :date 2022-03-04
    :author Kevin Kong
    '''
    def __init__(self, D:int, M:int, lb, ub) -> None:
        '''
        :param D {int} dimension of decision variable
        :param M {int} number of objectives
        :param lb {ndarray} lower bound of decision variable
        :param ub {ndarray} upper bound of decision variable
        '''
        self.D, self.M, self.lb, self.ub = D, M, lb, ub
    
