from ulab import numpy as np
'''
This package extends the numpy function

:date 2022-03-07
:author Kevin Kong
'''


def logical_and(a:np.ndarray, b:np.ndarray) -> np.ndarray:
    '''
    1D Logical 'and' operation of two matrices
    :param a {ndarray}
    :param b {ndarray}
    :return {ndarray}
    '''
    assert a.shape == b.shape
    res = np.zeros(a.shape, dtype=np.bool)
    n = len(a)
    for i in range(n):
        res[i] = (a[i] * b[i])
    return res
    
def logical_or(a:np.ndarray, b:np.ndarray) -> np.ndarray:
    '''
    1D Logical 'or' operation of two matrices
    :param a {ndarray}
    :param b {ndarray}
    :return {ndarray}
    '''
    assert a.shape == b.shape
    res = np.zeros(a.shape, dtype=np.bool)
    n = len(a)
    for i in range(n):
        if a[i] or b[i]:
            res[i] = 1
    return res

def ndarray_slice(a:np.ndarray, row, column) -> np.ndarray:
    '''
    ndarray slice extension
    :param a {ndarray}
    :param row {ndarray/list/range}
    :param column {ndarray/list/range}
    :return {ndarray}
    '''
    (m, n) = a.shape
    assert m >= len(row) and n >= len(column)
    arr = np.zeros((len(row), len(column)))
    for (i_index, i) in enumerate(row):
        for (j_index,j) in enumerate(column):
            arr[i_index, j_index] = a[i, j]
    return arr
    
def prod(A:np.ndarray) -> np.ndarray:
    '''
    Product of array elements
    :param A {ndarray} array
    :return {ndarray}
    '''
    (N,M) = A.shape
    product = np.ones((N,1))
    for i in range(N):
        for j in range(M):
            product[i] *= A[i,j]
    return product
        