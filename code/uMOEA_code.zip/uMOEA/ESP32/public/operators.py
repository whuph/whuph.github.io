from ulab import numpy as np
from random import random
from math import ceil

'''
This package provides operators for generating offsprings

:date 2022-03-07
:author Kevin Kong
'''

def DE(old:np.ndarray, select:np.ndarray):
    '''
    Differential Evolution
    :param old {ndarray} old solution
    :param select {ndarray} selected three solutions
    :param {ndarray} offspring
    '''
    F = 0.5
    CR = 0.5
    dim = len(old)
    jrandom = ceil(random() * dim) - 1
    randomArray = np.ones(dim)
    for i in range(dim):
        randomArray[i] = random()
    deselect = randomArray < CR
    deselect[jrandom] = 1
    offspring = select[0,:] + F * (select[1,:] - select[2,:])
    offspring[~deselect] = old[~deselect]
    return offspring