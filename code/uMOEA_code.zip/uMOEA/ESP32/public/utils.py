from ulab import numpy as np
from random import choice
from public.extends import logical_and, logical_or, ndarray_slice, prod
from random import random

'''
This package contains some useful methods

:date 2022-03-04
:author Kevin Kong
'''


def getWeights(N: int, M: int) -> (int, np.ndarray):
    """
    Read weights from local npx file.
    In order to reduce unnecessary calculations, the pre-generated weights are used.
    :param N {int} archive size
    :param M {int} the number of objective
    :return {(int,ndarray)} weight vectors and its count
    """
    file_name = "resources/N_%d_M_%d.npy" % (N, M)
    data = np.load(file_name)
    (n, _) = data.shape
    return n, data


def pdist2(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """
    Calculate the euclidean distance between a and b
    :param a {ndarray} vector a
    :param b {ndarray} vector b
    :return {ndarray} distance between a and b
    """
    (r1, c1) = a.shape
    (r2, c2) = b.shape
    dis = np.zeros((r1, r2))
    for i in range(r1):
        for j in range(r2):
            dis[i, j] = np.sqrt(np.sum((a[i, :] - a[j, :]) ** 2))
    return dis


def determineNeighbors(W: np.ndarray, T: int) -> np.ndarray:
    """
    Determine the neightbor of weight vectors.
    :param W {ndarray} weight vectors matrix
    :param T {int} the size of neighbor
    :return {ndarray} neighbors
    """
    dist = pdist2(W, W)
    B = np.argsort(dist, axis=1)
    return B[:, :T]


def calcTche(Objs: np.ndarray, W: np.ndarray, Z) -> np.ndarray:
    """
    Calculate Tchebycheff value
    :param Objs {ndarray} objective function values
    :param W {ndarray} weight vectors
    :param Z {ndarray} ideal point
    :return {ndarray} Tchebycheff value
    """
    try:
        return np.max((abs(Objs - Z) * W), axis=1)
    except:
        print("Objs:", Objs.shape)
        print("W:", W.shape)
        return np.max((abs(Objs - Z) * W), axis=1)


def randperm(sequence: list, k: int) -> list:
    """
    Random permutation
    :param sequence {list} array to be selected
    :param k {int} quantity to be selected
    :return {list}
    """
    s = sequence.copy()
    selected = []
    for _ in range(k):
        tmp = choice(s)
        selected.append(tmp)
        s.remove(tmp)
    return selected


def repair(x, lb, ub) -> np.ndarray:
    """
    Fix out-of-bounds variables
    :param x {ndarray} decision variables
    :param lb {ndarray} lower bound
    :param ub {ndarray} upper bound
    :return {ndarray} repaired variables
    """
    return (logical_and((x >= lb), (x <= ub))) * x + \
           logical_or((x < lb), (x > ub)) * (lb + (ub - lb) * random())


def uniformNormalDistribution() -> float:
    """
    Get uniform normal distribution number
    :return {float}
    """
    s = 0
    for i in range(12):
        s += random()
    return s - 6


def normrnd(u: float, sigma: float) -> float:
    """
    Get normal distribution random number
    :param u {float} mean
    :param sigma {float} stand deviation
    :return {float}
    """
    return u + (uniformNormalDistribution() * sigma)


def gaussianMutation(x: np.ndarray, lb: np.ndarray, ub: np.ndarray) -> np.ndarray:
    """
    Gaussian mutation
    :param x {ndarray} solution
    :param lb {ndarray} lower bound
    :param ub {ndarray} upper bound
    :return {ndarray} new solution
    """
    dim = len(x)
    prob = 1 / dim
    sigma = (ub - lb) / 20
    newInd = x.copy()
    for i in range(dim):
        if random() < prob:
            newInd[i] = normrnd(x, sigma)
    return newInd


def NDSort(fits: np.ndarray) -> np.ndarray:
    """
    non-dominated sorting by efficient non-dominated sort
    :refers https://github.com/YuLi2022/MOEA-CODE-PYTHON
    :param fits {ndarray} the matrix of objective values of a set of individuals
    :return {ndarray} rank
    """
    nPop = fits.shape[0]
    nF = fits.shape[1]
    ranks = np.zeros(nPop, dtype=np.uint16)
    nPs = np.zeros(nPop)
    sPs = []
    for i in range(nPop):
        iSet = []
        for j in range(nPop):
            if i == j:
                continue
            isDom1 = fits[i] <= fits[j]
            isDom2 = fits[i] < fits[j]
            if sum(isDom1) == nF and sum(isDom2) >= 1:
                iSet.append(j)
            if sum(~isDom2) == nF and sum(~isDom1) >= 1:
                nPs[i] += 1
        sPs.append(iSet)
    r = 0
    indices = np.arange(nPop)
    while sum(nPs == 0) != 0:
        rIdices = indices[nPs == 0]
        for rIdx in rIdices:
            ranks[rIdx] = r
            iSet = sPs[rIdx]
            for s in iSet:
                nPs[s] -= 1
        for rId in rIdices:
            nPs[rId] = -1
        r += 1
    return ranks


def find(a: np.ndarray):
    """
    Find indices of nonzero elements
    :param a {ndarray}
    :return {ndarray} indices of nonzero elements
    """
    N = len(a)
    arr = []
    for i in range(N):
        if a[i]:
            arr.append(i)
    return np.array(arr, dtype=np.uint16)


def updateEP(EP: np.ndarray, EPObjs: np.ndarray, Offsprings: np.ndarray, OffspringsObjs: np.ndarray, n: int) -> (
        np.ndarray, np.ndarray):
    """
    Update external population
    :param EP {ndarray} external population
    :param EPObjs {ndarray} EP objectives value
    :param Offsprings {ndarray}
    :param OffspringsObjs {ndarray}
    :param n {int} the size of EP
    :return {(ndarray,ndarray)} (EP, EPObjs)
    """
    EP = np.concatenate((EP, Offsprings), axis=0)
    EPObjs = np.concatenate((EPObjs, OffspringsObjs), axis=0)
    NDs = NDSort(EPObjs) == 1
    EPNew = []
    EPObjsNew = []
    for (i, ND) in enumerate(NDs):
        if ND == True:
            EPNew.append(EP[i, :].tolist())
            EPObjsNew.append(EPObjs[i, :].tolist())
    EP = np.array(EPNew)
    EPObjs = np.array(EPObjsNew)
    del EPNew, EPObjsNew, NDs
    try:
        (N, M) = EP.shape
    except ValueError:
        return (np.array([]), np.array([]))

    # Delete the overcrowded solutions
    Dis = pdist2(EPObjs, EPObjs)
    for i in range(N):
        Dis[i, i] = float("inf")
    Del = np.zeros((N), dtype=np.bool)
    while sum(Del) < N - n:
        Remain = find(~Del)
        subDis = np.sort(ndarray_slice(Dis, Remain, Remain), axis=1)
        worst = np.argmin(prod(subDis[:, 0:min(M, len(Remain))]))
        Del[Remain[worst]] = 1
    EPNew = []
    EPObjsNew = []
    for (index, d) in enumerate(Del):
        if not d:
            EPNew.append(EP[index, :])
            EPObjsNew.append(EPObjs[index, :])

    return (np.ndarray(EPNew), np.ndarray(EPObjsNew))


def updateWeight(archive: np.ndarray, Objs: np.ndarray, W: np.ndarray, Z: np.ndarray, EP: np.ndarray,
                 EPObjs: np.ndarray, nus: int) -> (np.ndarray, np.ndarray, np.ndarray):
    """
    update weight by deleting overcrowded subproblems and adding new subproblems
    :refers MOEA/D-AWA
    :param archive {ndarray}
    :param Objs {ndarray}
    :param W {ndarray}
    :param Z {ndarray}
    :param EP {ndarray}
    :param EPObjs {ndarray}
    :param nus {ndarray}
    :return {(ndarray, ndarray, ndarray)} (archive, Objs, W)
    """
    if EP.shape[0] == 0:
        return (archive, Objs, W)
    N = archive.shape[0]
    # Delete the overcrowded subproblems
    dis = pdist2(Objs, Objs)
    for i in range(Objs.shape[0]):
        dis[i, i] = float("inf")
    Del = np.zeros(Objs.shape[0], dtype=np.bool)
    while sum(Del) < min(nus, EP.shape[0]):
        Remain = find(~Del)
        subDis = np.sort(ndarray_slice(dis, Remain, Remain), axis=1)
        worst = np.argmin(prod(subDis[:, 0:min(Objs.shape[1], len(Remain))]))
        Del[Remain[worst]] = 1
    archiveNew = []
    ObjsNew = []
    WNew = []
    for (index, d) in enumerate(Del):
        if not d:
            archiveNew.append(archive[index, :])
            ObjsNew.append(Objs[index, :])
            WNew.append(W[index, :])
    archive = np.array(archiveNew)
    Objs = np.array(ObjsNew)
    W = np.array(WNew)
    del archiveNew, ObjsNew, WNew, Del, dis
    # Add new subproblems
    # Determine the new solutions be added
    Combine = np.concatenate((archive, EP), axis=0)
    CombineObjs = np.concatenate((Objs, EPObjs), axis=0)
    Selected = np.zeros(Combine.shape[0], dtype=np.bool)
    Selected[:archive.shape[0]] = 1
    dis = pdist2(CombineObjs, CombineObjs)
    for i in range(dis.shape[0]):
        dis[i, i] = float("inf")
    while sum(Selected) < min(N, len(Selected)):
        SelectedRow = find(~Selected)
        SelectedCol = find(Selected)
        subDis = np.sort(ndarray_slice(dis, SelectedRow, SelectedCol), axis=1)
        best = np.argmax(prod(subDis[:, 0:min(Objs.shape[1], subDis.shape[1])]))
        Selected[SelectedRow[best]] = 1
    # Add new subproblems
    newObjs = ndarray_slice(EPObjs, find(Selected[Objs.shape[0]:]), range(EPObjs.shape[1]))

    temp = 1 / (newObjs - Z)
    del newObjs
    for i in range(temp.shape[0]):
        for j in range(temp.shape[1]):
            if temp[i, j] == np.inf:
                temp[i, j] = 0.999999
    tempSum = np.sum(temp, axis=1)
    for i in range(temp.shape[0]):
        temp[i, :] = temp[i, :] / tempSum[i]
    W = np.concatenate((W, temp), axis=0)
    # Add new solutions
    archive = ndarray_slice(Combine, find(Selected), range(archive.shape[1]))
    Objs = ndarray_slice(CombineObjs, find(Selected), range(EPObjs.shape[1]))
    return (archive, Objs, W)
