function AMGA(Global)
% <algorithm> <A>
% AMGA
%  N --- 8 --- the number of the Population
%  init_N ---100 --- the number of the init Population

% AMGA��An Archive-based Micro Genetic Algorithm for Multi-objective Optimization

    %% Parameter setting --the number of parent_Population 
    N = Global.ParameterSet(8);
    init_N=Global.ParameterSet(100);
    %% Generate initial population
    piece=(Global.upper-Global.lower)/init_N;
    Lower=Global.lower;
    for i=1:init_N
        init_Population(i,:)=Lower+piece.*rand(1,Global.D);
        Lower=Lower+piece;
    end
    init_Population=INDIVIDUAL(init_Population);
    %% Update the Archive
    Archive=init_Population;
    load("population.mat")
    Archive = Population;
    %% Optimization
    while Global.NotTermination(Archive)
            %% Create parent populationfrom the Archive
            parent_population=Create_parent_population(Archive,N); 
            %% Non-dominated sorting
            [FrontNo,~] = NDSort(parent_population.objs,N);
             %% Calculate the crowding distance of each solution
            CrowdDis = CrowdingDistance(parent_population.objs,FrontNo);
            MatingPool = TournamentSelection(2,N/2,FrontNo,-CrowdDis);
            %% Create Offspring by using Revised DE
            Offspring  = GAhalf(parent_population(MatingPool));
            %% Update the Archive
            Archive=EnvironmentalSelection(Offspring,Archive,Global.N);
    end
end