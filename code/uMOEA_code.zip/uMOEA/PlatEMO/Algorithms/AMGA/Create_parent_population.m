function parent_population=Create_parent_population(Archive,N)
    [FrontNo,~] = NDSort(Archive.objs,length(Archive));
    CrowdDis = CrowdingDistance(Archive.objs,FrontNo);
    [~,index]=sort(CrowdDis,'descend');
    parent_population=Archive(index(1:N));
end