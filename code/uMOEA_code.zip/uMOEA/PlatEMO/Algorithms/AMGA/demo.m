N=8;
init_N=100;
Global.lower=zeros(1,7);
Global.upper=ones(1,7);
piece=(Global.upper(1)-Global.lower(1))/N;
lower=Global.lower(1):piece:Global.upper(1)-piece;
upper=Global.lower(1)+piece:piece:Global.upper;
for i=1:init_N
    init_Population(i,:)=unifrnd(lower,upper);
end
plot(init_Population(:,1),init_Population(:,2),'r*');
% init_Population=INDIVIDUAL(init_Population);