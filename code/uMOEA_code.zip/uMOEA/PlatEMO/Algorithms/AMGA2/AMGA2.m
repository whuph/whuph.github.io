function AMGA2(Global)
% <algorithm> <A>
% AMGA2
%  N --- 8 --- the number of the Population
%  init_N --- 100 --- the number of the init_Population

% AMGA2��improving the performance of the archive-based micro-genetic algorithm for multi-objective optimization
% Santosh Tiwari a , Georges Fadel b & Kalyanmoy Deb 
% Vanderplaats Research & Development, Inc. , Novi, MI, USA
% Clemson University , Clemson, SC, USA
% Indian Institute of Technology , Kanpur, India

    %% Parameter setting --the number of parent_Population 
    [N,init_N] = Global.ParameterSet(8,100);
    %% Generate initial population
    piece=(Global.upper-Global.lower)/init_N;
    Lower=Global.lower;
    for i=1:init_N
        init_Population(i,:)=Lower+piece.*rand(1,Global.D);
        Lower=Lower+piece;
    end
    init_Population=INDIVIDUAL(init_Population);
    %% Update the Archive
    Archive=init_Population;
    load("population.mat")
    Archive = Population;
    %% Optimization
    while Global.NotTermination(Archive)
            %% Create parent populationfrom the Archive
            parent_population=Create_parent_population(Archive,N); 
            %% Create Offspring by using Revised DE
            Offspring  = Revised_DE(parent_population,Archive(randperm(length(Archive),N)),...
                Archive(randperm(length(Archive),N)),Archive(randperm(length(Archive),N)),{0.5,0.1,1,20});
            %% Update the Archive
            Archive=EnvironmentalSelection(Offspring,Archive,Global.N);
    end
end