function parent_population=Create_parent_population(Archive,N)
    %% Create_population
    if length(Archive)==N
        parent_population=Archive;
    else
        [FrontNo,MaxFNo] = NDSort(Archive.objs,length(Archive));
        Next=false(1,length(FrontNo));
        Front=1;
        while(sum(Next)<=N)
            Next(find(FrontNo==Front))=true;
            Front=Front+1;
            if Front>MaxFNo
                Front=MaxFNo;
            end
        end
        %% Calculate the crowding distance of each solution
        CrowdDis = CrowdingDistance(Archive(Next).objs,FrontNo(Next));
        %% Select the extreme solutions
        [~,index]=min(Archive(Next).objs,[],1);
        Next=false(1,length(FrontNo));
        Next(unique(index))=true;
        %% Assign a value of zero for the redundant copies
        CrowdDis(unique(index))=0;
        %% Select the remaining individuals
        [~,Rank] = sort(CrowdDis,'descend');
        Next(Rank(N-sum(Next)))=true;
        parent_population=Archive(Next);
    end
end