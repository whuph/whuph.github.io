function x = cauchy_mutation(x,min_range,max_range)
    % ��������
    % @param x:������
    dim = length(x);
    prob = 1 / dim;
    beta = (max_range - min_range) ./ 20;
    new_ind = min(max(cauchy(x,beta), min_range), max_range);
    C = rand(1,dim) < prob;
    x(C) = new_ind(C);
end
function rnd = cauchy(alpha,beta)
    u = rand();
    rnd = alpha - beta / tan(pi*u);
end
