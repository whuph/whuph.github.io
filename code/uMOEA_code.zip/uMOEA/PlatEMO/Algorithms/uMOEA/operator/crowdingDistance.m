function CrowdDis = crowdingDistance(archive,P)
    [N,M] = size(archive(P).objs);
    CrowdDis = zeros(1,N);
    Fmax = max(archive(P).objs,[],1);
    Fmin = min(archive(P).objs,[],1);
    PopObj = archive(P).objs;
    for i = 1 : M
        [~,Rank] = sortrows(PopObj(:,i));
        CrowdDis(Rank==1) = inf;
        CrowdDis(Rank==end) = inf;
        for j = 2 : length(P)-1
            CrowdDis(Rank==j) = CrowdDis(Rank==j) + (PopObj(Rank==j+1,i) - PopObj(Rank==j-1,i))/(Fmax(i)-Fmin(i));
            % CrowdDis(Rank==j) = CrowdDis(Rank==j) + (PopObj(P(Rank==(j+1),i) - PopObj(P(Rank(j-1)),i))/(Fmax(i)-Fmin(i));
        end
    end
end