function uMOEA(Global)
% <algorithm> <M>
% Micro multi-objective evolutionary algorithm
% n --- 5 --- Population size
% tau --- 4 --- timeslice
% cauchyMin --- 0.0001 --- 
% flagRate --- 0.06 --- 
% gamma --- 0.4 --- tolerent rate
% s --- 10 --- scaling parameter of penalty function
    %% Parameter setting
    [n,tau, cauchyMin, flagRate, gamma, s] = Global.ParameterSet(5, 4, 0.0001, 0.06, 0.4, 10);

    %% Initialization
    [W,Global.N] = UniformPoint(Global.N,Global.M);
    W = 1./W./repmat(sum(1./W,2),1,size(W,2));

    T = size(W, 1);
    if T < n
        n = T;
    end
    
    %% Detect the neighbours of each solution
    B = pdist2(W,W);
    [~,B] = sort(B,2);
    B = B(:,1:T);
    
    %% Generate random population to fill the archive
    archive = Global.Initialization();
    Z = min(archive.objs,[],1);
    
    %% Evolutionary process division 
    queue = Queue(1:Global.N,n);
    %% Optimization
    process = queue.index;
    flag = 0;
    % Calculate divisity index
    phi = sum(max(abs(archive.objs-repmat(Z,Global.N,1)).*W,[],2));
    EP = [];
    while Global.NotTermination(archive)
        Offsprings = [];
        for t = 1:tau
            for i = 1:length(process)
                if rand < 0.9
                    P = B(process(i),randperm(size(B,2)));
                else
                    P = randperm(Global.N);
                end
                offspring = DE_crossover(archive(P(1)), archive(P(2:4)));
                offspring = repair(offspring,Global.problem.Global.lower,Global.problem.Global.upper);
                offspring = gaussian_mutation(offspring,Global.problem.Global.lower,Global.problem.Global.upper);
                offspring = INDIVIDUAL(offspring);
                Z = min(Z,offspring.obj);
                % Replace the poorly performed neighbors
                g_old = max(abs(archive(P).objs-repmat(Z,length(P),1)).*W(P,:),[],2)...
                    + s.*(archive(P).cons).^2;
                g_new = max(repmat(abs(offspring.obj-Z),length(P),1).*W(P,:),[],2)...
                    + s.*(offspring.cons).^2;
                archive(P(g_old>=g_new)) = offspring;
                Offsprings = [Offsprings,offspring];
            end
        end
        %% Update the archive(a.k.a External Population, EP)
        if Global.gen/Global.maxgen <= 0.9
            if isempty(EP)
				EP = updateEP(archive,Offsprings,ceil(Global.N));
			else
				EP = updateEP(EP,Offsprings,ceil(Global.N));
            end
        end
        %% Convergence judgement
        % Current diversity index
        phi_cur = sum(max(abs(archive.objs-repmat(Z,Global.N,1)).*W,[],2));
        if std([phi, phi_cur]) <= cauchyMin
            flag = flag + 1;
            if flag >= Global.maxgen * flagRate
                % Has converged
                dis = pdist2(archive.objs,archive.objs);
                dis(logical(eye(length(dis)))) = inf;
                nearest = min(dis,[],2);
                crowded = 0;
                if ~isempty(find(nearest == 0, 1))
                    % Must be crowded
                    crowded = 1;
                    nus = length(find(nearest == 0));
                else
                    nearest_mean = mean(nearest);
                    normalVal = nearest / nearest_mean;
                    nus = sum(normalVal < gamma);
                    if sum(normalVal < gamma) >= 1
                        crowded = 1;
                    end
                end
                if crowded == 1
                    % Update the weight vectors for the crowded Pop
                    [archive,W] = updateWeight(archive,W,Z,EP,nus); 
                    B = pdist2(W,W);
                    [~,B] = sort(B,2);
                    B = B(:,1:T);
                    flag = 0;
                end
            end
        else
            phi = phi_cur;
            flag = 0;
        end
        process = queue.next();
    end 
end