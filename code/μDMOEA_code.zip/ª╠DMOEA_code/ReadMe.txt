Welcome to access Hu Peng's Homepage, https://whuph.github.io/index.html,
Our papers and codes are avaliable on the website. 

// The population size in comparison algorithms and real-world problems is set to 20,  also can be set to 100.

If you find this code useful in your work, please cite the following paper "Luo Z, Xiong  J*, Peng H∗, Zhan G, Zhang Q, Wang H, Zhou X, Li Wei, Huang Y. A Micro Dynamic Multi-objective Evolutionary Algorithm for Small-scale Smart Greenhouse with Low-power Microprocessor[C]. Proceedings of the Genetic and Evolutionary Computation Conference (GECCO 2024), ACM, 2024: 687–690. " PlatEMO V4.5 is required to run the code. Reference "Ye Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform for evolutionary multi-objective optimization [educational forum], IEEE Computational Intelligence Magazine, 2017, 12(4): 73-87."