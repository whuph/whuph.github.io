Welcome to access Hu Peng's Homepage, https://whuph.github.io/index.html,
Our papers and codes are avaliable on the website. 

If you find this code useful in your work, please cite the 
following paper "Peng H*,Wang C, Han Y, Xiao W, Zhou X, Wu Z.Micro multi-strategy multi-objective artificial bee colony algorithm for microgrid energy optimization[J]. Future Generation Computer Systems, 2022. DOI: 10.1016/j.future.2022.01.011.