function [newN,Flag,Z] = Intermediate_strategy(pi,Z,N,Flag,oldN,record,threshold,Archive,rate_evol)
    M=size(Z,2);
    metric=find(record==1);
    associateZ=unique(pi);
    Num       = unique(Archive.decs,'rows');
    newN=length(associateZ);
    if(length(metric)>threshold*rate_evol&&abs(oldN-newN)<=3&&size(Num,1)<N)
        Flag=Flag+1;
    else
        Flag=0;
    end
    if Flag>threshold
        Cos=0.96;  
        while size(z,1)<N
            if size(z,1)<=2||Cos>1
                Z= UniformPoint(N,M);
                z=Z;
            end
            c=[];
             j=1;
            for i=1:size(z,1)-1
                p=(z(i,:)+z(i+1,:))/2;
                check=[z(i,:);p];
                if i==1||i==size(z,1)-1
                    if 1-pdist(check,'cosine')<0.997
                        c(j,:)=p;
                        j=j+1;
                    end
                else
                    if 1-pdist(check,'cosine')<Cos
                        c(j,:)=p;
                        j=j+1;
                    end
                end
            end
             z=[z;c];
            % The whole reference point is calculated again, and the reference points that are very close to the reference point are deleted  
            z       = unique(z,'rows');
            %%%%%%%%%%%%%%%%%%%%%%%%%%%
            if size(z,1)<N
                Cos=Cos+0.001;
            end
        end
        % Delete reference points
        if size(z,1)>N
            Distance=pdist2(z,z);
            Distance(logical(eye(length(Distance)))) = inf;
            Del = false(1,size(z,1));
            while size(z,1)-sum(Del)>N
                Remain   = find(~Del);
                Temp     = sort(Distance(Remain,Remain),2);
                [~,Rank] = sortrows(Temp);
                % The boundary reference points are reserved to prevent the loss of the distribution of reference points
                if Remain(Rank(1))==1||Remain(Rank(1))==size(z,1)
                    Del(Remain(Rank(2))) = true;
                else
                    Del(Remain(Rank(1))) = true;
                end
            end
            z(Del,:)=[];
        end
        Z=z;
    end
end