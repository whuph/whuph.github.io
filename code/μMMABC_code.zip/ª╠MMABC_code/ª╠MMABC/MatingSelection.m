function [MatingPool,pi]=MatingSelection(Archive,Z,Zmin,K)
ArchiveObj=Archive.objs;
N=length(Archive);
NZ=size(Z,1);
%% Associate each solution with one reference point
% Calculate the distance of each solution to each reference vector
Cosine   = 1 - pdist2(ArchiveObj,Z,'cosine');
Distance = repmat(sqrt(sum(ArchiveObj.^2,2)),1,NZ).*sqrt(1-Cosine.^2);
% Associate each solution with its nearest reference point
[~,pi] = min(Distance',[],1);
ArchiveObj=ArchiveObj-repmat(Zmin,N,1);
g=sum(ArchiveObj.*Z(pi,:),2);
[~,index]=sort(g);
MatingPool=index(1:K);
end