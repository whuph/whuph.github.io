function mMMABC(Global)
% <algorithm><M>
% ��MMABC
% N --- 5 --- the number of the Population

% This is a simple demo of ��MMABC
%--------------------------------------------------------------------------------------------------------
% If you find this code useful in your work, please cite the 
% following paper "Peng H*,Wang C (Student), Han Y (Student), Xiao W (Student), Zhou X, Wu Z.
%                             Micro multi-strategy multi-objective artificial bee colony algorithm for microgrid 
%			 energy optimization[J]. Future Generation Computer Systems, 2022".
%--------------------------------------------------------------------------------------------------------
% This function is implmented by CongWang
%--------------------------------------------------------------------------------------------------------
%--------------------------------------------------------------------------------------------------------
% More information can visit Hu Peng's homepage: https://whuph.github.io/index.html
%--------------------------------------------------------------------------------------------------------
    %% Parameter setting --the number of parent_Population 
    N = Global.ParameterSet(5);
    %% Generate the reference points and random population
    piece=(Global.upper-Global.lower)/N;
    Lower=Global.lower;
    for i=1:N
        init_Population(i,:)=Lower+piece.*rand(1,Global.D);
        Lower=Lower+piece;
    end
    init_Population=INDIVIDUAL(init_Population);
    [Z,Global.N] = UniformPoint(Global.N,Global.M);

    %% Generate the archive and ideal point
    Archive=init_Population;
    EliteSolution=Archive;
    Population=init_Population;
    Zmin = min(Archive.objs,[],1);
    %% Setting the basic variables
    p=1;
    threshold=50;
    Flag=0;
    oldN=size(Z,1);
    rate_evol=0.8;
    %% Optimization
    while Global.NotTermination(Archive)
        Offspring = Multi_strategy_ABC(Population,EliteSolution,N,Global.D,Global.lower,Global.upper);
        Zmin=min([Zmin;[Population.objs;Offspring.objs;Archive.objs]],[],1); 
        [Archive,EliteSolution,MaxFNo] = EnvironmentalSelection([Population,Offspring,Archive],Z,Zmin,Global.N);
        %% Adaptive updating mechanism
        [MatingPool,pi]=MatingSelection(Archive,Z,Zmin,N);
        Population=Archive(MatingPool);
        Population=UpdatePopulation(EliteSolution,Population,N,Global.lower,Global.upper,Global.D,Global.evaluated/Global.evaluation);
        %% Reference point reconstruction with intermediate strategy
         if Global.evaluated>Global.evaluation*rate_evol
             if rem(p,threshold)
                record(rem(p,threshold))=MaxFNo;
            else
                record(threshold)=MaxFNo;
            end
            if length(record)>=threshold
                [oldN,Flag,Z] = Intermediate_strategy(pi,Z,Global.N,Flag,oldN,record,threshold,Archive,rate_evol);
            end
         end        
        p=p+1;
    end
end