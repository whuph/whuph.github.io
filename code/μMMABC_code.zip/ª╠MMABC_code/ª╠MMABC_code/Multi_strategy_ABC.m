function Offspring = Multi_strategy_ABC(Population,Archive,SN,D,lower,upper)
%% Multi_strategy_ABC optimizer
    Archive=Archive.decs;
    offspring=Population.decs;
    for i=1:SN
        idx=randperm(SN,2);
        neighbour=idx(1);
        if (i==neighbour)
            neighbour=idx(2);
        end
        switch (rem(i,3))
            %% ABC
            case 1
                offspring(i,:)=offspring(i,:)+...
                    (offspring(i,:)-offspring(neighbour,:)).*(rand(1,D)-0.5)*2;
                offspring(i,:)       = min(max(offspring(i,:),lower),upper);
            %% GABC
            case 2
                offspring(i,:)=offspring(i,:)+...
                    (Archive(randperm(size(Archive,1),1),:)-offspring(i,:)).*(rand(1,D)-0.5)*2+...
                        (offspring(i,:)-offspring(neighbour,:)).*(rand(1,D)*1.5);
                offspring(i,:)       = min(max(offspring(i,:),lower),upper);
            %% MABC
            case 0
                offspring(i,:)=offspring(i,:)+(Archive(randperm(size(Archive,1),1),:)-offspring(i,:)).*rand(1,D);
                offspring(i,:)       = min(max(offspring(i,:),lower),upper);
                offspring(i,:)=gaussian_mutation(offspring(i,:),lower,upper);
        end
        Offspring(i)=INDIVIDUAL(offspring(i,:));
        Offspring(i) = Update(Offspring(i),Population(i));
    end
end
function Offspring = Update(Offspring,Population)
    temp = Offspring.objs - Population.objs;
    Dominate = any(temp<0,2) - any(temp>0,2);
    Offspring(Dominate==-1) = Population(Dominate==-1);
end