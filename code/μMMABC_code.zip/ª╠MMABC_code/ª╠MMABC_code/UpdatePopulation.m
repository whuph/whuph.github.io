function P=UpdatePopulation(EliteSolution,P1,N,lower,upper,D,ratio)
    %% Update the Population
    k=ceil(unifrnd(1,length(EliteSolution),1,N));
    P2=EliteSolution(k).decs;
    j=ceil(unifrnd(1,length(EliteSolution),1,N));
    tempEliteSolution=EliteSolution(j).decs;
    idx=ceil(unifrnd(1,D,N,3));
    P2(:,idx(:,1))=P2(:,idx(:,2))+(tempEliteSolution(:,idx(:,3))...
                        -tempEliteSolution(:,idx(:,2))).*rand(N,N);
    P2=gaussian_mutation(P2,lower,upper);     
    P2=INDIVIDUAL(P2);
            
    %% Chaotic Selection
    ch(1)=rand;
    for i=1:N-1
        ch(i+1)=3.7*ch(i)*(1-ch(i));
    end
    % Regulating factors that control the selection of paternal individuals of different properties
    Autoregulators=1-1./(1+exp(25*(ratio-mean(ch))));
    index=ch<mean(ch)*Autoregulators;
    P = [P1(index),P2(~index)];
end