function score = CSp(Problem, Population, His)
%% Chebychev-based Spacing Distance

    nonObj = Population.best.objs;
    bestN = size(nonObj, 1);
    Distance = ChebychevDis(nonObj, nonObj);
    
    mu = 0;
    sigma = 1/Problem.D;
    
    Gauss = mu + sigma * randn(bestN, bestN);
    for i = 1 : bestN
        for j = 1 : bestN
            if (Distance(i, j) + Gauss(i, j)) > 0
                Distance(i, j) = Distance(i, j) + Gauss(i, j);
            end
        end
    end

    Distance(logical(eye(size(Distance,1)))) = inf;
    score = std(min(Distance,[],2));

    if isnan(score)
        score = mean(His);
    end
end