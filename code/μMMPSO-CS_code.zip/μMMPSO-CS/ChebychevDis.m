function Distance = ChebychevDis(X, Y)
%% Calculate Chebychev Distance

    [M, ~] = size(X);
    Distance = zeros(M); 
    for i = 1:M
        for j = i+1:M
            Distance(i, j) = max(abs(X(i, :) - Y(j, :)));
            Distance(j, i) = Distance(i, j); 
        end
    end

end
