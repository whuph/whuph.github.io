Welcome to Hu Peng's Homepage at https://whuph.github.io/
Our research papers and corresponding codes are publicly available on this website.

This repository contains the MATLAB source code of the μMMPSO-CS algorithm (micro multi-operator multi-objective particle swarm optimization with a Chebyshev spacing indicator).

This implementation is based on the PlatEMO platform: Ye Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, "PlatEMO: A MATLAB Platform for Evolutionary Multi-Objective Optimization", IEEE Computational Intelligence Magazine, 2017, 12(4): 73-87.

The algorithm alternately employs three particle swarm operators with complementary search characteristics (convergence, diversity, and balance) to improve the convergence and diversity of the micro-population. In addition, an adaptive weight-vector update triggering mechanism based on the Chebyshev spacing indicator is designed, so that the weight vectors are updated only when a significant loss of diversity is detected.

## Files

```
mMMPSO_CS.m                   % Main framework of the algorithm
GetBest.m                     % Select pbest (PBI) and gbest (random)
OperatorPSO_convergence.m     % Convergence-oriented PSO operator
OperatorPSO_diversity.m       % Diversity-oriented PSO operator
OperatorPSO_balance.m         % Balance-oriented PSO operator
CSp.m                         % Chebyshev spacing indicator
ChebychevDis.m                % Chebyshev distance
Classification.m              % Initial archive generation
EnvironmentalSelection.m      % RVEA-style environmental selection
updateWeight.m                % Adaptive weight-vector update
```

## Usage

The algorithm is implemented as a PlatEMO algorithm class and should be run within the PlatEMO platform. Add this folder to the MATLAB path (or place it under the PlatEMO `Algorithms` directory), then run:

```matlab
platemo('algorithm', @mMMPSO_CS, 'problem', @WFG1, 'N', 20, 'maxFE', 10000);
```

The test problem can be replaced by any instance from the WFG, ZDT, or DTLZ suites. Following the paper, the population size is set to `N = 20` and the maximum number of function evaluations to `maxFE = 10000`.

## Parameters

The key parameters are: `alpha = 0.2` (progress threshold for computing the CS indicator), `beta = 0.9` (CS history ratio for triggering the weight update), a minimum interval of 20 iterations between two weight updates, `delta = 0.7` (branch probability of the diversity operator), and PBI penalty factor `theta = 5`.

NOTE: Users are encouraged to adapt the code to their specific problem domains while maintaining proper attribution. If the μMMPSO-CS algorithm code contributes to your research, please cite our paper: Lin Liu, Hu Peng, Zhongtian Luo, Mengfan Li, Lei Peng, Xiao Zhang, and Zhijian Wu, "A micro multi-operator multi-objective particle swarm optimization with Chebyshev spacing indicator", Evolutionary Intelligence, vol. 20, article no. 3, 2027, DOI: 10.1007/s12065-026-01290-4.
