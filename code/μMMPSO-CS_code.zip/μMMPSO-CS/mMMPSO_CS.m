classdef mMMPSO_CS< ALGORITHM
% <multi> <real/integer>

    methods
        function main(Algorithm,Problem)
            %% Generate the weight vectors
            [W,Problem.N] = UniformPoint(Problem.N,Problem.M);
            W = W./repmat(sqrt(sum(W.^2,2)),1,size(W,2));
            His = [];

            %% Generate random population
            Population = Problem.Initialization();
            Z          = min(Population.objs,[],1);
            Archive = Classification(Problem,Population,W,Z);

            %% Optimization
            while Algorithm.NotTerminated(Archive)
                [Pbest, Gbest] = GetBest(Archive,W,Z);
                flag = mod(floor(Problem.FE / Problem.N), 3);
                if flag == 1
                    Population = OperatorPSO_convergence(Problem,Population,Gbest);
                elseif flag == 2
                    Population = OperatorPSO_diversity(Problem,Population,Pbest,Gbest);
                else
                    Population = OperatorPSO_balance(Problem,Population,Pbest,Gbest);
                end

                Archive = EnvironmentalSelection([Archive,Population],W,(Problem.FE/Problem.maxFE)^2);

                S = OperatorGAhalf(Problem,Archive([1:length(Archive),randi(ceil(length(Archive)/2),1,length(Archive))]));
                Z = min([Z;S.objs;Population.objs],[],1);
               
                Archive = EnvironmentalSelection([Archive,Population,S],W,(Problem.FE/Problem.maxFE)^2);

                if Problem.FE / Problem.maxFE > 0.2   %alpha=0.2
                    His = [His, CSp(Problem, Population, His)];
                    if His(end)  >= 0.9 * (max(His) - min(His)) + min(His)  %beta=0.9
                        if ~mod(ceil(Problem.FE/Problem.N), 20)
                            [Population,W] = updateWeight(Population, W, Z, Archive, floor(Problem.N/6));
                        end
                    end
                end
            end
        end
    end
end